# Global Dominion — Military Systems Update

This build adds authoritative, server-side military production and doctrine.

## Aircraft / naval roles

- Fighter / interceptor: air-to-air superiority.
- Strike fighter / ground-attack aircraft: ground combat.
- Strategic bomber: infrastructure/building strikes.
- Naval bomber: anti-ship and coastal operations.
- Reconnaissance aircraft: intelligence role.
- Destroyer / cruiser / carrier / submarine: naval combat roles.

Every blueprint has independent HP, speed, range, costs, research requirements and target effectiveness.

## Research → production

A unit must be researched before production. Production also requires the appropriate facility:

- aircraft → airbase
- naval units → port

Production consumes money and available steel/electronics/oil and progresses on the server tick.

## Combat

The server validates target domains and applies role effectiveness. Aircraft are not interchangeable: fighters are strong against aircraft but weak against ground targets; bombers are strong against buildings and weak against fighters; naval bombers are specialized against ships.

Buildings have integrity and can be damaged/destroyed by authorized bomber/strike attacks.

## Render safety

The existing Node production server, Dockerfile, render.yaml, authentication, persistence and /health endpoint are preserved.
