# Global Dominion Military System

This build upgrades military gameplay into a persistent, server-authoritative real-time system inspired by the genre conventions of games such as Conflict of Nations, without copying proprietary code or UI.

## Functional systems

- Real-time unit movement using latitude/longitude and calculated distance.
- ETA and speed calculated from unit type, supply and distance.
- Route waypoints stored on each order and exposed to the mobile map.
- MOVE, ATTACK, DEFEND, RETREAT, PATROL, RECON, SUPPORT, FORTIFY and TRANSPORT order types.
- Moving armies remain in transit while the player is offline because orders use server timestamps.
- Garrisoned/defending units gain entrenchment, supply recovery and morale recovery.
- Attack orders create server-side battles when hostile forces or hostile territory are reached.
- Battles consume manpower, supply and ammunition and resolve over server ticks.
- Territory ownership changes after a decisive battle.
- World history records battle and territorial outcomes.
- Military formations persist in the JSON world save and reload after restart.
- Recruitment consumes player wealth and creates a real formation with movement/combat statistics.
- Fielded formations consume national treasury through military upkeep.
- Unit status, route, position, destination, progress, ETA, fuel, ammunition, supply and entrenchment are returned to the client.
- Mobile World Map renders live unit routes over the GeoJSON/map layer.
- Mobile Military screen exposes MOVE, ATTACK, DEFEND and RETREAT controls.

## Production architecture

The production Render entry point remains `server/src/index.js`. The existing `/health`, authentication, Render Docker configuration and persistent world file are preserved.

## Important note

The system is an original strategy implementation. It is intentionally not a clone of Conflict of Nations' proprietary code, artwork, branding, formulas or interface.
