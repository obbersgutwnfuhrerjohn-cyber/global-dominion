# Global Dominion Buildings System

Buildings are persistent gameplay objects attached to cities.

- Hospital: heals damaged military units stationed in the city over server ticks.
- Barracks: required for infantry and special forces recruitment.
- Tank Factory: required for armor and mechanized recruitment.
- Artillery Factory: required for artillery and air-defense recruitment.
- Airbase: required for aircraft production.
- Naval Port: required for naval production and coastal operations.
- Industrial Factory: industrial/economic facility.
- Railway: logistics infrastructure.
- Road Network: local logistics infrastructure.

Construction is server-authoritative, costs player wealth, has a persistent build queue, and completes through the world tick. Buildings have levels, integrity, destruction state, and can be targeted by specialized attacks.
