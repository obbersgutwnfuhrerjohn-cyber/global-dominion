# National Command System

President -> Defense Minister -> Military Commander -> Formation Commander -> Officers -> Units.

The server validates command authority. Formation proposal -> presidential approval -> production queue -> completed units -> active formation.

Civilian and military travel agencies are persistent. Military transport uses authoritative unit orders, routes and ETA.

Attack Helicopters require Rotary-Wing Operations research and an Airbase and use the same movement, fuel, ammunition, HP and battle systems as other units.
