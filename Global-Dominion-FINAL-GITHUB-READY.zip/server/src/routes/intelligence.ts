import { Router } from "express";
import { store, type SpyMissionType } from "../data/store";
import { requireAuth, type AuthedRequest } from "../middleware/auth";
import { sendError, sendSuccess } from "../utils/response";

const router = Router();

router.get("/agencies", requireAuth, (req: AuthedRequest, res) => {
  const countryId = (req.query.countryId as string) || req.player!.countryId || undefined;
  sendSuccess(res, [...store.agencies.values()].filter(a => !countryId || a.countryId === countryId));
});

router.post("/agencies", requireAuth, (req: AuthedRequest, res) => {
  try {
    const countryId = req.player!.countryId;
    if (!countryId) throw new Error("NO_COUNTRY");
    const agency = store.createAgency({ countryId, playerId: req.player!.id, name: String(req.body?.name || "National Intelligence Directorate") });
    sendSuccess(res, agency);
  } catch (e) {
    const code = String((e as Error).message || "ERROR");
    const status = code === "INSUFFICIENT_FUNDS" ? 400 : code === "AGENCY_LIMIT" ? 409 : 403;
    sendError(res, status, code.toLowerCase(), code.replaceAll("_", " "));
  }
});

router.get("/missions", requireAuth, (req: AuthedRequest, res) => {
  sendSuccess(res, [...store.spyMissions.values()].filter(m => m.playerId === req.player!.id));
});

router.post("/missions", requireAuth, (req: AuthedRequest, res) => {
  try {
    const type = String(req.body?.type || "recon") as SpyMissionType;
    if (!["recon", "surveillance", "counterintelligence", "sabotage"].includes(type)) throw new Error("INVALID_MISSION_TYPE");
    const mission = store.startSpyMission({
      playerId: req.player!.id,
      agencyId: String(req.body?.agencyId || ""),
      targetCountryId: String(req.body?.targetCountryId || ""),
      targetCity: req.body?.targetCity,
      type,
    });
    sendSuccess(res, mission);
  } catch (e) {
    const code = String((e as Error).message || "ERROR");
    const status = ["AGENCY_CAPACITY", "INVALID_TARGET", "INVALID_MISSION_TYPE"].includes(code) ? 400 : 403;
    sendError(res, status, code.toLowerCase(), code.replaceAll("_", " "));
  }
});

router.get("/reports", requireAuth, (req: AuthedRequest, res) => {
  sendSuccess(res, [...store.spyMissions.values()].filter(m => m.playerId === req.player!.id && ["completed", "caught", "failed"].includes(m.status)));
});

export default router;
