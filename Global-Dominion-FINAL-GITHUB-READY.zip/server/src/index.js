/**
 * Global Dominion API Server
 * Zero-dependency Node.js (http + crypto only)
 * Matches mobile client ApiResponse envelope + core service routes.
 */

const http = require("http");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const { URL } = require("url");
const { verifyStorePurchase, acknowledgeGooglePurchase, consumeGooglePurchase } = require("./iapVerification");

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || "0.0.0.0";
const TICK_MS = Number(process.env.TICK_MS) || 10_000;
const CORS_ORIGINS = (process.env.CORS_ORIGINS || "*").split(",").map((v) => v.trim()).filter(Boolean);
const MAX_BODY_BYTES = 256 * 1024;
const RATE_WINDOW_MS = 60_000;
const RATE_MAX = Number(process.env.RATE_MAX) || 120;
const rateBuckets = new Map();
const VERSION = "1.0.0";
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "..", "data");
const PERSIST_FILE = path.join(DATA_DIR, "world.json");

// ─── helpers ───────────────────────────────────────────────

function rid() {
  return `${Date.now().toString(36)}-${crypto.randomBytes(4).toString("hex")}`;
}

function id(prefix) {
  return `${prefix}_${Date.now().toString(36)}_${crypto.randomBytes(3).toString("hex")}`;
}

function now() {
  return new Date().toISOString();
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const derived = crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1 }).toString("hex");
  return `scrypt$${salt}$${derived}`;
}

function verifyPassword(password, stored) {
  if (typeof stored !== "string") return false;
  if (stored.startsWith("scrypt$")) {
    const [, salt, expected] = stored.split("$");
    if (!salt || !expected) return false;
    const actual = crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1 }).toString("hex");
    return crypto.timingSafeEqual(Buffer.from(actual, "hex"), Buffer.from(expected, "hex"));
  }
  // Legacy SHA-256 hashes are accepted once and upgraded after a successful login.
  const legacy = crypto.createHash("sha256").update(`gd:${password}`).digest("hex");
  return crypto.timingSafeEqual(Buffer.from(legacy), Buffer.from(stored));
}

function json(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Content-Length": Buffer.byteLength(payload),
    "Access-Control-Allow-Origin": CORS_ORIGINS.includes("*") ? "*" : (CORS_ORIGINS.includes(res.req?.headers?.origin) ? res.req.headers.origin : CORS_ORIGINS[0] || ""),
    "Access-Control-Allow-Headers":
      "Content-Type, Authorization, X-Request-ID, X-Client-Version, X-Client-Platform",
    "Access-Control-Allow-Methods": "GET,POST,PUT,PATCH,DELETE,OPTIONS",
    "Access-Control-Expose-Headers": "X-Request-ID",
    "X-Request-ID": body.requestId || rid(),
  });
  res.end(payload);
}

function ok(res, data, status = 200, requestId) {
  const requestIdFinal = requestId || rid();
  json(res, status, {
    success: true,
    data,
    error: null,
    serverTime: now(),
    requestId: requestIdFinal,
  });
}

function fail(res, status, code, message, retryable = false, requestId) {
  const requestIdFinal = requestId || rid();
  json(res, status, {
    success: false,
    data: null,
    error: { code, message, requestId: requestIdFinal, retryable },
    serverTime: now(),
    requestId: requestIdFinal,
  });
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", (c) => {
      size += c.length;
      if (size > MAX_BODY_BYTES) {
        req.destroy();
        reject(new Error("Request body too large"));
        return;
      }
      chunks.push(c);
    });
    req.on("end", () => {
      const raw = Buffer.concat(chunks).toString("utf8");
      if (!raw) return resolve({});
      try {
        resolve(JSON.parse(raw));
      } catch {
        reject(new Error("Invalid JSON"));
      }
    });
    req.on("error", reject);
  });
}

function getBearer(req) {
  const h = req.headers.authorization || "";
  if (h.startsWith("Bearer ")) return h.slice(7);
  return null;
}

// ─── in-memory store ───────────────────────────────────────

const countries = new Map([
  ["country_gnr", {
    id: "country_gnr", name: "Greater German Reich", code: "GNR", capital: "Berlin",
    population: 480000000, gdp: 22000000000000, government: "totalitarian", status: "peace",
    treasury: 6200000000000, militaryStrength: 99, stability: 92, color: "#8B1A1A",
    bloc: "Axis", region: "Central & Northern Europe", superpower: true,
  }],
  ["country_gar", {
    id: "country_gar", name: "Greater Albanian Reich", code: "GAR", capital: "Tirana",
    population: 92000000, gdp: 3800000000000, government: "fascist", status: "peace",
    treasury: 890000000000, militaryStrength: 94, stability: 86, color: "#6B1A2A",
    bloc: "Axis", region: "Full Balkans · Slavic South · All Greece", superpower: true,
  }],
  ["country_jps", {
    id: "country_jps", name: "Pacific States", code: "PST", capital: "San Francisco",
    population: 165000000, gdp: 9800000000000, government: "imperial", status: "peace",
    treasury: 2100000000000, militaryStrength: 96, stability: 88, color: "#1A3A1A",
    bloc: "Axis", region: "Pacific Coast", superpower: true,
  }],
  ["country_ar", {
    id: "country_ar", name: "American Reich", code: "AMR", capital: "Washington D.C.",
    population: 331000000, gdp: 19000000000000, government: "alternate-authoritarian", status: "peace",
    treasury: 4200000000000, militaryStrength: 90, stability: 84, color: "#4A3158",
    bloc: "Continental", region: "Eastern & Central North America", superpower: true,
  }],
  ["country_nz", {
    id: "country_nz", name: "Neutral Zone", code: "NZ", capital: "Denver",
    population: 12000000, gdp: 180000000000, government: "fractured", status: "unstable",
    treasury: 12000000000, militaryStrength: 28, stability: 38, color: "#6B5A3A",
    bloc: "Neutral", region: "Rocky Mountains", superpower: false,
  }],
  ["country_rms", {
    id: "country_rms", name: "Rocky Mountain States", code: "RMS", capital: "Cheyenne",
    population: 8500000, gdp: 95000000000, government: "provisional", status: "tense",
    treasury: 8000000000, militaryStrength: 35, stability: 52, color: "#3A3A48",
    bloc: "Contested", region: "Interior West", superpower: false,
  }],
]);

// Real-world nations used as alternate-history liberation/occupation states.
const realWorldCountrySeeds = [
  ["country_real_abw", { id:"country_real_abw", name:"Aruba", code:"ABW", capital:"Oranjestad", population:101484, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_abw", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_afg", { id:"country_real_afg", name:"Afghanistan", code:"AFG", capital:"Kabul", population:26023100, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_afg", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_ago", { id:"country_real_ago", name:"Angola", code:"AGO", capital:"Luanda", population:24383301, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_ago", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_aia", { id:"country_real_aia", name:"Anguilla", code:"AIA", capital:"The Valley", population:13452, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_aia", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_ala", { id:"country_real_ala", name:"\u00c5land Islands", code:"ALA", capital:"\u00c5land Islands", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_ala", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_alb", { id:"country_real_alb", name:"Albania", code:"ALB", capital:"Tirana", population:2895947, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_alb", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_and", { id:"country_real_and", name:"Andorra", code:"AND", capital:"Andorra", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_and", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_are", { id:"country_real_are", name:"United Arab Emirates", code:"ARE", capital:"Abu Dhabi", population:9446000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_are", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_arg", { id:"country_real_arg", name:"Argentina", code:"ARG", capital:"Buenos Aires", population:42669500, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_arg", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_arm", { id:"country_real_arm", name:"Armenia", code:"ARM", capital:"Yerevan", population:3009800, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_arm", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_asm", { id:"country_real_asm", name:"American Samoa", code:"ASM", capital:"Pago Pago", population:55519, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_asm", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_ata", { id:"country_real_ata", name:"Antarctica", code:"ATA", capital:"Antarctica", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_ata", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_atf", { id:"country_real_atf", name:"French Southern Territories", code:"ATF", capital:"French Southern Territories", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_atf", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_atg", { id:"country_real_atg", name:"Antigua and Barbuda", code:"ATG", capital:"Saint John's", population:86295, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_atg", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_aus", { id:"country_real_aus", name:"Australia", code:"AUS", capital:"Canberra", population:23696900, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_aus", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_aut", { id:"country_real_aut", name:"Austria", code:"AUT", capital:"Vienna", population:8527230, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_aut", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_aze", { id:"country_real_aze", name:"Azerbaijan", code:"AZE", capital:"Baku", population:9552500, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_aze", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_bdi", { id:"country_real_bdi", name:"Burundi", code:"BDI", capital:"Bujumbura", population:9530434, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_bdi", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_bel", { id:"country_real_bel", name:"Belgium", code:"BEL", capital:"Brussels", population:11225469, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_bel", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_ben", { id:"country_real_ben", name:"Benin", code:"BEN", capital:"Porto-Novo", population:9988068, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_ben", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_bes", { id:"country_real_bes", name:"Bonaire, Sint Eustatius and Saba", code:"BES", capital:"Bonaire, Sint Eustatius and Saba", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_bes", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_bfa", { id:"country_real_bfa", name:"Burkina Faso", code:"BFA", capital:"Ouagadougou", population:17322796, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_bfa", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_bgd", { id:"country_real_bgd", name:"Bangladesh", code:"BGD", capital:"Dhaka", population:157486000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_bgd", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_bgr", { id:"country_real_bgr", name:"Bulgaria", code:"BGR", capital:"Sofia", population:7245677, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_bgr", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_bhr", { id:"country_real_bhr", name:"Bahrain", code:"BHR", capital:"Manama", population:1316500, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_bhr", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_bhs", { id:"country_real_bhs", name:"Bahamas", code:"BHS", capital:"Bahamas", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_bhs", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_bih", { id:"country_real_bih", name:"Bosnia and Herzegovina", code:"BIH", capital:"Sarajevo", population:3791622, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_bih", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_blm", { id:"country_real_blm", name:"Saint Barth\u00e9lemy", code:"BLM", capital:"Saint Barth\u00e9lemy", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_blm", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_blr", { id:"country_real_blr", name:"Belarus", code:"BLR", capital:"Minsk", population:9475100, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_blr", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_blz", { id:"country_real_blz", name:"Belize", code:"BLZ", capital:"Belmopan", population:349728, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_blz", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_bmu", { id:"country_real_bmu", name:"Bermuda", code:"BMU", capital:"Hamilton", population:64237, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_bmu", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_bol", { id:"country_real_bol", name:"Bolivia, Plurinational State of", code:"BOL", capital:"Bolivia, Plurinational State of", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_bol", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_bra", { id:"country_real_bra", name:"Brazil", code:"BRA", capital:"Bras\u00edlia", population:203586000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_bra", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_brb", { id:"country_real_brb", name:"Barbados", code:"BRB", capital:"Bridgetown", population:285000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_brb", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_brn", { id:"country_real_brn", name:"Brunei Darussalam", code:"BRN", capital:"Brunei Darussalam", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_brn", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_btn", { id:"country_real_btn", name:"Bhutan", code:"BTN", capital:"Thimphu", population:755030, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_btn", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_bvt", { id:"country_real_bvt", name:"Bouvet Island", code:"BVT", capital:"Bouvet Island", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_bvt", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_bwa", { id:"country_real_bwa", name:"Botswana", code:"BWA", capital:"Gaborone", population:2024904, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_bwa", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_caf", { id:"country_real_caf", name:"Central African Republic", code:"CAF", capital:"Bangui", population:4709000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_caf", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_can", { id:"country_real_can", name:"Canada", code:"CAN", capital:"Ottawa", population:35540419, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_can", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_cck", { id:"country_real_cck", name:"Cocos (Keeling) Islands", code:"CCK", capital:"West Island", population:550, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_cck", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_che", { id:"country_real_che", name:"Switzerland", code:"CHE", capital:"Bern", population:8183800, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_che", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_chl", { id:"country_real_chl", name:"Chile", code:"CHL", capital:"Santiago", population:17819054, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_chl", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_chn", { id:"country_real_chn", name:"China", code:"CHN", capital:"Beijing", population:1367110000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_chn", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_civ", { id:"country_real_civ", name:"C\u00f4te d'Ivoire", code:"CIV", capital:"C\u00f4te d'Ivoire", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_civ", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_cmr", { id:"country_real_cmr", name:"Cameroon", code:"CMR", capital:"Yaound\u00e9", population:20386799, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_cmr", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_cod", { id:"country_real_cod", name:"Congo, The Democratic Republic of the", code:"COD", capital:"Congo, The Democratic Republic of the", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_cod", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_cog", { id:"country_real_cog", name:"Congo", code:"COG", capital:"Congo", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_cog", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_cok", { id:"country_real_cok", name:"Cook Islands", code:"COK", capital:"Avarua", population:14974, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_cok", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_col", { id:"country_real_col", name:"Colombia", code:"COL", capital:"Bogot\u00e1", population:47907800, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_col", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_com", { id:"country_real_com", name:"Comoros", code:"COM", capital:"Moroni", population:763952, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_com", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_cpv", { id:"country_real_cpv", name:"Cabo Verde", code:"CPV", capital:"Cabo Verde", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_cpv", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_cri", { id:"country_real_cri", name:"Costa Rica", code:"CRI", capital:"San Jos\u00e9", population:4713168, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_cri", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_cub", { id:"country_real_cub", name:"Cuba", code:"CUB", capital:"Havana", population:11210064, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_cub", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_cuw", { id:"country_real_cuw", name:"Cura\u00e7ao", code:"CUW", capital:"Cura\u00e7ao", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_cuw", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_cxr", { id:"country_real_cxr", name:"Christmas Island", code:"CXR", capital:"Flying Fish Cove", population:2072, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_cxr", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_cym", { id:"country_real_cym", name:"Cayman Islands", code:"CYM", capital:"George Town", population:55456, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_cym", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_cyp", { id:"country_real_cyp", name:"Cyprus", code:"CYP", capital:"Nicosia", population:858000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_cyp", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_cze", { id:"country_real_cze", name:"Czechia", code:"CZE", capital:"Czechia", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_cze", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_deu", { id:"country_real_deu", name:"Germany", code:"DEU", capital:"Berlin", population:80783000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_deu", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_dji", { id:"country_real_dji", name:"Djibouti", code:"DJI", capital:"Djibouti", population:886000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_dji", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_dma", { id:"country_real_dma", name:"Dominica", code:"DMA", capital:"Roseau", population:71293, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_dma", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_dnk", { id:"country_real_dnk", name:"Denmark", code:"DNK", capital:"Copenhagen", population:5655750, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_dnk", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_dom", { id:"country_real_dom", name:"Dominican Republic", code:"DOM", capital:"Santo Domingo", population:10378267, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_dom", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_dza", { id:"country_real_dza", name:"Algeria", code:"DZA", capital:"Algiers", population:38700000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_dza", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_ecu", { id:"country_real_ecu", name:"Ecuador", code:"ECU", capital:"Quito", population:15888900, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_ecu", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_egy", { id:"country_real_egy", name:"Egypt", code:"EGY", capital:"Cairo", population:87668100, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_egy", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_eri", { id:"country_real_eri", name:"Eritrea", code:"ERI", capital:"Asmara", population:6536000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_eri", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_esh", { id:"country_real_esh", name:"Western Sahara", code:"ESH", capital:"El Aai\u00fan", population:586000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_esh", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_esp", { id:"country_real_esp", name:"Spain", code:"ESP", capital:"Madrid", population:46507760, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_esp", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_est", { id:"country_real_est", name:"Estonia", code:"EST", capital:"Tallinn", population:1315819, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_est", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_eth", { id:"country_real_eth", name:"Ethiopia", code:"ETH", capital:"Addis Ababa", population:87952991, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_eth", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_fin", { id:"country_real_fin", name:"Finland", code:"FIN", capital:"Helsinki", population:5470437, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_fin", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_fji", { id:"country_real_fji", name:"Fiji", code:"FJI", capital:"Suva", population:859178, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_fji", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_flk", { id:"country_real_flk", name:"Falkland Islands (Malvinas)", code:"FLK", capital:"Falkland Islands (Malvinas)", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_flk", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_fra", { id:"country_real_fra", name:"France", code:"FRA", capital:"Paris", population:66078000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_fra", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_fro", { id:"country_real_fro", name:"Faroe Islands", code:"FRO", capital:"T\u00f3rshavn", population:48605, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_fro", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_fsm", { id:"country_real_fsm", name:"Micronesia, Federated States of", code:"FSM", capital:"Micronesia, Federated States of", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_fsm", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_gab", { id:"country_real_gab", name:"Gabon", code:"GAB", capital:"Libreville", population:1711000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_gab", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_gbr", { id:"country_real_gbr", name:"United Kingdom", code:"GBR", capital:"London", population:64105654, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_gbr", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_geo", { id:"country_real_geo", name:"Georgia", code:"GEO", capital:"Tbilisi", population:4490500, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_geo", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_ggy", { id:"country_real_ggy", name:"Guernsey", code:"GGY", capital:"St. Peter Port", population:63085, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_ggy", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_gha", { id:"country_real_gha", name:"Ghana", code:"GHA", capital:"Accra", population:27043093, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_gha", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_gib", { id:"country_real_gib", name:"Gibraltar", code:"GIB", capital:"Gibraltar", population:30001, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_gib", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_gin", { id:"country_real_gin", name:"Guinea", code:"GIN", capital:"Conakry", population:10628972, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_gin", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_glp", { id:"country_real_glp", name:"Guadeloupe", code:"GLP", capital:"Basse-Terre", population:405739, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_glp", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_gmb", { id:"country_real_gmb", name:"Gambia", code:"GMB", capital:"Gambia", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_gmb", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_gnb", { id:"country_real_gnb", name:"Guinea-Bissau", code:"GNB", capital:"Bissau", population:1746000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_gnb", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_gnq", { id:"country_real_gnq", name:"Equatorial Guinea", code:"GNQ", capital:"Malabo", population:1430000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_gnq", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_grc", { id:"country_real_grc", name:"Greece", code:"GRC", capital:"Athens", population:10992589, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_grc", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_grd", { id:"country_real_grd", name:"Grenada", code:"GRD", capital:"St. George's", population:103328, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_grd", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_grl", { id:"country_real_grl", name:"Greenland", code:"GRL", capital:"Nuuk", population:56295, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_grl", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_gtm", { id:"country_real_gtm", name:"Guatemala", code:"GTM", capital:"Guatemala City", population:15806675, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_gtm", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_guf", { id:"country_real_guf", name:"French Guiana", code:"GUF", capital:"Cayenne", population:237549, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_guf", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_gum", { id:"country_real_gum", name:"Guam", code:"GUM", capital:"Hag\u00e5t\u00f1a", population:159358, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_gum", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_guy", { id:"country_real_guy", name:"Guyana", code:"GUY", capital:"Georgetown", population:784894, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_guy", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_hkg", { id:"country_real_hkg", name:"Hong Kong", code:"HKG", capital:"City of Victoria", population:7234800, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_hkg", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_hmd", { id:"country_real_hmd", name:"Heard Island and McDonald Islands", code:"HMD", capital:"Heard Island and McDonald Islands", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_hmd", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_hnd", { id:"country_real_hnd", name:"Honduras", code:"HND", capital:"Tegucigalpa", population:8725111, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_hnd", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_hrv", { id:"country_real_hrv", name:"Croatia", code:"HRV", capital:"Zagreb", population:4267558, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_hrv", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_hti", { id:"country_real_hti", name:"Haiti", code:"HTI", capital:"Port-au-Prince", population:10745665, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_hti", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_hun", { id:"country_real_hun", name:"Hungary", code:"HUN", capital:"Budapest", population:9879000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_hun", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_idn", { id:"country_real_idn", name:"Indonesia", code:"IDN", capital:"Jakarta", population:252164800, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_idn", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_imn", { id:"country_real_imn", name:"Isle of Man", code:"IMN", capital:"Douglas", population:84497, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_imn", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_ind", { id:"country_real_ind", name:"India", code:"IND", capital:"New Delhi", population:1263930000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_ind", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_iot", { id:"country_real_iot", name:"British Indian Ocean Territory", code:"IOT", capital:"Diego Garcia", population:3000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_iot", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_irl", { id:"country_real_irl", name:"Ireland", code:"IRL", capital:"Dublin", population:6378000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_irl", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_irn", { id:"country_real_irn", name:"Iran, Islamic Republic of", code:"IRN", capital:"Iran, Islamic Republic of", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_irn", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_irq", { id:"country_real_irq", name:"Iraq", code:"IRQ", capital:"Baghdad", population:36004552, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_irq", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_isl", { id:"country_real_isl", name:"Iceland", code:"ISL", capital:"Reykjavik", population:328170, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_isl", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_isr", { id:"country_real_isr", name:"Israel", code:"ISR", capital:"Jerusalem", population:8268400, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_isr", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_ita", { id:"country_real_ita", name:"Italy", code:"ITA", capital:"Rome", population:60769102, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_ita", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_jam", { id:"country_real_jam", name:"Jamaica", code:"JAM", capital:"Kingston", population:2717991, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_jam", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_jey", { id:"country_real_jey", name:"Jersey", code:"JEY", capital:"Saint Helier", population:99000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_jey", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_jor", { id:"country_real_jor", name:"Jordan", code:"JOR", capital:"Amman", population:6666960, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_jor", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_jpn", { id:"country_real_jpn", name:"Japan", code:"JPN", capital:"Tokyo", population:127080000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_jpn", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_kaz", { id:"country_real_kaz", name:"Kazakhstan", code:"KAZ", capital:"Astana", population:17377800, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_kaz", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_ken", { id:"country_real_ken", name:"Kenya", code:"KEN", capital:"Nairobi", population:41800000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_ken", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_kgz", { id:"country_real_kgz", name:"Kyrgyzstan", code:"KGZ", capital:"Bishkek", population:5776570, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_kgz", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_khm", { id:"country_real_khm", name:"Cambodia", code:"KHM", capital:"Phnom Penh", population:15184116, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_khm", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_kir", { id:"country_real_kir", name:"Kiribati", code:"KIR", capital:"South Tarawa", population:106461, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_kir", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_kna", { id:"country_real_kna", name:"Saint Kitts and Nevis", code:"KNA", capital:"Basseterre", population:55000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_kna", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_kor", { id:"country_real_kor", name:"Korea, Republic of", code:"KOR", capital:"Korea, Republic of", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_kor", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_kwt", { id:"country_real_kwt", name:"Kuwait", code:"KWT", capital:"Kuwait City", population:3268431, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_kwt", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_lao", { id:"country_real_lao", name:"Lao People's Democratic Republic", code:"LAO", capital:"Vientiane", population:6693300, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_lao", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_lbn", { id:"country_real_lbn", name:"Lebanon", code:"LBN", capital:"Beirut", population:4104000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_lbn", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_lbr", { id:"country_real_lbr", name:"Liberia", code:"LBR", capital:"Monrovia", population:4397000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_lbr", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_lby", { id:"country_real_lby", name:"Libya", code:"LBY", capital:"Tripoli", population:6253000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_lby", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_lca", { id:"country_real_lca", name:"Saint Lucia", code:"LCA", capital:"Castries", population:184000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_lca", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_lie", { id:"country_real_lie", name:"Liechtenstein", code:"LIE", capital:"Vaduz", population:37132, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_lie", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_lka", { id:"country_real_lka", name:"Sri Lanka", code:"LKA", capital:"Colombo", population:20277597, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_lka", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_lso", { id:"country_real_lso", name:"Lesotho", code:"LSO", capital:"Maseru", population:2098000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_lso", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_ltu", { id:"country_real_ltu", name:"Lithuania", code:"LTU", capital:"Vilnius", population:2927310, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_ltu", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_lux", { id:"country_real_lux", name:"Luxembourg", code:"LUX", capital:"Luxembourg", population:549700, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_lux", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_lva", { id:"country_real_lva", name:"Latvia", code:"LVA", capital:"Riga", population:1991800, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_lva", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_mac", { id:"country_real_mac", name:"Macao", code:"MAC", capital:"Macao", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_mac", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_maf", { id:"country_real_maf", name:"Saint Martin (French part)", code:"MAF", capital:"Saint Martin (French part)", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_maf", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_mar", { id:"country_real_mar", name:"Morocco", code:"MAR", capital:"Rabat", population:33465000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_mar", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_mco", { id:"country_real_mco", name:"Monaco", code:"MCO", capital:"Monaco", population:36950, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_mco", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_mda", { id:"country_real_mda", name:"Moldova, Republic of", code:"MDA", capital:"Moldova, Republic of", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_mda", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_mdg", { id:"country_real_mdg", name:"Madagascar", code:"MDG", capital:"Antananarivo", population:21842167, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_mdg", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_mdv", { id:"country_real_mdv", name:"Maldives", code:"MDV", capital:"Mal\u00e9", population:341256, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_mdv", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_mex", { id:"country_real_mex", name:"Mexico", code:"MEX", capital:"Mexico City", population:119713203, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_mex", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_mhl", { id:"country_real_mhl", name:"Marshall Islands", code:"MHL", capital:"Majuro", population:56086, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_mhl", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_mkd", { id:"country_real_mkd", name:"North Macedonia", code:"MKD", capital:"North Macedonia", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_mkd", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_mli", { id:"country_real_mli", name:"Mali", code:"MLI", capital:"Bamako", population:15768000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_mli", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_mlt", { id:"country_real_mlt", name:"Malta", code:"MLT", capital:"Valletta", population:416055, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_mlt", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_mmr", { id:"country_real_mmr", name:"Myanmar", code:"MMR", capital:"Myanmar", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_mmr", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_mne", { id:"country_real_mne", name:"Montenegro", code:"MNE", capital:"Montenegro", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_mne", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_mng", { id:"country_real_mng", name:"Mongolia", code:"MNG", capital:"Ulan Bator", population:2987733, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_mng", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_mnp", { id:"country_real_mnp", name:"Northern Mariana Islands", code:"MNP", capital:"Saipan", population:53883, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_mnp", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_moz", { id:"country_real_moz", name:"Mozambique", code:"MOZ", capital:"Maputo", population:25041922, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_moz", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_mrt", { id:"country_real_mrt", name:"Mauritania", code:"MRT", capital:"Nouakchott", population:3545620, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_mrt", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_msr", { id:"country_real_msr", name:"Montserrat", code:"MSR", capital:"Plymouth", population:4922, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_msr", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_mtq", { id:"country_real_mtq", name:"Martinique", code:"MTQ", capital:"Fort-de-France", population:386486, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_mtq", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_mus", { id:"country_real_mus", name:"Mauritius", code:"MUS", capital:"Port Louis", population:1261208, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_mus", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_mwi", { id:"country_real_mwi", name:"Malawi", code:"MWI", capital:"Lilongwe", population:15805239, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_mwi", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_mys", { id:"country_real_mys", name:"Malaysia", code:"MYS", capital:"Kuala Lumpur", population:30430500, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_mys", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_myt", { id:"country_real_myt", name:"Mayotte", code:"MYT", capital:"Mamoudzou", population:212645, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_myt", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_nam", { id:"country_real_nam", name:"Namibia", code:"NAM", capital:"Windhoek", population:2113077, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_nam", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_ncl", { id:"country_real_ncl", name:"New Caledonia", code:"NCL", capital:"Noum\u00e9a", population:268767, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_ncl", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_ner", { id:"country_real_ner", name:"Niger", code:"NER", capital:"Niamey", population:17138707, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_ner", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_nfk", { id:"country_real_nfk", name:"Norfolk Island", code:"NFK", capital:"Kingston", population:2302, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_nfk", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_nga", { id:"country_real_nga", name:"Nigeria", code:"NGA", capital:"Abuja", population:178517000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_nga", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_nic", { id:"country_real_nic", name:"Nicaragua", code:"NIC", capital:"Managua", population:6134270, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_nic", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_niu", { id:"country_real_niu", name:"Niue", code:"NIU", capital:"Alofi", population:1613, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_niu", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_nld", { id:"country_real_nld", name:"Netherlands", code:"NLD", capital:"Amsterdam", population:16881000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_nld", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_nor", { id:"country_real_nor", name:"Norway", code:"NOR", capital:"Oslo", population:5156450, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_nor", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_npl", { id:"country_real_npl", name:"Nepal", code:"NPL", capital:"Kathmandu", population:27646053, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_npl", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_nru", { id:"country_real_nru", name:"Nauru", code:"NRU", capital:"Yaren", population:10084, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_nru", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_nzl", { id:"country_real_nzl", name:"New Zealand", code:"NZL", capital:"Wellington", population:4547900, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_nzl", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_omn", { id:"country_real_omn", name:"Oman", code:"OMN", capital:"Muscat", population:4089076, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_omn", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_pak", { id:"country_real_pak", name:"Pakistan", code:"PAK", capital:"Islamabad", population:188410000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_pak", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_pan", { id:"country_real_pan", name:"Panama", code:"PAN", capital:"Panama City", population:3713312, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_pan", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_pcn", { id:"country_real_pcn", name:"Pitcairn", code:"PCN", capital:"Pitcairn", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_pcn", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_per", { id:"country_real_per", name:"Peru", code:"PER", capital:"Lima", population:30814175, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_per", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_phl", { id:"country_real_phl", name:"Philippines", code:"PHL", capital:"Manila", population:100697400, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_phl", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_plw", { id:"country_real_plw", name:"Palau", code:"PLW", capital:"Ngerulmud", population:20901, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_plw", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_png", { id:"country_real_png", name:"Papua New Guinea", code:"PNG", capital:"Port Moresby", population:7398500, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_png", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_pol", { id:"country_real_pol", name:"Poland", code:"POL", capital:"Warsaw", population:38496000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_pol", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_pri", { id:"country_real_pri", name:"Puerto Rico", code:"PRI", capital:"San Juan", population:3615086, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_pri", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_prk", { id:"country_real_prk", name:"Korea, Democratic People's Republic of", code:"PRK", capital:"Korea, Democratic People's Republic of", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_prk", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_prt", { id:"country_real_prt", name:"Portugal", code:"PRT", capital:"Lisbon", population:10477800, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_prt", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_pry", { id:"country_real_pry", name:"Paraguay", code:"PRY", capital:"Asunci\u00f3n", population:6893727, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_pry", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_pse", { id:"country_real_pse", name:"Palestine, State of", code:"PSE", capital:"Palestine, State of", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_pse", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_pyf", { id:"country_real_pyf", name:"French Polynesia", code:"PYF", capital:"Papeet\u0113", population:268270, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_pyf", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_qat", { id:"country_real_qat", name:"Qatar", code:"QAT", capital:"Doha", population:2269672, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_qat", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_reu", { id:"country_real_reu", name:"R\u00e9union", code:"REU", capital:"Saint-Denis", population:840974, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_reu", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_rou", { id:"country_real_rou", name:"Romania", code:"ROU", capital:"Bucharest", population:19942642, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_rou", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_rus", { id:"country_real_rus", name:"Russian Federation", code:"RUS", capital:"Moscow", population:146233000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_rus", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_rwa", { id:"country_real_rwa", name:"Rwanda", code:"RWA", capital:"Kigali", population:10996891, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_rwa", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_sau", { id:"country_real_sau", name:"Saudi Arabia", code:"SAU", capital:"Riyadh", population:30770375, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_sau", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_sdn", { id:"country_real_sdn", name:"Sudan", code:"SDN", capital:"Khartoum", population:37289406, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_sdn", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_sen", { id:"country_real_sen", name:"Senegal", code:"SEN", capital:"Dakar", population:13508715, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_sen", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_sgp", { id:"country_real_sgp", name:"Singapore", code:"SGP", capital:"Singapore", population:5469700, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_sgp", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_sgs", { id:"country_real_sgs", name:"South Georgia and the South Sandwich Islands", code:"SGS", capital:"King Edward Point", population:30, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_sgs", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_shn", { id:"country_real_shn", name:"Saint Helena, Ascension and Tristan da Cunha", code:"SHN", capital:"Saint Helena, Ascension and Tristan da Cunha", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_shn", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_sjm", { id:"country_real_sjm", name:"Svalbard and Jan Mayen", code:"SJM", capital:"Longyearbyen", population:2562, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_sjm", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_slb", { id:"country_real_slb", name:"Solomon Islands", code:"SLB", capital:"Honiara", population:581344, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_slb", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_sle", { id:"country_real_sle", name:"Sierra Leone", code:"SLE", capital:"Freetown", population:6205000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_sle", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_slv", { id:"country_real_slv", name:"El Salvador", code:"SLV", capital:"San Salvador", population:6401240, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_slv", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_smr", { id:"country_real_smr", name:"San Marino", code:"SMR", capital:"City of San Marino", population:32743, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_smr", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_som", { id:"country_real_som", name:"Somalia", code:"SOM", capital:"Mogadishu", population:10806000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_som", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_spm", { id:"country_real_spm", name:"Saint Pierre and Miquelon", code:"SPM", capital:"Saint-Pierre", population:6081, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_spm", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_srb", { id:"country_real_srb", name:"Serbia", code:"SRB", capital:"Belgrade", population:7186862, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_srb", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_ssd", { id:"country_real_ssd", name:"South Sudan", code:"SSD", capital:"Juba", population:11384393, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_ssd", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_stp", { id:"country_real_stp", name:"Sao Tome and Principe", code:"STP", capital:"Sao Tome and Principe", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_stp", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_sur", { id:"country_real_sur", name:"Suriname", code:"SUR", capital:"Paramaribo", population:534189, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_sur", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_svk", { id:"country_real_svk", name:"Slovakia", code:"SVK", capital:"Bratislava", population:5415949, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_svk", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_svn", { id:"country_real_svn", name:"Slovenia", code:"SVN", capital:"Ljubljana", population:2064966, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_svn", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_swe", { id:"country_real_swe", name:"Sweden", code:"SWE", capital:"Stockholm", population:9737521, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_swe", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_swz", { id:"country_real_swz", name:"Eswatini", code:"SWZ", capital:"Eswatini", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_swz", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_sxm", { id:"country_real_sxm", name:"Sint Maarten (Dutch part)", code:"SXM", capital:"Sint Maarten (Dutch part)", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_sxm", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_syc", { id:"country_real_syc", name:"Seychelles", code:"SYC", capital:"Victoria", population:89949, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_syc", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_syr", { id:"country_real_syr", name:"Syrian Arab Republic", code:"SYR", capital:"Damascus", population:22964324, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_syr", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_tca", { id:"country_real_tca", name:"Turks and Caicos Islands", code:"TCA", capital:"Turks and Caicos Islands", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_tca", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_tcd", { id:"country_real_tcd", name:"Chad", code:"TCD", capital:"N'Djamena", population:13211000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_tcd", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_tgo", { id:"country_real_tgo", name:"Togo", code:"TGO", capital:"Lom\u00e9", population:6993000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_tgo", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_tha", { id:"country_real_tha", name:"Thailand", code:"THA", capital:"Bangkok", population:64871000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_tha", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_tjk", { id:"country_real_tjk", name:"Tajikistan", code:"TJK", capital:"Dushanbe", population:8161000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_tjk", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_tkl", { id:"country_real_tkl", name:"Tokelau", code:"TKL", capital:"Fakaofo", population:1411, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_tkl", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_tkm", { id:"country_real_tkm", name:"Turkmenistan", code:"TKM", capital:"Ashgabat", population:5838064, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_tkm", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_tls", { id:"country_real_tls", name:"Timor-Leste", code:"TLS", capital:"Timor-Leste", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_tls", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_ton", { id:"country_real_ton", name:"Tonga", code:"TON", capital:"Nuku'alofa", population:103252, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_ton", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_tto", { id:"country_real_tto", name:"Trinidad and Tobago", code:"TTO", capital:"Port of Spain", population:1328019, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_tto", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_tun", { id:"country_real_tun", name:"Tunisia", code:"TUN", capital:"Tunis", population:10982754, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_tun", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_tur", { id:"country_real_tur", name:"T\u00fcrkiye", code:"TUR", capital:"T\u00fcrkiye", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_tur", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_tuv", { id:"country_real_tuv", name:"Tuvalu", code:"TUV", capital:"Funafuti", population:11323, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_tuv", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_twn", { id:"country_real_twn", name:"Taiwan, Province of China", code:"TWN", capital:"Taiwan, Province of China", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_twn", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_tza", { id:"country_real_tza", name:"Tanzania, United Republic of", code:"TZA", capital:"Tanzania, United Republic of", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_tza", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_uga", { id:"country_real_uga", name:"Uganda", code:"UGA", capital:"Kampala", population:34856813, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_uga", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_ukr", { id:"country_real_ukr", name:"Ukraine", code:"UKR", capital:"Kiev", population:42973696, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_ukr", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_umi", { id:"country_real_umi", name:"United States Minor Outlying Islands", code:"UMI", capital:"United States Minor Outlying Islands", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_umi", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_ury", { id:"country_real_ury", name:"Uruguay", code:"URY", capital:"Montevideo", population:3404189, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_ury", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_usa", { id:"country_real_usa", name:"United States", code:"USA", capital:"Washington D.C.", population:319259000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_usa", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_uzb", { id:"country_real_uzb", name:"Uzbekistan", code:"UZB", capital:"Tashkent", population:30492800, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_uzb", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_vat", { id:"country_real_vat", name:"Holy See (Vatican City State)", code:"VAT", capital:"Holy See (Vatican City State)", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_vat", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_vct", { id:"country_real_vct", name:"Saint Vincent and the Grenadines", code:"VCT", capital:"Kingstown", population:109000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_vct", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_ven", { id:"country_real_ven", name:"Venezuela, Bolivarian Republic of", code:"VEN", capital:"Venezuela, Bolivarian Republic of", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_ven", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_vgb", { id:"country_real_vgb", name:"Virgin Islands, British", code:"VGB", capital:"Virgin Islands, British", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_vgb", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_vir", { id:"country_real_vir", name:"Virgin Islands, U.S.", code:"VIR", capital:"Virgin Islands, U.S.", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_vir", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_vnm", { id:"country_real_vnm", name:"Viet Nam", code:"VNM", capital:"Viet Nam", population:1000000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_vnm", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_vut", { id:"country_real_vut", name:"Vanuatu", code:"VUT", capital:"Port Vila", population:264652, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_vut", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_wlf", { id:"country_real_wlf", name:"Wallis and Futuna", code:"WLF", capital:"Mata-Utu", population:13135, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_wlf", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_wsm", { id:"country_real_wsm", name:"Samoa", code:"WSM", capital:"Apia", population:187820, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_wsm", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_yem", { id:"country_real_yem", name:"Yemen", code:"YEM", capital:"Sana'a", population:25956000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_yem", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_zaf", { id:"country_real_zaf", name:"South Africa", code:"ZAF", capital:"Pretoria", population:54002000, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_zaf", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_zmb", { id:"country_real_zmb", name:"Zambia", code:"ZMB", capital:"Lusaka", population:15023315, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_zmb", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
  ["country_real_zwe", { id:"country_real_zwe", name:"Zimbabwe", code:"ZWE", capital:"Harare", population:13061239, gdp:0, government:"provisional", status:"occupied", treasury:100000000, militaryStrength:20, stability:55, color:"#596275", originalCountryId:"country_real_zwe", controllerCountryId:"country_nz", occupationResistance:35, independenceMovement:15 }],
];
for (const [rid, rc] of realWorldCountrySeeds) { if (!countries.has(rid)) countries.set(rid, rc); }

const resourceTypes = [
  { type: "food", name: "Food", amount: 1250, production: 85, consumption: 72, unit: "t" },
  { type: "energy", name: "Energy", amount: 3400, production: 210, consumption: 195, unit: "MWh" },
  { type: "oil", name: "Oil", amount: 890, production: 42, consumption: 38, unit: "bbl" },
  { type: "steel", name: "Steel", amount: 560, production: 28, consumption: 31, unit: "t" },
  { type: "electronics", name: "Electronics", amount: 210, production: 12, consumption: 9, unit: "units" },
  { type: "rare_earth", name: "Rare Earth", amount: 45, production: 3, consumption: 2, unit: "t" },
];

let resources = [];
for (const c of countries.values()) {
  for (const t of resourceTypes) {
    const v = 0.7 + Math.random() * 0.6;
    resources.push({
      countryId: c.id,
      type: t.type,
      name: t.name,
      amount: Math.floor(t.amount * v),
      production: Math.floor(t.production * v),
      consumption: Math.floor(t.consumption * v),
      unit: t.unit,
    });
  }
}

const UNIT_SPEED_KMH = {
  infantry: 28, mechanized: 42, armor: 48, artillery: 30, air_defense: 32,
  strike_fighter: 820, naval_fighter: 800, heavy_bomber: 760, patrol_aircraft: 620, awacs: 600,
  reconnaissance: 55, special_forces: 34, fighter: 820, bomber: 760,
  transport_aircraft: 700, helicopter: 240, drone: 300, interceptor: 920, ground_attack: 690, naval_bomber: 720, reconnaissance_aircraft: 650, frigate: 38,
  destroyer: 42, cruiser: 34, carrier: 30, submarine: 28, landing_ship: 24,
  transport: 32, transport_ship: 24,
};
const UNIT_ATTACK = {
  infantry: 35, mechanized: 48, armor: 72, artillery: 80, air_defense: 22,
  strike_fighter: 115, naval_fighter: 105, heavy_bomber: 125, patrol_aircraft: 70, awacs: 10,
  reconnaissance: 24, special_forces: 52, fighter: 90, bomber: 105,
  transport_aircraft: 8, helicopter: 75, drone: 35, interceptor: 135, ground_attack: 135, naval_bomber: 150, reconnaissance_aircraft: 12, frigate: 62,
  destroyer: 78, cruiser: 92, carrier: 70, submarine: 88, landing_ship: 30,
  transport: 18, transport_ship: 18,
};
const UNIT_DEFENSE = {
  infantry: 42, mechanized: 50, armor: 65, artillery: 24, air_defense: 55,
  strike_fighter: 32, naval_fighter: 34, heavy_bomber: 25, patrol_aircraft: 30, awacs: 20,
  reconnaissance: 20, special_forces: 38, fighter: 28, bomber: 22,
  transport_aircraft: 10, helicopter: 30, drone: 16, interceptor: 110, ground_attack: 65, naval_bomber: 55, reconnaissance_aircraft: 45, frigate: 60,
  destroyer: 72, cruiser: 82, carrier: 64, submarine: 76, landing_ship: 36,
  transport: 24, transport_ship: 24,
};

// ─── Unit doctrine / aircraft & naval specialization ─────────
const UNIT_BLUEPRINTS = {
  fighter: { branch:"air", role:"air_superiority", displayName:"Fighter", hpPerUnit:140, attackAir:115, attackGround:18, attackNaval:8, defenseAir:105, speedKmh:820, rangeKm:900, requiresTech:"tech_air_superiority", requiresFacility:"airbase", buildSeconds:180, cost:{steel:120,electronics:80,oil:45,money:18000} },
  helicopter: { branch:"air", role:"attack_helicopter", displayName:"Attack Helicopter", hpPerUnit:165, attackAir:35, attackGround:125, attackNaval:18, defenseAir:28, speedKmh:240, rangeKm:350, requiresTech:"tech_helicopter", requiresFacility:"airbase", buildSeconds:150, cost:{steel:95,electronics:70,oil:40,money:16000} },
  interceptor: { branch:"air", role:"interceptor", displayName:"Interceptor", hpPerUnit:125, attackAir:135, attackGround:12, attackNaval:5, defenseAir:110, speedKmh:920, rangeKm:1000, requiresTech:"tech_air_superiority", requiresFacility:"airbase", buildSeconds:150, cost:{steel:110,electronics:90,oil:50,money:19000} },
  strike_fighter: { branch:"air", role:"multirole", displayName:"Strike Fighter", hpPerUnit:115, attackAir:78, attackGround:88, attackNaval:30, defenseAir:82, speedKmh:820, rangeKm:1100, requiresTech:"tech_ground_attack", requiresFacility:"airbase", buildSeconds:210, cost:{steel:130,electronics:95,oil:55,money:21000} },
  ground_attack: { branch:"air", role:"ground_attack", displayName:"Ground Attack Aircraft", hpPerUnit:110, attackAir:30, attackGround:135, attackNaval:18, defenseAir:65, speedKmh:690, rangeKm:850, requiresTech:"tech_ground_attack", requiresFacility:"airbase", buildSeconds:210, cost:{steel:135,electronics:70,oil:60,money:20000} },
  bomber: { branch:"air", role:"bomber", displayName:"Strategic Bomber", hpPerUnit:190, attackAir:18, attackGround:75, attackNaval:20, defenseAir:35, speedKmh:760, rangeKm:1600, requiresTech:"tech_strategic_bombing", requiresFacility:"airbase", buildSeconds:300, cost:{steel:220,electronics:120,oil:90,money:40000} },
  naval_bomber: { branch:"air", role:"naval_bomber", displayName:"Naval Bomber", hpPerUnit:130, attackAir:25, attackGround:25, attackNaval:150, defenseAir:55, speedKmh:720, rangeKm:1400, requiresTech:"tech_naval_aviation", requiresFacility:"airbase", buildSeconds:240, cost:{steel:160,electronics:100,oil:70,money:28000} },
  reconnaissance_aircraft: { branch:"air", role:"recon", displayName:"Reconnaissance Aircraft", hpPerUnit:105, attackAir:12, attackGround:8, attackNaval:8, defenseAir:45, speedKmh:650, rangeKm:1500, requiresTech:"tech_recon", requiresFacility:"airbase", buildSeconds:180, cost:{steel:100,electronics:130,oil:50,money:22000} },
  destroyer: { branch:"navy", role:"escort", displayName:"Destroyer", hpPerUnit:520, attackAir:35, attackGround:45, attackNaval:100, defenseAir:80, speedKmh:42, rangeKm:700, requiresTech:"tech_naval", requiresFacility:"port", buildSeconds:420, cost:{steel:900,electronics:180,oil:160,money:120000} },
  cruiser: { branch:"navy", role:"surface_strike", displayName:"Cruiser", hpPerUnit:780, attackAir:45, attackGround:90, attackNaval:125, defenseAir:95, speedKmh:34, rangeKm:1000, requiresTech:"tech_naval", requiresFacility:"port", buildSeconds:600, cost:{steel:1500,electronics:280,oil:220,money:220000} },
  carrier: { branch:"navy", role:"carrier", displayName:"Aircraft Carrier", hpPerUnit:1100, attackAir:75, attackGround:35, attackNaval:85, defenseAir:120, speedKmh:30, rangeKm:900, requiresTech:"tech_carriers", requiresFacility:"port", buildSeconds:1200, cost:{steel:3500,electronics:600,oil:500,money:600000} },
  submarine: { branch:"navy", role:"submarine", displayName:"Attack Submarine", hpPerUnit:600, attackAir:10, attackGround:5, attackNaval:155, defenseAir:25, speedKmh:28, rangeKm:800, requiresTech:"tech_submarines", requiresFacility:"port", buildSeconds:720, cost:{steel:1800,electronics:320,oil:250,money:300000} },
};

const GROUND_ARMORY = {
  infantry: {displayName:"Infantry", branch:"ground", role:"line_infantry", hpPerUnit:100, attackGround:55, attackArmor:18, attackAir:5, defenseGround:48, speedKmh:28, rangeKm:1, requiresFacility:"barracks"},
  mechanized: {displayName:"Mechanized Infantry", branch:"ground", role:"mobile_infantry", hpPerUnit:125, attackGround:68, attackArmor:32, attackAir:8, defenseGround:58, speedKmh:42, rangeKm:1, requiresFacility:"tank_factory"},
  armor: {displayName:"Main Battle Tank", branch:"ground", role:"armor", hpPerUnit:180, attackGround:72, attackArmor:105, attackAir:5, defenseGround:92, speedKmh:48, rangeKm:2, requiresFacility:"tank_factory"},
  tank_destroyer: {displayName:"Tank Destroyer", branch:"ground", role:"anti_armor", hpPerUnit:135, attackGround:42, attackArmor:145, attackAir:4, defenseGround:65, speedKmh:44, rangeKm:3, requiresFacility:"tank_factory"},
  artillery: {displayName:"Field Artillery", branch:"ground", role:"artillery", hpPerUnit:105, attackGround:125, attackArmor:82, attackAir:2, defenseGround:35, speedKmh:30, rangeKm:45, requiresFacility:"artillery_factory"},
  air_defense: {displayName:"Mobile Anti-Air", branch:"ground", role:"anti_air", hpPerUnit:120, attackGround:15, attackArmor:8, attackAir:135, defenseGround:70, speedKmh:32, rangeKm:35, requiresFacility:"artillery_factory"},
  special_forces: {displayName:"Special Forces", branch:"ground", role:"special_operations", hpPerUnit:90, attackGround:105, attackArmor:28, attackAir:2, defenseGround:42, speedKmh:34, rangeKm:2, requiresFacility:"barracks"},
  combat_engineers: {displayName:"Combat Engineers", branch:"ground", role:"engineer", hpPerUnit:115, attackGround:65, attackArmor:20, attackAir:2, defenseGround:62, speedKmh:30, rangeKm:1, requiresFacility:"barracks"},
};

const COMBAT_EFFECTIVENESS = {
  fighter: {fighter:1.75, interceptor:1.65, bomber:1.80, ground_attack:1.45, naval_bomber:1.45, ground:0.18, armor:0.12, building:0.08, ship:0.10},
  interceptor: {fighter:1.85, interceptor:1.70, bomber:1.95, ground_attack:1.70, naval_bomber:1.80, ground:0.12, armor:0.08, building:0.05, ship:0.08},
  ground_attack: {fighter:0.35, interceptor:0.25, bomber:0.40, ground:1.80, armor:1.90, building:1.15, ship:0.35},
  bomber: {fighter:0.20, interceptor:0.15, bomber:0.65, ground:0.85, armor:0.75, building:1.95, ship:0.55},
  helicopter: {fighter:0.18, interceptor:0.12, bomber:0.30, ground:1.75, armor:1.55, building:1.20, ship:0.25},
  naval_bomber: {fighter:0.30, interceptor:0.25, bomber:0.45, ground:0.25, armor:0.30, building:0.45, ship:1.95},
  infantry: {ground:1.20, armor:0.45, air:0.08, building:0.75},
  mechanized: {ground:1.45, armor:0.65, air:0.10, building:0.80},
  armor: {ground:1.65, armor:1.25, air:0.08, building:1.10},
  tank_destroyer: {ground:1.10, armor:1.95, air:0.06, building:0.80},
  artillery: {ground:1.85, armor:1.35, air:0.04, building:1.10},
  air_defense: {air:1.95, ground:0.55, armor:0.25, building:0.30},
  special_forces: {ground:1.85, armor:0.55, air:0.05, building:1.30},
  combat_engineers: {ground:1.35, armor:0.50, air:0.04, building:1.65},
  destroyer: {ship:1.55, submarine:1.90, ground:0.75, building:0.85, air:0.80},
  cruiser: {ship:1.80, submarine:1.35, ground:1.20, building:1.35, air:0.85},
  carrier: {ship:1.65, submarine:0.85, ground:0.95, building:1.10, air:1.45},
  submarine: {ship:1.90, submarine:1.25, ground:0.10, building:0.20, air:0.02},
};

function combatTargetClass(type){
  if(["fighter","interceptor","strike_fighter","ground_attack","bomber","naval_bomber","reconnaissance_aircraft"].includes(type)) return "air";
  if(["destroyer","cruiser","carrier","submarine","landing_ship","transport_ship","frigate","corvette"].includes(type)) return "ship";
  if(["armor","tank_destroyer","mechanized"].includes(type)) return "armor";
  if(["infantry","artillery","air_defense","special_forces","combat_engineers","ground_attack"].includes(type)) return "ground";
  return "ground";
}
function effectivenessFor(attacker, target){
  const a=COMBAT_EFFECTIVENESS[attacker]||{};
  const tc=combatTargetClass(target);
  return Number(a[target] ?? a[tc] ?? 1);
}
function starsFor(v){
  const n=Math.max(1,Math.min(5,Math.round(v/0.4)));
  return "★".repeat(n)+"☆".repeat(5-n);
}

const aircraftProduction = [];

const BUILDING_BLUEPRINTS = {
  hospital: {displayName:"Military Hospital", cost:450, buildTicks:90, maxLevel:5, effects:{healingPerTick:4, woundedRecovery:1}},
  barracks: {displayName:"Barracks", cost:300, buildTicks:60, maxLevel:5, effects:{groundProduction:true, manpower:250}},
  tank_factory: {displayName:"Tank Factory", cost:900, buildTicks:120, maxLevel:5, effects:{armorProduction:true, armorBonus:0.08}},
  artillery_factory: {displayName:"Artillery Factory", cost:850, buildTicks:120, maxLevel:5, effects:{artilleryProduction:true}},
  airbase: {displayName:"Airbase", cost:800, buildTicks:100, maxLevel:5, effects:{airProduction:true, airDefense:20}},
  port: {displayName:"Naval Port", cost:800, buildTicks:110, maxLevel:5, effects:{navalProduction:true, coastalDefense:25}},
  factory: {displayName:"Industrial Factory", cost:600, buildTicks:100, maxLevel:5, effects:{industry:25}},
  rail: {displayName:"Railway", cost:500, buildTicks:80, maxLevel:5, effects:{logistics:20}},
  road: {displayName:"Road Network", cost:300, buildTicks:50, maxLevel:5, effects:{logistics:10}},
  secret_service: {displayName:"Secret Service Headquarters", cost:1200, buildTicks:140, maxLevel:5, effects:{intelligenceCapacity:2, counterintelligence:12, agencyLimit:1}},
};
function buildingBlueprint(type){ return BUILDING_BLUEPRINTS[type] || BUILDING_BLUEPRINTS.factory; }
function cityBuildings(cityId){ return buildings.filter(b=>b.cityId===cityId && !b.destroyed); }
function hasBuilding(cityId,type){ return cityBuildings(cityId).some(b=>b.type===type); }
function buildingLevel(cityId,type){ return cityBuildings(cityId).filter(b=>b.type===type).reduce((n,b)=>Math.max(n,Number(b.level)||1),0); }
function facilityForGroundUnit(type){
  if(type==='infantry'||type==='special_forces') return 'barracks';
  if(type==='armor'||type==='mechanized') return 'tank_factory';
  if(type==='artillery'||type==='air_defense') return 'artillery_factory';
  return null;
}
function hospitalHealUnits(){
  for(const u of units.values()){
    if(!u.currentCityId || !u.health || u.health>=100) continue;
    const level=buildingLevel(u.currentCityId,'hospital');
    if(level<=0) continue;
    const heal=Math.min(100, level*BUILDING_BLUEPRINTS.hospital.effects.healingPerTick);
    u.health=Math.min(100,u.health+heal);
    initializeHitPoints(u);
    u.hitPoints=Math.min(u.maxHitPoints,Math.round(u.maxHitPoints*(u.health/100)));
    if(u.status==='recovering' && u.health>=70) u.status='ready';
  }
}
const buildings = [];
// Initial strategic facilities for the four starting powers. These are real buildable facilities,
// not UI-only flags; production consumes them and additional facilities can be constructed.
for (const seed of [
  ["country_gnr","city_cap_deu","airbase"],["country_gnr","city_cap_deu","port"],
  ["country_gar","city_cap_alb","airbase"],["country_gar","city_cap_alb","port"],
  ["country_jps","city_cap_usa","airbase"],["country_jps","city_cap_usa","port"],
  ["country_ar","city_cap_usa","airbase"],["country_ar","city_cap_usa","port"],
  ["country_gnr","city_cap_deu","secret_service"], ["country_gar","city_cap_alb","secret_service"],
  ["country_jps","city_cap_usa","secret_service"], ["country_ar","city_cap_usa","secret_service"],
]) {
  buildings.push({id:id("bld"),cityId:seed[1],countryId:seed[0],type:seed[2],level:1,integrity:100,destroyed:false,completedAt:now()});
}
for (const [countryId,cityId] of [["country_gnr","city_cap_deu"],["country_gar","city_cap_alb"],["country_jps","city_cap_usa"],["country_ar","city_cap_usa"]]) {
  for (const type of ["hospital","barracks","tank_factory","artillery_factory"]) buildings.push({id:id("bld"),cityId,countryId,type,level:1,integrity:100,destroyed:false,completedAt:now()});
}

const RESEARCH_BLUEPRINTS = [
  {id:"tech_helicopter", name:"Rotary-Wing Operations", category:"aviation", level:2, cost:1900, days:4, prerequisites:["tech_air"], unlocks:["helicopter"]},
  {id:"tech_air_superiority", name:"Air Superiority Doctrine", category:"aviation", level:2, cost:2200, days:4, prerequisites:["tech_air"], unlocks:["fighter","interceptor"]},
  {id:"tech_ground_attack", name:"Close Air Support Doctrine", category:"aviation", level:3, cost:3200, days:6, prerequisites:["tech_air"], unlocks:["strike_fighter","ground_attack"]},
  {id:"tech_strategic_bombing", name:"Strategic Bombing Doctrine", category:"aviation", level:4, cost:5200, days:8, prerequisites:["tech_ground_attack"], unlocks:["bomber"]},
  {id:"tech_naval_aviation", name:"Naval Aviation", category:"aviation", level:3, cost:3800, days:6, prerequisites:["tech_air","tech_naval"], unlocks:["naval_bomber"]},
  {id:"tech_recon", name:"Long Range Reconnaissance", category:"aviation", level:2, cost:1800, days:3, prerequisites:["tech_air"], unlocks:["reconnaissance_aircraft"]},
  {id:"tech_carriers", name:"Carrier Task Forces", category:"naval", level:4, cost:9000, days:12, prerequisites:["tech_naval"], unlocks:["carrier"]},
  {id:"tech_submarines", name:"Advanced Submarines", category:"naval", level:3, cost:4200, days:7, prerequisites:["tech_naval"], unlocks:["submarine"]},
];
function blueprintFor(type){ return UNIT_BLUEPRINTS[type] || null; }
function unitHasResearch(playerId, techId){
  if(!techId) return true;
  return researchProjects.some(p=>p.playerId===playerId && p.technologyId===techId && p.status==="completed");
}
function hasFacility(countryId, facilityType, cityId){
  if(!facilityType) return true;
  return buildings.some(b=>b.countryId===countryId && b.type===facilityType && !b.destroyed && (!cityId || b.cityId===cityId));
}
function targetClassFor(unit){
  if(isAirUnit(unit)) return "air";
  if(isNavalUnit(unit)) return "naval";
  return "ground";
}
function effectivenessFor(unit, target){
  const bp=blueprintFor(unit.type);
  if(!bp) return 1;
  if(target && target.__building){ return bp.role==="bomber"?1.9:bp.role==="ground_attack"?1.5:bp.role==="multirole"?1.1:0.15; }
  const cls=targetClassFor(target || {});
  if(bp.role==="air_superiority" || bp.role==="interceptor") return cls==="air"?1.75:0.18;
  if(bp.role==="ground_attack") return cls==="ground"?1.8:0.28;
  if(bp.role==="bomber") return cls==="ground"?1.35:0.22;
  if(bp.role==="naval_bomber") return cls==="naval"?1.9:0.2;
  if(bp.role==="multirole") return cls==="air"?0.85:cls==="ground"?1.25:0.65;
  if(bp.role==="surface_strike") return cls==="naval"?1.45:cls==="ground"?1.2:0.5;
  if(bp.role==="submarine") return cls==="naval"?1.8:0.1;
  return 1;
}
function initializeHitPoints(u){
  const bp=blueprintFor(u.type);
  if(bp){
    const count=Math.max(1,Number(u.size)||1);
    u.maxHitPoints=Math.max(1,Math.round(count*bp.hpPerUnit));
    if(u.hitPoints==null) u.hitPoints=u.maxHitPoints;
    u.hitPoints=Math.min(u.maxHitPoints,Math.max(0,u.hitPoints));
  } else {
    u.maxHitPoints=Math.max(1000,Math.round((u.size||1000)*10));
    if(u.hitPoints==null) u.hitPoints=u.maxHitPoints;
  }
  return u;
}
function haversineKm(a,b){
  const R=6371, p=Math.PI/180;
  const dLat=(b.latitude-a.latitude)*p, dLon=(b.longitude-a.longitude)*p;
  const x=Math.sin(dLat/2)**2 + Math.cos(a.latitude*p)*Math.cos(b.latitude*p)*Math.sin(dLon/2)**2;
  return 2*R*Math.asin(Math.sqrt(x));
}
function cityPoint(city){ return city ? {latitude:Number(city.latitude)||0, longitude:Number(city.longitude)||0} : null; }
function findNearestFriendlyCity(unit){
  const candidates=strategyCities.filter(c => (c.controllerCountryId||c.countryId)===unit.countryId && Number.isFinite(c.latitude) && Number.isFinite(c.longitude));
  if(!candidates.length) return null;
  const from=unit.position || cityPoint(strategyCities.find(c=>c.id===unit.currentCityId));
  if(!from) return candidates[0];
  return candidates.sort((a,b)=>haversineKm(from,cityPoint(a))-haversineKm(from,cityPoint(b)))[0];
}
function makeRoute(from,to,steps=8){
  const route=[]; for(let i=0;i<=steps;i++){const t=i/steps; route.push({latitude:from.latitude+(to.latitude-from.latitude)*t,longitude:from.longitude+(to.longitude-from.longitude)*t});} return route;
}
function normalizeUnit(u){
  if(!u.position){
    const city=strategyCities.find(c=>c.id===u.currentCityId) || strategyCities.find(c=>c.name===u.location);
    u.position=cityPoint(city) || {latitude:0,longitude:0};
  }
  if(!u.destination) u.destination=null;
  if(!u.route) u.route=[];
  if(!u.movementSpeed) u.movementSpeed=UNIT_SPEED_KMH[u.type]||30;
  if(u.health==null) u.health=100;
  if(u.readiness==null) u.readiness=90;
  if(u.fuel==null) u.fuel=100;
  if(u.ammunition==null) u.ammunition=100;
  if(u.organization==null) u.organization=100;
  if(u.entrenchment==null) u.entrenchment=0;
  if(!u.orderStatus) u.orderStatus='idle';
  if(!u.commanderPlayerId) u.commanderPlayerId=u.ownerPlayerId||null;
  return u;
}
const units = new Map([
  ["unit_1", ({id:"unit_1",countryId:"country_jps",type:"infantry",name:"1st Infantry Division",size:12000,location:"Washington Sector",currentCityId:"city_cap_usa",morale:78,supply:92,status:"ready",ownerPlayerId:null})],
  ["unit_2", ({id:"unit_2",countryId:"country_jps",type:"armor",name:"3rd Armored Brigade",size:4500,location:"Northern Command",currentCityId:"city_cap_usa",morale:85,supply:88,status:"ready",ownerPlayerId:null})],
  ["unit_3", ({id:"unit_3",countryId:"country_jps",type:"fighter",name:"Air Wing Alpha",size:48,location:"Central Airbase",currentCityId:"city_cap_usa",morale:91,supply:95,status:"ready",ownerPlayerId:null})],
  ["unit_4", ({id:"unit_4",countryId:"country_gnr",type:"infantry",name:"Berlin Garrison",size:28000,location:"Berlin",currentCityId:"city_cap_deu",morale:80,supply:86,status:"ready",ownerPlayerId:null})],
]);


let market = [
  { symbol: "FOOD", name: "Food Futures", price: 42.5, change: 1.2 },
  { symbol: "OIL", name: "Crude Oil", price: 78.3, change: -0.8 },
  { symbol: "STL", name: "Steel Index", price: 615.0, change: 3.1 },
  { symbol: "ENR", name: "Energy Basket", price: 112.4, change: 0.4 },
  { symbol: "TECH", name: "Tech Components", price: 245.7, change: 5.6 },
];

let events = [
  {
    id: "evt_1",
    title: "Trade Summit Concludes",
    description: "Major powers agree on temporary tariff reductions.",
    type: "diplomacy",
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    countryIds: ["country_gnr", "country_jps", "country_gar"],
  },
  {
    id: "evt_2",
    title: "Resource Shortage Alert",
    description: "Steel production lags behind industrial demand.",
    type: "economy",
    timestamp: new Date(Date.now() - 7200000).toISOString(),
    countryIds: ["country_nz", "country_rms"],
  },
  {
    id: "evt_3",
    title: "Election Cycle Begins",
    description: "Parliamentary elections scheduled in the European Federation.",
    type: "politics",
    timestamp: new Date(Date.now() - 14400000).toISOString(),
    countryIds: ["country_eu"],
  },
];

const players = new Map(); // id -> player
const playersByEmail = new Map();
const sessions = new Map(); // accessToken -> session
const shopPurchases = new Map(); // transactionId -> record
const playerEntitlements = new Map(); // playerId -> { marks, unlocks, purchases[] }
const wars = [];
const companies = [];
const accounts = [];
const relations = new Map();

// ─── persistent grand-strategy state ──────────────────────
const strategyCities = [
  ["Berlin","country_gnr",52.52,13.405,true,3660000], ["Hamburg","country_gnr",53.55,9.993,false,1900000], ["Munich","country_gnr",48.135,11.582,false,1500000],
  ["London","country_gnr",51.507,-0.128,true,9000000], ["Paris","country_gnr",48.857,2.352,true,2100000], ["Warsaw","country_gnr",52.229,21.012,false,1800000], ["Moscow","country_gnr",55.756,37.617,true,13000000],
  ["Tirana","country_gar",41.327,19.819,true,550000], ["Belgrade","country_gar",44.787,20.448,true,1400000], ["Athens","country_gar",37.984,23.728,true,3200000], ["Thessaloniki","country_gar",40.64,22.944,false,1000000], ["Rome","country_gar",41.902,12.496,true,2800000],
  ["San Francisco","country_jps",37.775,-122.419,true,870000], ["Los Angeles","country_jps",34.052,-118.244,true,3900000], ["Seattle","country_jps",47.606,-122.332,false,750000], ["Tokyo","country_jps",35.676,139.65,true,14000000], ["Osaka","country_jps",34.693,135.502,false,2700000], ["Shanghai","country_jps",31.23,121.474,true,25000000], ["Beijing","country_jps",39.904,116.407,true,22000000], ["Seoul","country_jps",37.566,126.978,false,9500000],
  ["Denver","country_nz",39.739,-104.99,true,720000], ["New York","country_nz",40.713,-74.006,true,8300000], ["Cheyenne","country_rms",41.14,-104.82,false,65000],
  ["Cairo","country_gar",30.044,31.235,false,10000000], ["Istanbul","country_gar",41.008,28.978,false,15000000], ["Tehran","country_nz",35.689,51.389,false,9000000], ["Delhi","country_jps",28.614,77.209,true,19000000], ["Mumbai","country_jps",19.076,72.878,false,12500000],
  ["Sydney","country_jps",-33.869,151.209,true,5300000], ["Melbourne","country_jps",-37.813,144.963,false,5100000], ["Buenos Aires","country_nz",-34.603,-58.382,true,3100000], ["São Paulo","country_nz",-23.551,-46.633,true,12000000], ["Cape Town","country_nz",-33.925,18.424,false,4600000],
].map(([name,countryId,lat,lon,capital,pop],i)=>({id:`city_${i+1}`,name,countryId,latitude:lat,longitude:lon,capital,major:capital||pop>1000000,population:pop,industrial:pop>1000000,military:capital||pop>2000000,morale:75,development:Math.min(10,Math.max(2,Math.round(pop/2500000))),updatedAt:now()}));

// Capital cities for the real-world nation layer.
const realWorldCapitalCities = [
  {id:"city_cap_abw",name:"Oranjestad",countryId:"country_real_abw",latitude:12.5,longitude:-69.96666666,capital:true,major:true,population:101484,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_afg",name:"Kabul",countryId:"country_real_afg",latitude:33.0,longitude:65.0,capital:true,major:true,population:26023100,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_ago",name:"Luanda",countryId:"country_real_ago",latitude:-12.5,longitude:18.5,capital:true,major:true,population:24383301,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_aia",name:"The Valley",countryId:"country_real_aia",latitude:18.25,longitude:-63.16666666,capital:true,major:true,population:13452,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_ala",name:"\u00c5land Islands",countryId:"country_real_ala",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_alb",name:"Tirana",countryId:"country_real_alb",latitude:41.0,longitude:20.0,capital:true,major:true,population:2895947,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_and",name:"Andorra",countryId:"country_real_and",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_are",name:"Abu Dhabi",countryId:"country_real_are",latitude:24.0,longitude:54.0,capital:true,major:true,population:9446000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_arg",name:"Buenos Aires",countryId:"country_real_arg",latitude:-34.0,longitude:-64.0,capital:true,major:true,population:42669500,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_arm",name:"Yerevan",countryId:"country_real_arm",latitude:40.0,longitude:45.0,capital:true,major:true,population:3009800,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_asm",name:"Pago Pago",countryId:"country_real_asm",latitude:-14.33333333,longitude:-170.0,capital:true,major:true,population:55519,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_ata",name:"Antarctica",countryId:"country_real_ata",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_atf",name:"French Southern Territories",countryId:"country_real_atf",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_atg",name:"Saint John's",countryId:"country_real_atg",latitude:17.05,longitude:-61.8,capital:true,major:true,population:86295,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_aus",name:"Canberra",countryId:"country_real_aus",latitude:-27.0,longitude:133.0,capital:true,major:true,population:23696900,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_aut",name:"Vienna",countryId:"country_real_aut",latitude:47.33333333,longitude:13.33333333,capital:true,major:true,population:8527230,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_aze",name:"Baku",countryId:"country_real_aze",latitude:40.5,longitude:47.5,capital:true,major:true,population:9552500,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_bdi",name:"Bujumbura",countryId:"country_real_bdi",latitude:-3.5,longitude:30.0,capital:true,major:true,population:9530434,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_bel",name:"Brussels",countryId:"country_real_bel",latitude:50.83333333,longitude:4.0,capital:true,major:true,population:11225469,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_ben",name:"Porto-Novo",countryId:"country_real_ben",latitude:9.5,longitude:2.25,capital:true,major:true,population:9988068,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_bes",name:"Bonaire, Sint Eustatius and Saba",countryId:"country_real_bes",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_bfa",name:"Ouagadougou",countryId:"country_real_bfa",latitude:13.0,longitude:-2.0,capital:true,major:true,population:17322796,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_bgd",name:"Dhaka",countryId:"country_real_bgd",latitude:24.0,longitude:90.0,capital:true,major:true,population:157486000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_bgr",name:"Sofia",countryId:"country_real_bgr",latitude:43.0,longitude:25.0,capital:true,major:true,population:7245677,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_bhr",name:"Manama",countryId:"country_real_bhr",latitude:26.0,longitude:50.55,capital:true,major:true,population:1316500,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_bhs",name:"Bahamas",countryId:"country_real_bhs",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_bih",name:"Sarajevo",countryId:"country_real_bih",latitude:44.0,longitude:18.0,capital:true,major:true,population:3791622,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_blm",name:"Saint Barth\u00e9lemy",countryId:"country_real_blm",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_blr",name:"Minsk",countryId:"country_real_blr",latitude:53.0,longitude:28.0,capital:true,major:true,population:9475100,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_blz",name:"Belmopan",countryId:"country_real_blz",latitude:17.25,longitude:-88.75,capital:true,major:true,population:349728,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_bmu",name:"Hamilton",countryId:"country_real_bmu",latitude:32.33333333,longitude:-64.75,capital:true,major:true,population:64237,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_bol",name:"Bolivia, Plurinational State of",countryId:"country_real_bol",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_bra",name:"Bras\u00edlia",countryId:"country_real_bra",latitude:-10.0,longitude:-55.0,capital:true,major:true,population:203586000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_brb",name:"Bridgetown",countryId:"country_real_brb",latitude:13.16666666,longitude:-59.53333333,capital:true,major:true,population:285000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_brn",name:"Brunei Darussalam",countryId:"country_real_brn",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_btn",name:"Thimphu",countryId:"country_real_btn",latitude:27.5,longitude:90.5,capital:true,major:true,population:755030,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_bvt",name:"Bouvet Island",countryId:"country_real_bvt",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_bwa",name:"Gaborone",countryId:"country_real_bwa",latitude:-22.0,longitude:24.0,capital:true,major:true,population:2024904,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_caf",name:"Bangui",countryId:"country_real_caf",latitude:7.0,longitude:21.0,capital:true,major:true,population:4709000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_can",name:"Ottawa",countryId:"country_real_can",latitude:60.0,longitude:-95.0,capital:true,major:true,population:35540419,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_cck",name:"West Island",countryId:"country_real_cck",latitude:-12.5,longitude:96.83333333,capital:true,major:true,population:550,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_che",name:"Bern",countryId:"country_real_che",latitude:47.0,longitude:8.0,capital:true,major:true,population:8183800,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_chl",name:"Santiago",countryId:"country_real_chl",latitude:-30.0,longitude:-71.0,capital:true,major:true,population:17819054,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_chn",name:"Beijing",countryId:"country_real_chn",latitude:35.0,longitude:105.0,capital:true,major:true,population:1367110000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_civ",name:"C\u00f4te d'Ivoire",countryId:"country_real_civ",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_cmr",name:"Yaound\u00e9",countryId:"country_real_cmr",latitude:6.0,longitude:12.0,capital:true,major:true,population:20386799,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_cod",name:"Congo, The Democratic Republic of the",countryId:"country_real_cod",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_cog",name:"Congo",countryId:"country_real_cog",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_cok",name:"Avarua",countryId:"country_real_cok",latitude:-21.23333333,longitude:-159.76666666,capital:true,major:true,population:14974,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_col",name:"Bogot\u00e1",countryId:"country_real_col",latitude:4.0,longitude:-72.0,capital:true,major:true,population:47907800,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_com",name:"Moroni",countryId:"country_real_com",latitude:-12.16666666,longitude:44.25,capital:true,major:true,population:763952,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_cpv",name:"Cabo Verde",countryId:"country_real_cpv",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_cri",name:"San Jos\u00e9",countryId:"country_real_cri",latitude:10.0,longitude:-84.0,capital:true,major:true,population:4713168,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_cub",name:"Havana",countryId:"country_real_cub",latitude:21.5,longitude:-80.0,capital:true,major:true,population:11210064,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_cuw",name:"Cura\u00e7ao",countryId:"country_real_cuw",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_cxr",name:"Flying Fish Cove",countryId:"country_real_cxr",latitude:-10.5,longitude:105.66666666,capital:true,major:true,population:2072,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_cym",name:"George Town",countryId:"country_real_cym",latitude:19.5,longitude:-80.5,capital:true,major:true,population:55456,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_cyp",name:"Nicosia",countryId:"country_real_cyp",latitude:35.0,longitude:33.0,capital:true,major:true,population:858000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_cze",name:"Czechia",countryId:"country_real_cze",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_deu",name:"Berlin",countryId:"country_real_deu",latitude:51.0,longitude:9.0,capital:true,major:true,population:80783000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_dji",name:"Djibouti",countryId:"country_real_dji",latitude:11.5,longitude:43.0,capital:true,major:true,population:886000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_dma",name:"Roseau",countryId:"country_real_dma",latitude:15.41666666,longitude:-61.33333333,capital:true,major:true,population:71293,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_dnk",name:"Copenhagen",countryId:"country_real_dnk",latitude:56.0,longitude:10.0,capital:true,major:true,population:5655750,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_dom",name:"Santo Domingo",countryId:"country_real_dom",latitude:19.0,longitude:-70.66666666,capital:true,major:true,population:10378267,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_dza",name:"Algiers",countryId:"country_real_dza",latitude:28.0,longitude:3.0,capital:true,major:true,population:38700000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_ecu",name:"Quito",countryId:"country_real_ecu",latitude:-2.0,longitude:-77.5,capital:true,major:true,population:15888900,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_egy",name:"Cairo",countryId:"country_real_egy",latitude:27.0,longitude:30.0,capital:true,major:true,population:87668100,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_eri",name:"Asmara",countryId:"country_real_eri",latitude:15.0,longitude:39.0,capital:true,major:true,population:6536000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_esh",name:"El Aai\u00fan",countryId:"country_real_esh",latitude:24.5,longitude:-13.0,capital:true,major:true,population:586000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_esp",name:"Madrid",countryId:"country_real_esp",latitude:40.0,longitude:-4.0,capital:true,major:true,population:46507760,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_est",name:"Tallinn",countryId:"country_real_est",latitude:59.0,longitude:26.0,capital:true,major:true,population:1315819,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_eth",name:"Addis Ababa",countryId:"country_real_eth",latitude:8.0,longitude:38.0,capital:true,major:true,population:87952991,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_fin",name:"Helsinki",countryId:"country_real_fin",latitude:64.0,longitude:26.0,capital:true,major:true,population:5470437,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_fji",name:"Suva",countryId:"country_real_fji",latitude:-18.0,longitude:175.0,capital:true,major:true,population:859178,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_flk",name:"Falkland Islands (Malvinas)",countryId:"country_real_flk",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_fra",name:"Paris",countryId:"country_real_fra",latitude:46.0,longitude:2.0,capital:true,major:true,population:66078000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_fro",name:"T\u00f3rshavn",countryId:"country_real_fro",latitude:62.0,longitude:-7.0,capital:true,major:true,population:48605,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_fsm",name:"Micronesia, Federated States of",countryId:"country_real_fsm",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_gab",name:"Libreville",countryId:"country_real_gab",latitude:-1.0,longitude:11.75,capital:true,major:true,population:1711000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_gbr",name:"London",countryId:"country_real_gbr",latitude:54.0,longitude:-2.0,capital:true,major:true,population:64105654,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_geo",name:"Tbilisi",countryId:"country_real_geo",latitude:42.0,longitude:43.5,capital:true,major:true,population:4490500,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_ggy",name:"St. Peter Port",countryId:"country_real_ggy",latitude:49.46666666,longitude:-2.58333333,capital:true,major:true,population:63085,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_gha",name:"Accra",countryId:"country_real_gha",latitude:8.0,longitude:-2.0,capital:true,major:true,population:27043093,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_gib",name:"Gibraltar",countryId:"country_real_gib",latitude:36.13333333,longitude:-5.35,capital:true,major:true,population:30001,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_gin",name:"Conakry",countryId:"country_real_gin",latitude:11.0,longitude:-10.0,capital:true,major:true,population:10628972,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_glp",name:"Basse-Terre",countryId:"country_real_glp",latitude:16.25,longitude:-61.583333,capital:true,major:true,population:405739,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_gmb",name:"Gambia",countryId:"country_real_gmb",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_gnb",name:"Bissau",countryId:"country_real_gnb",latitude:12.0,longitude:-15.0,capital:true,major:true,population:1746000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_gnq",name:"Malabo",countryId:"country_real_gnq",latitude:2.0,longitude:10.0,capital:true,major:true,population:1430000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_grc",name:"Athens",countryId:"country_real_grc",latitude:39.0,longitude:22.0,capital:true,major:true,population:10992589,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_grd",name:"St. George's",countryId:"country_real_grd",latitude:12.11666666,longitude:-61.66666666,capital:true,major:true,population:103328,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_grl",name:"Nuuk",countryId:"country_real_grl",latitude:72.0,longitude:-40.0,capital:true,major:true,population:56295,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_gtm",name:"Guatemala City",countryId:"country_real_gtm",latitude:15.5,longitude:-90.25,capital:true,major:true,population:15806675,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_guf",name:"Cayenne",countryId:"country_real_guf",latitude:4.0,longitude:-53.0,capital:true,major:true,population:237549,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_gum",name:"Hag\u00e5t\u00f1a",countryId:"country_real_gum",latitude:13.46666666,longitude:144.78333333,capital:true,major:true,population:159358,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_guy",name:"Georgetown",countryId:"country_real_guy",latitude:5.0,longitude:-59.0,capital:true,major:true,population:784894,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_hkg",name:"City of Victoria",countryId:"country_real_hkg",latitude:22.25,longitude:114.16666666,capital:true,major:true,population:7234800,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_hmd",name:"Heard Island and McDonald Islands",countryId:"country_real_hmd",latitude:-53.1,longitude:72.51666666,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_hnd",name:"Tegucigalpa",countryId:"country_real_hnd",latitude:15.0,longitude:-86.5,capital:true,major:true,population:8725111,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_hrv",name:"Zagreb",countryId:"country_real_hrv",latitude:45.16666666,longitude:15.5,capital:true,major:true,population:4267558,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_hti",name:"Port-au-Prince",countryId:"country_real_hti",latitude:19.0,longitude:-72.41666666,capital:true,major:true,population:10745665,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_hun",name:"Budapest",countryId:"country_real_hun",latitude:47.0,longitude:20.0,capital:true,major:true,population:9879000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_idn",name:"Jakarta",countryId:"country_real_idn",latitude:-5.0,longitude:120.0,capital:true,major:true,population:252164800,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_imn",name:"Douglas",countryId:"country_real_imn",latitude:54.25,longitude:-4.5,capital:true,major:true,population:84497,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_ind",name:"New Delhi",countryId:"country_real_ind",latitude:20.0,longitude:77.0,capital:true,major:true,population:1263930000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_iot",name:"Diego Garcia",countryId:"country_real_iot",latitude:-6.0,longitude:71.5,capital:true,major:true,population:3000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_irl",name:"Dublin",countryId:"country_real_irl",latitude:53.0,longitude:-8.0,capital:true,major:true,population:6378000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_irn",name:"Iran, Islamic Republic of",countryId:"country_real_irn",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_irq",name:"Baghdad",countryId:"country_real_irq",latitude:33.0,longitude:44.0,capital:true,major:true,population:36004552,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_isl",name:"Reykjavik",countryId:"country_real_isl",latitude:65.0,longitude:-18.0,capital:true,major:true,population:328170,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_isr",name:"Jerusalem",countryId:"country_real_isr",latitude:31.5,longitude:34.75,capital:true,major:true,population:8268400,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_ita",name:"Rome",countryId:"country_real_ita",latitude:42.83333333,longitude:12.83333333,capital:true,major:true,population:60769102,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_jam",name:"Kingston",countryId:"country_real_jam",latitude:18.25,longitude:-77.5,capital:true,major:true,population:2717991,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_jey",name:"Saint Helier",countryId:"country_real_jey",latitude:49.25,longitude:-2.16666666,capital:true,major:true,population:99000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_jor",name:"Amman",countryId:"country_real_jor",latitude:31.0,longitude:36.0,capital:true,major:true,population:6666960,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_jpn",name:"Tokyo",countryId:"country_real_jpn",latitude:36.0,longitude:138.0,capital:true,major:true,population:127080000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_kaz",name:"Astana",countryId:"country_real_kaz",latitude:48.0,longitude:68.0,capital:true,major:true,population:17377800,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_ken",name:"Nairobi",countryId:"country_real_ken",latitude:1.0,longitude:38.0,capital:true,major:true,population:41800000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_kgz",name:"Bishkek",countryId:"country_real_kgz",latitude:41.0,longitude:75.0,capital:true,major:true,population:5776570,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_khm",name:"Phnom Penh",countryId:"country_real_khm",latitude:13.0,longitude:105.0,capital:true,major:true,population:15184116,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_kir",name:"South Tarawa",countryId:"country_real_kir",latitude:1.41666666,longitude:173.0,capital:true,major:true,population:106461,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_kna",name:"Basseterre",countryId:"country_real_kna",latitude:17.33333333,longitude:-62.75,capital:true,major:true,population:55000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_kor",name:"Korea, Republic of",countryId:"country_real_kor",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_kwt",name:"Kuwait City",countryId:"country_real_kwt",latitude:29.5,longitude:45.75,capital:true,major:true,population:3268431,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_lao",name:"Vientiane",countryId:"country_real_lao",latitude:18.0,longitude:105.0,capital:true,major:true,population:6693300,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_lbn",name:"Beirut",countryId:"country_real_lbn",latitude:33.83333333,longitude:35.83333333,capital:true,major:true,population:4104000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_lbr",name:"Monrovia",countryId:"country_real_lbr",latitude:6.5,longitude:-9.5,capital:true,major:true,population:4397000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_lby",name:"Tripoli",countryId:"country_real_lby",latitude:25.0,longitude:17.0,capital:true,major:true,population:6253000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_lca",name:"Castries",countryId:"country_real_lca",latitude:13.88333333,longitude:-60.96666666,capital:true,major:true,population:184000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_lie",name:"Vaduz",countryId:"country_real_lie",latitude:47.26666666,longitude:9.53333333,capital:true,major:true,population:37132,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_lka",name:"Colombo",countryId:"country_real_lka",latitude:7.0,longitude:81.0,capital:true,major:true,population:20277597,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_lso",name:"Maseru",countryId:"country_real_lso",latitude:-29.5,longitude:28.5,capital:true,major:true,population:2098000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_ltu",name:"Vilnius",countryId:"country_real_ltu",latitude:56.0,longitude:24.0,capital:true,major:true,population:2927310,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_lux",name:"Luxembourg",countryId:"country_real_lux",latitude:49.75,longitude:6.16666666,capital:true,major:true,population:549700,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_lva",name:"Riga",countryId:"country_real_lva",latitude:57.0,longitude:25.0,capital:true,major:true,population:1991800,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_mac",name:"Macao",countryId:"country_real_mac",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_maf",name:"Saint Martin (French part)",countryId:"country_real_maf",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_mar",name:"Rabat",countryId:"country_real_mar",latitude:32.0,longitude:-5.0,capital:true,major:true,population:33465000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_mco",name:"Monaco",countryId:"country_real_mco",latitude:43.73333333,longitude:7.4,capital:true,major:true,population:36950,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_mda",name:"Moldova, Republic of",countryId:"country_real_mda",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_mdg",name:"Antananarivo",countryId:"country_real_mdg",latitude:-20.0,longitude:47.0,capital:true,major:true,population:21842167,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_mdv",name:"Mal\u00e9",countryId:"country_real_mdv",latitude:3.25,longitude:73.0,capital:true,major:true,population:341256,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_mex",name:"Mexico City",countryId:"country_real_mex",latitude:23.0,longitude:-102.0,capital:true,major:true,population:119713203,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_mhl",name:"Majuro",countryId:"country_real_mhl",latitude:9.0,longitude:168.0,capital:true,major:true,population:56086,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_mkd",name:"North Macedonia",countryId:"country_real_mkd",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_mli",name:"Bamako",countryId:"country_real_mli",latitude:17.0,longitude:-4.0,capital:true,major:true,population:15768000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_mlt",name:"Valletta",countryId:"country_real_mlt",latitude:35.83333333,longitude:14.58333333,capital:true,major:true,population:416055,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_mmr",name:"Myanmar",countryId:"country_real_mmr",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_mne",name:"Montenegro",countryId:"country_real_mne",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_mng",name:"Ulan Bator",countryId:"country_real_mng",latitude:46.0,longitude:105.0,capital:true,major:true,population:2987733,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_mnp",name:"Saipan",countryId:"country_real_mnp",latitude:15.2,longitude:145.75,capital:true,major:true,population:53883,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_moz",name:"Maputo",countryId:"country_real_moz",latitude:-18.25,longitude:35.0,capital:true,major:true,population:25041922,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_mrt",name:"Nouakchott",countryId:"country_real_mrt",latitude:20.0,longitude:-12.0,capital:true,major:true,population:3545620,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_msr",name:"Plymouth",countryId:"country_real_msr",latitude:16.75,longitude:-62.2,capital:true,major:true,population:4922,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_mtq",name:"Fort-de-France",countryId:"country_real_mtq",latitude:14.666667,longitude:-61.0,capital:true,major:true,population:386486,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_mus",name:"Port Louis",countryId:"country_real_mus",latitude:-20.28333333,longitude:57.55,capital:true,major:true,population:1261208,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_mwi",name:"Lilongwe",countryId:"country_real_mwi",latitude:-13.5,longitude:34.0,capital:true,major:true,population:15805239,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_mys",name:"Kuala Lumpur",countryId:"country_real_mys",latitude:2.5,longitude:112.5,capital:true,major:true,population:30430500,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_myt",name:"Mamoudzou",countryId:"country_real_myt",latitude:-12.83333333,longitude:45.16666666,capital:true,major:true,population:212645,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_nam",name:"Windhoek",countryId:"country_real_nam",latitude:-22.0,longitude:17.0,capital:true,major:true,population:2113077,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_ncl",name:"Noum\u00e9a",countryId:"country_real_ncl",latitude:-21.5,longitude:165.5,capital:true,major:true,population:268767,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_ner",name:"Niamey",countryId:"country_real_ner",latitude:16.0,longitude:8.0,capital:true,major:true,population:17138707,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_nfk",name:"Kingston",countryId:"country_real_nfk",latitude:-29.03333333,longitude:167.95,capital:true,major:true,population:2302,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_nga",name:"Abuja",countryId:"country_real_nga",latitude:10.0,longitude:8.0,capital:true,major:true,population:178517000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_nic",name:"Managua",countryId:"country_real_nic",latitude:13.0,longitude:-85.0,capital:true,major:true,population:6134270,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_niu",name:"Alofi",countryId:"country_real_niu",latitude:-19.03333333,longitude:-169.86666666,capital:true,major:true,population:1613,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_nld",name:"Amsterdam",countryId:"country_real_nld",latitude:52.5,longitude:5.75,capital:true,major:true,population:16881000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_nor",name:"Oslo",countryId:"country_real_nor",latitude:62.0,longitude:10.0,capital:true,major:true,population:5156450,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_npl",name:"Kathmandu",countryId:"country_real_npl",latitude:28.0,longitude:84.0,capital:true,major:true,population:27646053,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_nru",name:"Yaren",countryId:"country_real_nru",latitude:-0.53333333,longitude:166.91666666,capital:true,major:true,population:10084,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_nzl",name:"Wellington",countryId:"country_real_nzl",latitude:-41.0,longitude:174.0,capital:true,major:true,population:4547900,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_omn",name:"Muscat",countryId:"country_real_omn",latitude:21.0,longitude:57.0,capital:true,major:true,population:4089076,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_pak",name:"Islamabad",countryId:"country_real_pak",latitude:30.0,longitude:70.0,capital:true,major:true,population:188410000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_pan",name:"Panama City",countryId:"country_real_pan",latitude:9.0,longitude:-80.0,capital:true,major:true,population:3713312,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_pcn",name:"Pitcairn",countryId:"country_real_pcn",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_per",name:"Lima",countryId:"country_real_per",latitude:-10.0,longitude:-76.0,capital:true,major:true,population:30814175,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_phl",name:"Manila",countryId:"country_real_phl",latitude:13.0,longitude:122.0,capital:true,major:true,population:100697400,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_plw",name:"Ngerulmud",countryId:"country_real_plw",latitude:7.5,longitude:134.5,capital:true,major:true,population:20901,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_png",name:"Port Moresby",countryId:"country_real_png",latitude:-6.0,longitude:147.0,capital:true,major:true,population:7398500,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_pol",name:"Warsaw",countryId:"country_real_pol",latitude:52.0,longitude:20.0,capital:true,major:true,population:38496000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_pri",name:"San Juan",countryId:"country_real_pri",latitude:18.25,longitude:-66.5,capital:true,major:true,population:3615086,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_prk",name:"Korea, Democratic People's Republic of",countryId:"country_real_prk",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_prt",name:"Lisbon",countryId:"country_real_prt",latitude:39.5,longitude:-8.0,capital:true,major:true,population:10477800,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_pry",name:"Asunci\u00f3n",countryId:"country_real_pry",latitude:-23.0,longitude:-58.0,capital:true,major:true,population:6893727,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_pse",name:"Palestine, State of",countryId:"country_real_pse",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_pyf",name:"Papeet\u0113",countryId:"country_real_pyf",latitude:-15.0,longitude:-140.0,capital:true,major:true,population:268270,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_qat",name:"Doha",countryId:"country_real_qat",latitude:25.5,longitude:51.25,capital:true,major:true,population:2269672,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_reu",name:"Saint-Denis",countryId:"country_real_reu",latitude:-21.15,longitude:55.5,capital:true,major:true,population:840974,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_rou",name:"Bucharest",countryId:"country_real_rou",latitude:46.0,longitude:25.0,capital:true,major:true,population:19942642,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_rus",name:"Moscow",countryId:"country_real_rus",latitude:60.0,longitude:100.0,capital:true,major:true,population:146233000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_rwa",name:"Kigali",countryId:"country_real_rwa",latitude:-2.0,longitude:30.0,capital:true,major:true,population:10996891,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_sau",name:"Riyadh",countryId:"country_real_sau",latitude:25.0,longitude:45.0,capital:true,major:true,population:30770375,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_sdn",name:"Khartoum",countryId:"country_real_sdn",latitude:15.0,longitude:30.0,capital:true,major:true,population:37289406,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_sen",name:"Dakar",countryId:"country_real_sen",latitude:14.0,longitude:-14.0,capital:true,major:true,population:13508715,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_sgp",name:"Singapore",countryId:"country_real_sgp",latitude:1.36666666,longitude:103.8,capital:true,major:true,population:5469700,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_sgs",name:"King Edward Point",countryId:"country_real_sgs",latitude:-54.5,longitude:-37.0,capital:true,major:true,population:30,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_shn",name:"Saint Helena, Ascension and Tristan da Cunha",countryId:"country_real_shn",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_sjm",name:"Longyearbyen",countryId:"country_real_sjm",latitude:78.0,longitude:20.0,capital:true,major:true,population:2562,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_slb",name:"Honiara",countryId:"country_real_slb",latitude:-8.0,longitude:159.0,capital:true,major:true,population:581344,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_sle",name:"Freetown",countryId:"country_real_sle",latitude:8.5,longitude:-11.5,capital:true,major:true,population:6205000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_slv",name:"San Salvador",countryId:"country_real_slv",latitude:13.83333333,longitude:-88.91666666,capital:true,major:true,population:6401240,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_smr",name:"City of San Marino",countryId:"country_real_smr",latitude:43.76666666,longitude:12.41666666,capital:true,major:true,population:32743,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_som",name:"Mogadishu",countryId:"country_real_som",latitude:10.0,longitude:49.0,capital:true,major:true,population:10806000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_spm",name:"Saint-Pierre",countryId:"country_real_spm",latitude:46.83333333,longitude:-56.33333333,capital:true,major:true,population:6081,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_srb",name:"Belgrade",countryId:"country_real_srb",latitude:44.1305021,longitude:16.4284181,capital:true,major:true,population:7186862,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_ssd",name:"Juba",countryId:"country_real_ssd",latitude:7.0,longitude:30.0,capital:true,major:true,population:11384393,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_stp",name:"Sao Tome and Principe",countryId:"country_real_stp",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_sur",name:"Paramaribo",countryId:"country_real_sur",latitude:4.0,longitude:-56.0,capital:true,major:true,population:534189,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_svk",name:"Bratislava",countryId:"country_real_svk",latitude:48.66666666,longitude:19.5,capital:true,major:true,population:5415949,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_svn",name:"Ljubljana",countryId:"country_real_svn",latitude:46.11666666,longitude:14.81666666,capital:true,major:true,population:2064966,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_swe",name:"Stockholm",countryId:"country_real_swe",latitude:62.0,longitude:15.0,capital:true,major:true,population:9737521,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_swz",name:"Eswatini",countryId:"country_real_swz",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_sxm",name:"Sint Maarten (Dutch part)",countryId:"country_real_sxm",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_syc",name:"Victoria",countryId:"country_real_syc",latitude:-4.58333333,longitude:55.66666666,capital:true,major:true,population:89949,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_syr",name:"Damascus",countryId:"country_real_syr",latitude:35.0,longitude:38.0,capital:true,major:true,population:22964324,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_tca",name:"Turks and Caicos Islands",countryId:"country_real_tca",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_tcd",name:"N'Djamena",countryId:"country_real_tcd",latitude:15.0,longitude:19.0,capital:true,major:true,population:13211000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_tgo",name:"Lom\u00e9",countryId:"country_real_tgo",latitude:8.0,longitude:1.16666666,capital:true,major:true,population:6993000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_tha",name:"Bangkok",countryId:"country_real_tha",latitude:15.0,longitude:100.0,capital:true,major:true,population:64871000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_tjk",name:"Dushanbe",countryId:"country_real_tjk",latitude:39.0,longitude:71.0,capital:true,major:true,population:8161000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_tkl",name:"Fakaofo",countryId:"country_real_tkl",latitude:-9.0,longitude:-172.0,capital:true,major:true,population:1411,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_tkm",name:"Ashgabat",countryId:"country_real_tkm",latitude:40.0,longitude:60.0,capital:true,major:true,population:5838064,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_tls",name:"Timor-Leste",countryId:"country_real_tls",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_ton",name:"Nuku'alofa",countryId:"country_real_ton",latitude:-20.0,longitude:-175.0,capital:true,major:true,population:103252,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_tto",name:"Port of Spain",countryId:"country_real_tto",latitude:11.0,longitude:-61.0,capital:true,major:true,population:1328019,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_tun",name:"Tunis",countryId:"country_real_tun",latitude:34.0,longitude:9.0,capital:true,major:true,population:10982754,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_tur",name:"T\u00fcrkiye",countryId:"country_real_tur",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_tuv",name:"Funafuti",countryId:"country_real_tuv",latitude:-8.0,longitude:178.0,capital:true,major:true,population:11323,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_twn",name:"Taiwan, Province of China",countryId:"country_real_twn",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_tza",name:"Tanzania, United Republic of",countryId:"country_real_tza",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_uga",name:"Kampala",countryId:"country_real_uga",latitude:1.0,longitude:32.0,capital:true,major:true,population:34856813,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_ukr",name:"Kiev",countryId:"country_real_ukr",latitude:49.0,longitude:32.0,capital:true,major:true,population:42973696,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_umi",name:"United States Minor Outlying Islands",countryId:"country_real_umi",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_ury",name:"Montevideo",countryId:"country_real_ury",latitude:-33.0,longitude:-56.0,capital:true,major:true,population:3404189,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_usa",name:"Washington D.C.",countryId:"country_real_usa",latitude:38.0,longitude:-97.0,capital:true,major:true,population:319259000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_uzb",name:"Tashkent",countryId:"country_real_uzb",latitude:41.0,longitude:64.0,capital:true,major:true,population:30492800,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_vat",name:"Holy See (Vatican City State)",countryId:"country_real_vat",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_vct",name:"Kingstown",countryId:"country_real_vct",latitude:13.25,longitude:-61.2,capital:true,major:true,population:109000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_ven",name:"Venezuela, Bolivarian Republic of",countryId:"country_real_ven",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_vgb",name:"Virgin Islands, British",countryId:"country_real_vgb",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_vir",name:"Virgin Islands, U.S.",countryId:"country_real_vir",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_vnm",name:"Viet Nam",countryId:"country_real_vnm",latitude:0.0,longitude:0.0,capital:true,major:true,population:1000000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_vut",name:"Port Vila",countryId:"country_real_vut",latitude:-16.0,longitude:167.0,capital:true,major:true,population:264652,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_wlf",name:"Mata-Utu",countryId:"country_real_wlf",latitude:-13.3,longitude:-176.2,capital:true,major:true,population:13135,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_wsm",name:"Apia",countryId:"country_real_wsm",latitude:-13.58333333,longitude:-172.33333333,capital:true,major:true,population:187820,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_yem",name:"Sana'a",countryId:"country_real_yem",latitude:15.0,longitude:48.0,capital:true,major:true,population:25956000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_zaf",name:"Pretoria",countryId:"country_real_zaf",latitude:-29.0,longitude:24.0,capital:true,major:true,population:54002000,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_zmb",name:"Lusaka",countryId:"country_real_zmb",latitude:-15.0,longitude:30.0,capital:true,major:true,population:15023315,industrial:false,military:false,morale:65,development:3,updatedAt:now()},
  {id:"city_cap_zwe",name:"Harare",countryId:"country_real_zwe",latitude:-20.0,longitude:30.0,capital:true,major:true,population:13061239,industrial:false,military:false,morale:65,development:3,updatedAt:now()}
];
strategyCities.push(...realWorldCapitalCities);
for (const city of strategyCities) city.controllerCountryId = countries.get(city.countryId)?.controllerCountryId || city.countryId;

const strategyTerritories = strategyCities.map((c,i)=>({
  id:`territory_${i+1}`, name:c.name, countryId:countries.get(c.countryId)?.controllerCountryId || c.countryId, originalCountryId:c.countryId, controllerCountryId:countries.get(c.countryId)?.controllerCountryId || c.countryId, cityId:c.id, population:c.population,
  strategicValue:c.capital?10:5, contested:false, occupied:false, controlPercentage:100, morale:c.morale,
  resistance: countries.get(c.countryId)?.occupationResistance || 0,
  resources:{food:Math.max(1,Math.round(c.population/100000)), oil:c.name.match(/Moscow|Cairo|Tehran|Los Angeles|Riyadh|Baghdad/)?120:25, steel:Math.max(1,Math.round(c.population/400000)), electronics:c.industrial?35:10},
  updatedAt:now()
}));
for (const u of units.values()) normalizeUnit(u);


// ─── global transportation network ───────────────────────
// These are gameplay routes layered over the supplied alternate-history map.
// Roads connect nearby land cities; sea routes connect major coastal hubs; air routes
// connect the world's principal capitals. They are visual + gameplay infrastructure.
for (const u of units.values()) { normalizeUnit(u); initializeHitPoints(u); }

const PORT_COUNTRY_CODES = new Set([
  "USA","CAN","MEX","BRA","ARG","CHL","PER","COL","ECU","PAN","CUB","DOM",
  "GBR","IRL","FRA","ESP","PRT","NLD","BEL","DEU","DNK","NOR","SWE","FIN",
  "ISL","RUS","POL","UKR","TUR","GRC","ITA","HRV","SVN","ALB","ROU","BGR",
  "MAR","DZA","TUN","LBY","EGY","ZAF","NAM","AGO","NGA","GHA","CIV","SEN",
  "KEN","TZA","MOZ","MDG","SAU","ARE","OMN","YEM","IND","PAK","BGD","LKA",
  "THA","VNM","MYS","SGP","IDN","PHL","CHN","TWN","KOR","JPN","AUS","NZL",
  "PNG","FJI"
]);
const AIR_HUB_CODES = new Set([
  "USA","CAN","MEX","BRA","ARG","GBR","FRA","DEU","ESP","ITA","NLD","RUS","POL",
  "UKR","TUR","EGY","ZAF","NGA","KEN","SAU","ARE","IND","PAK","BGD","THA","SGP",
  "MYS","IDN","VNM","CHN","TWN","KOR","JPN","AUS","NZL","MEX"
]);
function continentBucket(c){
  const lat=Number(c.latitude)||0, lon=Number(c.longitude)||0;
  if(lat < -35) return lon > 110 ? "oceania" : "south-america-africa";
  if(lon < -30 && lat > 5) return "north-america";
  if(lon < -30 && lat <= 5) return "south-america";
  if(lon > 25 && lon < 60 && lat > 0) return "europe-west-asia";
  if(lon >= 60 && lon < 150 && lat > 0) return "asia";
  if(lon >= 150 && lat > -20) return "oceania-asia";
  if(lat < 20 && lon >= -20 && lon <= 55) return "africa";
  if(lat >= 20 && lon <= 25) return "europe";
  return "global";
}
function nearestCitiesFor(from, pool, count, maxKm){
  return pool
    .map(c=>({c,d:haversineKm(cityPoint(from),cityPoint(c))}))
    .filter(x=>x.d>25 && x.d<=maxKm)
    .sort((a,b)=>a.d-b.d)
    .slice(0,count);
}
function buildTransportRoutes(){
  const valid=strategyCities.filter(c=>Number.isFinite(Number(c.latitude))&&Number.isFinite(Number(c.longitude))&&!(Number(c.latitude)===0&&Number(c.longitude)===0));
  const routes=[]; const seen=new Set();
  // Dense road network: nearest 3 same-continent hubs + direct intra-country links.
  for(const from of valid){
    const pool=valid.filter(c=>c.id!==from.id && c.name!==from.name && (c.countryId===from.countryId || continentBucket(c)===continentBucket(from)));
    for(const {c} of nearestCitiesFor(from,pool,3,1800)){
      const key=[from.id,c.id].sort().join(':'); if(seen.has('road:'+key)) continue; seen.add('road:'+key);
      routes.push({id:'road_'+routes.length,type:'road',name:`Road: ${from.name} — ${c.name}`,fromCityId:from.id,toCityId:c.id,from:{latitude:Number(from.latitude),longitude:Number(from.longitude)},to:{latitude:Number(c.latitude),longitude:Number(c.longitude)},distanceKm:Math.round(haversineKm(cityPoint(from),cityPoint(c))),speedKmh:85,style:'solid'});
    }
  }
  // Sea lanes between coastal capitals/major ports. Keep the number readable at map level.
  const ports=valid.filter(c=>PORT_COUNTRY_CODES.has(String(c.countryId||'').replace('country_real_','').toUpperCase()) || PORT_COUNTRY_CODES.has(String(c.code||'').toUpperCase()));
  for(const from of ports){
    for(const {c} of nearestCitiesFor(from,ports,2,6500)){
      const key=[from.id,c.id].sort().join(':'); if(seen.has('sea:'+key)) continue; seen.add('sea:'+key);
      routes.push({id:'sea_'+routes.length,type:'sea',name:`Sea Lane: ${from.name} — ${c.name}`,fromCityId:from.id,toCityId:c.id,from:{latitude:Number(from.latitude),longitude:Number(from.longitude)},to:{latitude:Number(c.latitude),longitude:Number(c.longitude)},distanceKm:Math.round(haversineKm(cityPoint(from),cityPoint(c))),speedKmh:32,style:'dash'});
    }
  }
  // Air corridors: nearest 3 hubs, continent-spanning connections included.
  const hubs=valid.filter(c=>AIR_HUB_CODES.has(String(c.countryId||'').replace('country_real_','').toUpperCase()) || AIR_HUB_CODES.has(String(c.code||'').toUpperCase()));
  for(const from of hubs){
    for(const {c} of nearestCitiesFor(from,hubs,3,10000)){
      const key=[from.id,c.id].sort().join(':'); if(seen.has('air:'+key)) continue; seen.add('air:'+key);
      routes.push({id:'air_'+routes.length,type:'air',name:`Air Corridor: ${from.name} — ${c.name}`,fromCityId:from.id,toCityId:c.id,from:{latitude:Number(from.latitude),longitude:Number(from.longitude)},to:{latitude:Number(c.latitude),longitude:Number(c.longitude)},distanceKm:Math.round(haversineKm(cityPoint(from),cityPoint(c))),speedKmh:780,style:'dot'});
    }
  }
  return routes;
}
const transportRoutes = buildTransportRoutes();


const constructionQueue = [];
const researchProjects = [];
let technologies = [
  {id:"tech_infantry",name:"Modern Infantry Doctrine",category:"military",level:1,cost:500,days:2,prerequisites:[],unlocked:true},
  {id:"tech_armor",name:"Advanced Armor",category:"military",level:2,cost:1200,days:4,prerequisites:["tech_infantry"],unlocked:false},
  {id:"tech_air",name:"Jet Aviation",category:"aviation",level:2,cost:1600,days:5,prerequisites:["tech_infantry"],unlocked:false},
  {id:"tech_naval",name:"Fleet Operations",category:"naval",level:2,cost:1500,days:5,prerequisites:["tech_infantry"],unlocked:false},
  {id:"tech_industry",name:"Industrial Automation",category:"industry",level:1,cost:900,days:3,prerequisites:[],unlocked:false},
  {id:"tech_logistics",name:"Strategic Logistics",category:"logistics",level:2,cost:1100,days:3,prerequisites:["tech_industry"],unlocked:false},
];
technologies = technologies.concat(RESEARCH_BLUEPRINTS.map(x=>({...x,unlocked:false})));
const marketOrders = [];
const unitOrders = [];
const battles = [];
const revolutions = [];
const independenceClaims = [];
const travelOrders = [];
const governments = [];
const governmentCommandStructures = [];
const militaryFormations = [];
const militaryProposals = [];
const travelAgencies = [];
const formationProductionQueue = [];
const diplomaticTreaties = [];
const worldHistory = [];
const playerJobs = [];
const playerNationRoles = [];
const espionageMissions = [];
const intelligenceAgencies = [];
const intelligenceAgencyLimit = 5;
const socialPosts = [];
const directMessages = [];
const coalitions = [];
const coalitionMessages = [];
const startedAt = now();
let tickCount = 0;

// Government and military command hierarchy. These are persistent gameplay roles, not UI-only labels.
const STARTING_GOVERNMENT_COUNTRIES = ["country_gnr","country_gar","country_jps","country_ar"];
for (const countryId of STARTING_GOVERNMENT_COUNTRIES) {
  governmentCommandStructures.push({
    countryId, presidentPlayerId:null, defenseMinisterPlayerId:null, militaryCommanderPlayerId:null,
    militaryPolicy:"defensive_readiness", budget:1000000, updatedAt:now()
  });
}
for (const countryId of STARTING_GOVERNMENT_COUNTRIES) {
  travelAgencies.push({id:id("agency"),countryId,name:`${countries.get(countryId)?.name||countryId} Travel Authority`,type:"civilian",capacity:500,active:true});
  travelAgencies.push({id:id("agency"),countryId,name:`${countries.get(countryId)?.name||countryId} Military Transport Command`,type:"military",capacity:100000,active:true});
}

// Fictional intelligence directorates for the alternate-history game world.
const intelligenceCountrySeeds = [
  ["country_gnr", "Greater Reich Intelligence Directorate"],
  ["country_gar", "Greater Albanian Intelligence Directorate"],
  ["country_jps", "Pacific States Intelligence Directorate"],
  ["country_nz", "American Reich Intelligence Directorate"],
];
for (const [countryId, name] of intelligenceCountrySeeds) intelligenceAgencies.push({id:`agency_${countryId}`,countryId,name,founderPlayerId:null,level:1,capacity:3,counterintelligence:42,active:true,createdAt:now()});

for (const a of countries.keys()) {
  for (const b of countries.keys()) {
    if (a !== b) relations.set(`${a}:${b}`, 0);
  }
}

// ─── persistence (JSON file, survives restarts) ────────────

function ensureDataDir() {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  } catch (_) {}
}

function saveState() {
  try {
    ensureDataDir();
    const payload = {
      version: VERSION,
      savedAt: now(),
      tickCount,
      players: Array.from(players.values()),
      sessions: Array.from(sessions.values()),
      wars,
      companies,
      accounts,
      resources,
      market,
      events,
      relations: Array.from(relations.entries()),
      shopPurchases: Array.from(shopPurchases.entries()),
      playerEntitlements: Array.from(playerEntitlements.entries()),
      strategyCities, strategyTerritories, buildings, constructionQueue, researchProjects, marketOrders, unitOrders, battles, revolutions, independenceClaims, travelOrders, governments, governmentCommandStructures, militaryFormations, militaryProposals, travelAgencies, formationProductionQueue, diplomaticTreaties, worldHistory, playerJobs, playerNationRoles, espionageMissions, intelligenceAgencies, socialPosts, directMessages, coalitions, coalitionMessages, aircraftProduction, units:Array.from(units.values()),
    };
    fs.writeFileSync(PERSIST_FILE, JSON.stringify(payload, null, 0));
  } catch (err) {
    console.error("[persist] save failed:", err.message);
  }
}

function loadState() {
  try {
    if (!fs.existsSync(PERSIST_FILE)) return false;
    const raw = fs.readFileSync(PERSIST_FILE, "utf8");
    const data = JSON.parse(raw);
    if (!data || !Array.isArray(data.players)) return false;
    players.clear();
    playersByEmail.clear();
    sessions.clear();
    for (const p of data.players) {
      players.set(p.id, p);
      if (p.email) playersByEmail.set(p.email.toLowerCase(), p.id);
    }
    for (const s of data.sessions || []) {
      if (s.accessToken && new Date(s.expiresAt) > new Date()) {
        sessions.set(s.accessToken, s);
      }
    }
    if (Array.isArray(data.wars)) wars.splice(0, wars.length, ...data.wars);
    if (Array.isArray(data.companies)) companies.splice(0, companies.length, ...data.companies);
    if (Array.isArray(data.accounts)) accounts.splice(0, accounts.length, ...data.accounts);
    if (Array.isArray(data.resources)) resources = data.resources;
    if (Array.isArray(data.market)) market = data.market;
    if (Array.isArray(data.events)) events = data.events;
    if (Array.isArray(data.relations)) {
      relations.clear();
      for (const [k, v] of data.relations) relations.set(k, v);
    }
    if (Array.isArray(data.shopPurchases)) { shopPurchases.clear(); for (const [k, v] of data.shopPurchases) shopPurchases.set(k, v); }
    if (Array.isArray(data.playerEntitlements)) { playerEntitlements.clear(); for (const [k, v] of data.playerEntitlements) playerEntitlements.set(k, v); }
    if (Array.isArray(data.strategyCities)) strategyCities.splice(0, strategyCities.length, ...data.strategyCities);
    if (Array.isArray(data.strategyTerritories)) strategyTerritories.splice(0, strategyTerritories.length, ...data.strategyTerritories);
    if (Array.isArray(data.buildings)) buildings.splice(0, buildings.length, ...data.buildings);
    if (Array.isArray(data.constructionQueue)) constructionQueue.splice(0, constructionQueue.length, ...data.constructionQueue);
    if (Array.isArray(data.researchProjects)) researchProjects.splice(0, researchProjects.length, ...data.researchProjects);
    if (Array.isArray(data.marketOrders)) marketOrders.splice(0, marketOrders.length, ...data.marketOrders);
    if (Array.isArray(data.unitOrders)) unitOrders.splice(0, unitOrders.length, ...data.unitOrders);
    if (Array.isArray(data.units)) { units.clear(); for (const u of data.units) units.set(u.id, initializeHitPoints(normalizeUnit(u))); }
    if (Array.isArray(data.aircraftProduction)) aircraftProduction.splice(0, aircraftProduction.length, ...data.aircraftProduction);
    if (Array.isArray(data.battles)) battles.splice(0, battles.length, ...data.battles);
    if (Array.isArray(data.revolutions)) revolutions.splice(0, revolutions.length, ...data.revolutions);
    if (Array.isArray(data.independenceClaims)) independenceClaims.splice(0, independenceClaims.length, ...data.independenceClaims);
    if (Array.isArray(data.travelOrders)) travelOrders.splice(0, travelOrders.length, ...data.travelOrders);
    if (Array.isArray(data.governments)) governments.splice(0, governments.length, ...data.governments);
    if (Array.isArray(data.governmentCommandStructures)) governmentCommandStructures.splice(0, governmentCommandStructures.length, ...data.governmentCommandStructures);
    if (Array.isArray(data.militaryFormations)) militaryFormations.splice(0, militaryFormations.length, ...data.militaryFormations);
    if (Array.isArray(data.militaryProposals)) militaryProposals.splice(0, militaryProposals.length, ...data.militaryProposals);
    if (Array.isArray(data.travelAgencies)) travelAgencies.splice(0, travelAgencies.length, ...data.travelAgencies);
    if (Array.isArray(data.formationProductionQueue)) formationProductionQueue.splice(0, formationProductionQueue.length, ...data.formationProductionQueue);
    if (Array.isArray(data.diplomaticTreaties)) diplomaticTreaties.splice(0, diplomaticTreaties.length, ...data.diplomaticTreaties);
    if (Array.isArray(data.worldHistory)) worldHistory.splice(0, worldHistory.length, ...data.worldHistory);
    if (Array.isArray(data.playerJobs)) playerJobs.splice(0, playerJobs.length, ...data.playerJobs);
    if (Array.isArray(data.playerNationRoles)) playerNationRoles.splice(0, playerNationRoles.length, ...data.playerNationRoles);
    if (Array.isArray(data.espionageMissions)) espionageMissions.splice(0, espionageMissions.length, ...data.espionageMissions);
    if (Array.isArray(data.intelligenceAgencies)) intelligenceAgencies.splice(0, intelligenceAgencies.length, ...data.intelligenceAgencies);
    if (Array.isArray(data.socialPosts)) socialPosts.splice(0, socialPosts.length, ...data.socialPosts);
    if (Array.isArray(data.directMessages)) directMessages.splice(0, directMessages.length, ...data.directMessages);
    if (Array.isArray(data.coalitions)) coalitions.splice(0, coalitions.length, ...data.coalitions);
    if (Array.isArray(data.coalitionMessages)) coalitionMessages.splice(0, coalitionMessages.length, ...data.coalitionMessages);
    if (typeof data.tickCount === "number") tickCount = data.tickCount;
    console.log(`[persist] loaded ${players.size} players, ${sessions.size} sessions from disk`);
    return true;
  } catch (err) {
    console.error("[persist] load failed:", err.message);
    return false;
  }
}

loadState();
// autosave every 30s
setInterval(saveState, 30_000);

function publicPlayer(p) {
  return {
    id: p.id,
    playerId: p.id,
    username: p.username,
    displayName: p.displayName,
    email: p.email,
    emailVerified: p.emailVerified,
    profileImageUrl: p.profileImageUrl,
    countryId: p.countryId,
    nationalityCountryId: p.nationalityCountryId,
    rank: p.rank,
    level: p.level,
    experience: p.experience,
    prestige: p.prestige,
    reputation: p.reputation,
    wealth: p.wealth,
    currency: p.currency,
    status: p.status,
    career: p.career,
    biography: p.biography,
    currentCityId: p.currentCityId || null,
    travelStatus: p.travelStatus || "stationary",
    travelDestinationCityId: p.travelDestinationCityId || null,
    createdAt: p.createdAt,
    lastLoginAt: p.lastLoginAt,
  };
}

function authUser(p) {
  return {
    playerId: p.id,
    email: p.email,
    emailVerified: p.emailVerified,
    displayName: p.displayName,
    profileImageUrl: p.profileImageUrl,
    createdAt: p.createdAt,
    lastLoginAt: p.lastLoginAt,
  };
}

function createSession(playerId, deviceId) {
  const session = {
    sessionId: id("sess"),
    playerId,
    accessToken: id("tok"),
    refreshToken: id("ref"),
    expiresAt: new Date(Date.now() + 30 * 86400000).toISOString(),
    createdAt: now(),
    deviceId: deviceId || null,
  };
  sessions.set(session.accessToken, session);
  return session;
}

function getPlayerFromReq(req) {
  const token = getBearer(req);
  if (!token) return null;
  const session = sessions.get(token);
  if (!session) return null;
  if (new Date(session.expiresAt) < new Date()) {
    sessions.delete(token);
    return null;
  }
  const player = players.get(session.playerId);
  if (!player) return null;
  return { player, session };
}


function getActiveOrder(unitId){ return unitOrders.find(o=>o.unitId===unitId && o.status==='active'); }
function isAirUnit(u){ return ["fighter","interceptor","strike_fighter","ground_attack","naval_fighter","bomber","heavy_bomber","naval_bomber","patrol_aircraft","reconnaissance_aircraft","awacs","transport_aircraft","helicopter","drone"].includes(u.type); }
function isNavalUnit(u){ return ["frigate","destroyer","cruiser","carrier","submarine","landing_ship","transport_ship","corvette"].includes(u.type); }
function isGroundUnit(u){ return !isAirUnit(u) && !isNavalUnit(u); }
const COASTAL_CITY_NAMES = new Set([
  "San Francisco","Los Angeles","New York","Washington D.C.","Miami","Boston","Seattle","Vancouver","Montreal","Havana","Rio de Janeiro","Buenos Aires","Lima","Santiago","Panama City","London","Dublin","Paris","Amsterdam","Brussels","Copenhagen","Oslo","Stockholm","Helsinki","Reykjavik","Lisbon","Madrid","Rome","Athens","Istanbul","Tirana","Berlin","Warsaw","Kyiv","Moscow","Cairo","Tripoli","Tunis","Algiers","Rabat","Dakar","Lagos","Accra","Luanda","Cape Town","Pretoria","Nairobi","Mogadishu","Jeddah","Riyadh","Abu Dhabi","Muscat","Karachi","Mumbai","Colombo","Dhaka","Bangkok","Singapore","Jakarta","Manila","Hong Kong","Shanghai","Beijing","Seoul","Tokyo","Sydney","Melbourne","Auckland","Wellington","Honolulu","Taipei","Hanoi","Ho Chi Minh City","Kolkata","Chennai","Kochi","Alexandria","Casablanca","Durban","Maputo","Dar es Salaam"]);
function isCoastalCity(city){ if(!city) return false; if(city.isCoastal===true) return true; return COASTAL_CITY_NAMES.has(city.name); }
function targetCityForUnit(u){ return strategyCities.find(c=>c.id===u.currentCityId) || strategyCities.find(c=>c.name===u.location); }
function airRangeKm(type){ return ({fighter:900,interceptor:1000,strike_fighter:1100,ground_attack:850,naval_fighter:1200,bomber:1600,heavy_bomber:2200,naval_bomber:1400,patrol_aircraft:1500,reconnaissance_aircraft:1500,awacs:1800,helicopter:350,drone:700,transport_aircraft:1200}[type]||700); }
function navalRangeKm(type){ return ({corvette:250,frigate:500,destroyer:700,cruiser:1000,carrier:900,submarine:800,landing_ship:300,transport_ship:500}[type]||400); }
function unitCombatPower(u, defending=false){
  const type=u.type||'infantry';
  const base=(defending?UNIT_DEFENSE[type]:UNIT_ATTACK[type])||30;
  const sizeFactor=Math.min(2.2, Math.max(0.25,(u.size||0)/5000));
  const readiness=(u.readiness||80)/100, morale=(u.morale||70)/100, supply=(u.supply||70)/100, health=(u.health||100)/100;
  const entrench=defending ? 1+(u.entrenchment||0)/100 : 1;
  return Math.max(1, Math.round(base*sizeFactor*readiness*morale*supply*health*entrench));
}
function startUnitOrder(unit, body, playerId){
  const orderType=String(body.orderType||'move').toLowerCase();
  const allowed=['move','attack','defend','retreat','patrol','recon','support','fortify','transport','air_patrol','air_strike','intercept','naval_bombard','naval_patrol','amphibious_assault'];
  if(!allowed.includes(orderType)) throw Object.assign(new Error('Unsupported military order.'),{status:400,code:'validation_error'});
  const airOrder=['air_patrol','air_strike','intercept'].includes(orderType);
  const navalOrder=['naval_bombard','naval_patrol','amphibious_assault'].includes(orderType);
  if(airOrder && !isAirUnit(unit)) throw Object.assign(new Error('This order requires an air unit.'),{status:400,code:'invalid_unit_type'});
  if(navalOrder && !isNavalUnit(unit)) throw Object.assign(new Error('This order requires a naval unit.'),{status:400,code:'invalid_unit_type'});
  let targetUnit=null; if(body.targetUnitId) targetUnit=units.get(body.targetUnitId);
  let targetBuilding=null; if(body.targetBuildingId) targetBuilding=buildings.find(b=>b.id===body.targetBuildingId);
  if(targetBuilding){ const city=strategyCities.find(c=>c.id===targetBuilding.cityId); if(!city) throw Object.assign(new Error("Building city not found."),{status:404,code:"not_found"}); if((city.controllerCountryId||city.countryId)===unit.countryId) throw Object.assign(new Error("Cannot attack a friendly building."),{status:409,code:"conflict"}); if(!["bomber","heavy_bomber","strike_fighter","ground_attack"].includes(unit.type)) throw Object.assign(new Error("This aircraft is not optimized for building strikes."),{status:400,code:"invalid_unit_role"}); }
  if(targetUnit && targetUnit.countryId===unit.countryId && ['attack','air_strike','intercept','naval_bombard'].includes(orderType)) throw Object.assign(new Error('Cannot attack a friendly unit.'),{status:409,code:'conflict'});
  if(['air_strike','air_patrol'].includes(orderType) && targetUnit && !isGroundUnit(targetUnit)) throw Object.assign(new Error('Air-to-ground orders require a ground target.'),{status:400,code:'invalid_target'});
  if(orderType==='intercept' && (!targetUnit || !isAirUnit(targetUnit))) throw Object.assign(new Error('Intercept requires an enemy aircraft target.'),{status:400,code:'invalid_target'});
  let destination=null, destinationCityId=body.destinationCityId||null, destinationName=body.destinationName||body.targetName||null;
  if(destinationCityId){ const city=strategyCities.find(c=>c.id===destinationCityId); if(!city) throw Object.assign(new Error('Destination city not found.'),{status:404,code:'not_found'}); if(orderType==='naval_bombard' && !isCoastalCity(city)) throw Object.assign(new Error('Naval bombardment requires a coastal city.'),{status:400,code:'not_coastal'}); destination=cityPoint(city); destinationName=city.name; }
  if(targetUnit){ destination=targetUnit.position; destinationName=targetUnit.location||targetUnit.name; }
  if(targetBuilding && !targetUnit){ const city=strategyCities.find(c=>c.id===targetBuilding.cityId); destination=cityPoint(city); destinationCityId=city?.id||null; destinationName=city?.name||"Building"; }
  if(body.destination && typeof body.destination.latitude==='number' && typeof body.destination.longitude==='number'){ destination={latitude:body.destination.latitude,longitude:body.destination.longitude}; }
  if(!destination && orderType==='retreat'){ const c=findNearestFriendlyCity(unit); if(c){destination=cityPoint(c);destinationCityId=c.id;destinationName=c.name;} }
  if(!destination) throw Object.assign(new Error('A destination or target is required.'),{status:400,code:'validation_error'});
  const from=unit.position || {latitude:0,longitude:0};
  const distanceKm=Math.max(1,haversineKm(from,destination));
  if(airOrder && distanceKm>airRangeKm(unit.type) && !targetUnit) throw Object.assign(new Error(`Target is outside ${Math.round(airRangeKm(unit.type))} km aircraft range.`),{status:400,code:'out_of_range'});
  if(navalOrder && distanceKm>navalRangeKm(unit.type) && !targetUnit) throw Object.assign(new Error(`Target is outside ${Math.round(navalRangeKm(unit.type))} km naval range.`),{status:400,code:'out_of_range'});
  const speed=Math.max(1,UNIT_SPEED_KMH[unit.type]||30)*(unit.supply<30?0.65:unit.supply<60?0.82:1);
  const etaSeconds=Math.max(5,Math.round(distanceKm/speed*3600));
  const created=Date.now();
  const order={id:id('order'),unitId:unit.id,playerId:playerId,orderType,destinationName:destinationName||'Target',destinationCityId,targetUnitId:targetUnit?.id||null,targetBuildingId:targetBuilding?.id||body.targetBuildingId||null,targetTerritoryId:body.targetTerritoryId||null,destination,origin:{...from},route:makeRoute(from,destination,Math.min(24,Math.max(4,Math.round(distanceKm/180)))),distanceKm,speedKmh:Math.round(speed*10)/10,etaSeconds,startedAt:new Date(created).toISOString(),arrivalAt:new Date(created+etaSeconds*1000).toISOString(),progress:0,status:'active',createdAt:new Date(created).toISOString(),cancelled:false,tracking:!!targetUnit,rangeKm:airOrder?airRangeKm(unit.type):navalOrder?navalRangeKm(unit.type):null};
  const old=getActiveOrder(unit.id); if(old){old.status='cancelled';old.cancelled=true;old.completedAt=now();}
  unitOrders.push(order); unit.destination=destination; unit.route=order.route; unit.activeOrderId=order.id; unit.orderStatus=orderType; unit.status=['attack','air_strike','intercept','naval_bombard','amphibious_assault'].includes(orderType)?'attacking':orderType==='air_patrol'||orderType==='naval_patrol'||orderType==='patrol'?'patrol':orderType==='defend'||orderType==='fortify'?'defending':orderType==='retreat'?'retreating':'moving'; unit.entrenchment=0;
  return order;
}
function finishUnitOrder(unit, order){
  const dest=order.destination; if(dest) unit.position={...dest};
  unit.destination=null; unit.route=[]; unit.activeOrderId=null; order.progress=100; order.status='completed'; order.completedAt=now();
  if(order.destinationCityId){ const city=strategyCities.find(c=>c.id===order.destinationCityId); if(city){unit.currentCityId=city.id;unit.location=city.name; if(order.orderType==='defend'||order.orderType==='fortify') unit.garrisonedCityId=city.id;} }
  unit.orderStatus=['attack','air_strike','intercept','naval_bombard','amphibious_assault'].includes(order.orderType)?'attacking':(order.orderType==='air_patrol'||order.orderType==='naval_patrol'||order.orderType==='patrol'?'patrol':(order.orderType==='defend'||order.orderType==='fortify'?'garrisoned':'idle'));
  unit.status=['attack','air_strike','intercept','naval_bombard','amphibious_assault'].includes(order.orderType)?'attacking':(order.orderType==='air_patrol'||order.orderType==='naval_patrol'||order.orderType==='patrol'?'patrol':(order.orderType==='defend'||order.orderType==='fortify'?'defending':'ready'));
  if(order.orderType==='fortify'||order.orderType==='defend') unit.entrenchment=Math.min(50,(unit.entrenchment||0)+25);
}
function createBattleForUnitAttack(unit, order){
  let targetUnit=order.targetUnitId?units.get(order.targetUnitId):null;
  let targetTerritory=order.targetTerritoryId?strategyTerritories.find(t=>t.id===order.targetTerritoryId):null;
  if(!targetTerritory && order.destinationCityId) targetTerritory=strategyTerritories.find(t=>t.cityId===order.destinationCityId);
  if(targetUnit && targetUnit.countryId!==unit.countryId){
    const existing=battles.find(b=>b.status==='active' && ((b.attackerUnitIds||[]).includes(unit.id) || (b.defenderUnitIds||[]).includes(unit.id)) && ((b.attackerUnitIds||[]).includes(targetUnit.id)||(b.defenderUnitIds||[]).includes(targetUnit.id)));
    if(existing) return existing;
    const war=wars.find(w=>w.status==='active' && ((w.attackerCountryId===unit.countryId&&w.defenderCountryId===targetUnit.countryId)||(w.defenderCountryId===unit.countryId&&w.attackerCountryId===targetUnit.countryId)));
    if(!war) return null;
    const b={id:id('battle'),warId:war.id,territoryId:targetUnit.currentTerritoryId||null,location:targetUnit.location||'Field',locationPoint:{...targetUnit.position},attackerCountryId:unit.countryId,defenderCountryId:targetUnit.countryId,attackerUnitIds:[unit.id],defenderUnitIds:[targetUnit.id],attackerStrength:unitCombatPower(unit,false),defenderStrength:unitCombatPower(targetUnit,true),progress:0,status:'active',createdAt:now(),startedAt:now(),updatedAt:now(),attackerMorale:unit.morale,defenderMorale:targetUnit.morale,intensity:50};
    battles.push(b); unit.status='attacking'; targetUnit.status='engaged'; return b;
  }
  if(targetTerritory && targetTerritory.controllerCountryId!==unit.countryId){
    const enemy= [...units.values()].filter(u=>u.countryId===targetTerritory.controllerCountryId && u.position && targetTerritory.cityId===u.currentCityId).sort((a,b)=>unitCombatPower(b,true)-unitCombatPower(a,true))[0];
    if(enemy){ order.targetUnitId=enemy.id; return createBattleForUnitAttack(unit,order); }
    const war=wars.find(w=>w.status==='active' && ((w.attackerCountryId===unit.countryId&&w.defenderCountryId===targetTerritory.controllerCountryId)||(w.defenderCountryId===unit.countryId&&w.attackerCountryId===targetTerritory.controllerCountryId)));
    if(!war) return null;
    const b={id:id('battle'),warId:war.id,territoryId:targetTerritory.id,location:targetTerritory.name,locationPoint:{...unit.position},attackerCountryId:unit.countryId,defenderCountryId:targetTerritory.controllerCountryId,attackerUnitIds:[unit.id],defenderUnitIds:[],attackerStrength:unitCombatPower(unit,false),defenderStrength:Math.max(100,Math.round((countries.get(targetTerritory.controllerCountryId)?.militaryStrength||30)*8)),progress:0,status:'active',createdAt:now(),startedAt:now(),updatedAt:now(),attackerMorale:unit.morale,defenderMorale:targetTerritory.morale||60,intensity:60};
    battles.push(b); targetTerritory.contested=true; unit.status='attacking'; return b;
  }
  return null;
}
function createSpecializedAirNavalBattle(unit, order){
  const targetUnit=order.targetUnitId?units.get(order.targetUnitId):null;
  const targetCity=order.destinationCityId?strategyCities.find(c=>c.id===order.destinationCityId):null;
  const targetBuilding=order.targetBuildingId?buildings.find(b=>b.id===order.targetBuildingId):null;
  const targetCountryId=targetUnit?.countryId || (targetBuilding && targetCity ? (targetCity.controllerCountryId||targetCity.countryId) : null) || targetCity?.controllerCountryId || targetCity?.countryId;
  if(!targetCountryId || targetCountryId===unit.countryId) return null;
  const war=wars.find(w=>w.status==='active' && ((w.attackerCountryId===unit.countryId&&w.defenderCountryId===targetCountryId)||(w.defenderCountryId===unit.countryId&&w.attackerCountryId===targetCountryId)));
  if(!war) return null;
  const existing=battles.find(b=>b.status==='active' && (b.attackerUnitIds||[]).includes(unit.id) && (b.targetUnitId===targetUnit?.id || b.targetCityId===targetCity?.id));
  if(existing) return existing;
  const air= isAirUnit(unit); const naval=isNavalUnit(unit);
  const targetPower=targetUnit?unitCombatPower(targetUnit,true):targetBuilding?Math.max(80,Math.round((targetBuilding.level||1)*120)):Math.max(120,Math.round((countries.get(targetCountryId)?.militaryStrength||30)*10));
  const b={id:id('battle'),warId:war.id,territoryId:targetCity?strategyTerritories.find(t=>t.cityId===targetCity.id)?.id:null,location:targetUnit?.location||targetCity?.name||'Target',locationPoint:{...(targetUnit?.position||cityPoint(targetCity)||unit.position)},attackerCountryId:unit.countryId,defenderCountryId:targetCountryId,attackerUnitIds:[unit.id],defenderUnitIds:targetUnit?[targetUnit.id]:[],targetUnitId:targetUnit?.id||null,targetBuildingId:targetBuilding?.id||null,targetCityId:targetCity?.id||null,combatDomain:air?'air':naval?'naval':'ground',attackerStrength:unitCombatPower(unit,false),defenderStrength:targetPower,progress:0,status:'active',createdAt:now(),startedAt:now(),updatedAt:now(),intensity:air?70:naval?65:60};
  b.effectiveness=effectivenessFor(unit,targetUnit || (targetBuilding ? {__building:true,type:"ground"} : (targetCity ? {type:"ground"} : {})));
  b.damageModel={attackerRole:blueprintFor(unit.type)?.role || "general",targetRole:targetUnit ? blueprintFor(targetUnit.type)?.role || targetClassFor(targetUnit) : "city"};
  battles.push(b); unit.status='attacking'; if(targetUnit) targetUnit.status='engaged';
  events.unshift({id:id('evt'),title:air?`Air strike: ${b.location}`:`Naval attack: ${b.location}`,description:`${unit.name} engaged a ${air?'ground/air':'coastal'} target.`,type:'military',timestamp:now(),countryIds:[unit.countryId,targetCountryId]});
  return b;
}

function resolveMilitaryBattles(){
  for(const b of battles){
    if(b.status!=='active') continue;
    const attackers=(b.attackerUnitIds||[]).map(id=>units.get(id)).filter(Boolean);
    const defenders=(b.defenderUnitIds||[]).map(id=>units.get(id)).filter(Boolean);
    b.attackerStrength=Math.max(1,attackers.reduce((s,u)=>s+unitCombatPower(u,false),0) || b.attackerStrength || 1);
    b.defenderStrength=Math.max(1,defenders.reduce((s,u)=>s+unitCombatPower(u,true),0) || b.defenderStrength || 1);
    const multiplier=(b.combatDomain==='air'?1.35:b.combatDomain==='naval'?1.18:1) * Math.max(0.1,Number(b.effectiveness)||1);
    const aDamage=Math.max(1,Math.round(b.defenderStrength*(0.008+Math.random()*0.012)*multiplier));
    const dDamage=Math.max(1,Math.round(b.attackerStrength*(0.007+Math.random()*0.011)));
    for(const u of attackers){initializeHitPoints(u); const hpLoss=Math.max(1,Math.round(dDamage/Math.max(1,attackers.length)*10)); u.hitPoints=Math.max(0,u.hitPoints-hpLoss); u.health=Math.max(0,Math.round((u.hitPoints/u.maxHitPoints)*100)); u.size=Math.max(0,Math.round((u.hitPoints/Math.max(1,u.maxHitPoints))*(u.originalSize||u.size)));u.originalSize=u.originalSize||u.size;u.supply=Math.max(0,u.supply-0.5);u.ammunition=Math.max(0,(u.ammunition??100)-0.8);}
    if(b.targetBuildingId){ const building=buildings.find(x=>x.id===b.targetBuildingId); if(building){ building.integrity=Math.max(0,Number(building.integrity==null?100:building.integrity)-Math.max(1,Math.round(aDamage/20))); building.lastDamagedAt=now(); if(building.integrity<=0){ building.destroyed=true; building.integrity=0; } } }
    for(const u of defenders){initializeHitPoints(u); const hpLoss=Math.max(1,Math.round(aDamage/Math.max(1,defenders.length)*10)); u.hitPoints=Math.max(0,u.hitPoints-hpLoss); u.health=Math.max(0,Math.round((u.hitPoints/u.maxHitPoints)*100));u.size=Math.max(0,Math.round((u.hitPoints/Math.max(1,u.maxHitPoints))*(u.originalSize||u.size)));u.originalSize=u.originalSize||u.size;u.supply=Math.max(0,u.supply-0.7);u.ammunition=Math.max(0,(u.ammunition??100)-1);}
    b.attackerStrength=Math.max(0,b.attackerStrength-aDamage); b.defenderStrength=Math.max(0,b.defenderStrength-dDamage);
    b.progress=Math.min(100,b.progress+Math.max(2,Math.round((b.attackerStrength/(b.attackerStrength+b.defenderStrength))*5)));
    b.updatedAt=now();
    if(b.progress>=100 || b.attackerStrength<=50 || b.defenderStrength<=50){
      const attackerWon=b.attackerStrength>b.defenderStrength; b.status=attackerWon?'attacker_won':'defender_won'; b.endedAt=now(); b.winnerCountryId=attackerWon?b.attackerCountryId:b.defenderCountryId;
      const winner=b.winnerCountryId;
      for(const u of attackers.concat(defenders)){ if(u.status==='engaged'||u.status==='attacking') u.status=u.countryId===winner?'ready':'retreating'; }
      if(b.territoryId && attackerWon){
        const t=strategyTerritories.find(x=>x.id===b.territoryId); if(t){t.controllerCountryId=winner;t.countryId=winner;t.controlPercentage=100;t.contested=false;t.occupied=winner!==t.originalCountryId;t.updatedAt=now();const c=strategyCities.find(x=>x.id===t.cityId);if(c)c.controllerCountryId=winner;}
      }
      const war=wars.find(w=>w.id===b.warId); if(war){ war.warScore=(war.warScore||0)+(attackerWon?15:-15); war.updatedAt=now(); }
      worldHistory.unshift({id:id('hist'),type:'battle',title:`Battle ended: ${winner}`,description:`${b.location} — ${b.status}`,timestamp:now(),countryIds:[b.attackerCountryId,b.defenderCountryId]});
      events.unshift({id:id('evt'),title:`Battle ended at ${b.location}`,description:`${winner} won the engagement.`,type:'military',timestamp:now(),countryIds:[b.attackerCountryId,b.defenderCountryId]});
    }
  }
}
function advanceTick() {
  tickCount += 1;
  resources = resources.map((r) => {
    const delta = r.production - r.consumption;
    const next = Math.max(0, r.amount + delta);
    return { ...r, amount: Math.round(next * 100) / 100 };
  });
  // Military upkeep: fielded formations consume fuel/ammunition/supply and national treasury.
  for (const u of units.values()) {
    const c=countries.get(u.countryId);
    const upkeep=Math.max(1,Math.round((u.size||0)*0.01));
    if(c) c.treasury=Math.max(0,(c.treasury||0)-upkeep);
  }

  // Real-time aircraft/naval production. Finished units enter the same authoritative unit map.
  for (const q of aircraftProduction) {
    if (q.status !== "active") continue;
    const bp=blueprintFor(q.type);
    const duration=Math.max(1,Number(bp?.buildSeconds||300)*1000*Math.max(1,q.quantity));
    q.progress=Math.min(100,((Date.now()-new Date(q.startedAt).getTime())/duration)*100);
    if(q.progress>=100){
      q.progress=100; q.completed=q.quantity; q.status="completed";
      const city=strategyCities.find(c=>c.id===q.cityId);
      const u=normalizeUnit({id:id("unit"),countryId:q.countryId,type:q.type,name:`${bp?.displayName||q.type} Squadron`,size:q.quantity,originalSize:q.quantity,location:city?.name||"Airbase",currentCityId:q.cityId,morale:90,supply:100,status:"ready",ownerPlayerId:q.playerId});
      initializeHitPoints(u); units.set(u.id,u);
      events.unshift({id:id("evt"),title:`Production complete: ${bp?.displayName||q.type}`,description:`${q.quantity} ${bp?.displayName||q.type} ready at ${city?.name||"base"}.`,type:"military",timestamp:now(),countryIds:[q.countryId]});
    }
  }

  // Approved military formation production. Completed formations receive real units and become active.
  for(const q of formationProductionQueue){
    if(q.status!=="active") continue;
    const duration=Math.max(30,Number(q.durationSeconds)||120)*1000; q.progress=Math.min(100,((Date.now()-new Date(q.startedAt).getTime())/duration)*100);
    if(q.progress>=100){
      q.progress=100; q.status="completed";
      const formation=militaryFormations.find(f=>f.id===q.formationId);
      const city=strategyCities.find(c=>c.id===q.cityId);
      if(formation){
        const size=Math.max(1,Number(q.quantity)||1);
        const u=normalizeUnit({id:id("unit"),countryId:q.countryId,type:q.type,name:`${formation.name} · ${String(q.type).replace(/_/g," ")}`,size,location:city?.name||"Base",currentCityId:q.cityId,formationId:formation.id,commanderPlayerId:formation.commanderPlayerId,ownerPlayerId:formation.commanderPlayerId,morale:85,supply:100,status:"ready"});
        initializeHitPoints(u); units.set(u.id,u); formation.units.push(u.id); formation.status="active"; formation.updatedAt=now();
        events.unshift({id:id("evt"),title:`Formation production complete: ${formation.name}`,description:`${size} ${q.type} assigned to ${formation.name}.`,type:"military",timestamp:now(),countryIds:[q.countryId]});
      }
    }
  }

  // Real-time construction and research progress.
  for (const q of constructionQueue) {
    if (q.status !== "active") continue;
    q.progress = Math.min(100, q.progress + Math.max(1, Math.round(100 / Math.max(20, Number(q.buildTicks)||60))));
    if (q.progress >= 100) {
      q.status = "completed";
      const existing=buildings.find(b=>b.cityId===q.cityId && b.type===q.type && !b.destroyed);
      if(existing) existing.level=Math.min(BUILDING_BLUEPRINTS[q.type]?.maxLevel||5,(existing.level||1)+1);
      else buildings.push({ id:id("bld"), cityId:q.cityId, countryId:q.countryId, type:q.type, level:1, integrity:100, destroyed:false, completedAt:now() });
      events.unshift({id:id("evt"),title:`Construction complete: ${BUILDING_BLUEPRINTS[q.type]?.displayName||q.type}`,description:`${BUILDING_BLUEPRINTS[q.type]?.displayName||q.type} is operational in ${strategyCities.find(c=>c.id===q.cityId)?.name||"city"}.`,type:"construction",timestamp:now(),countryIds:[q.countryId]});
    }
  }
  hospitalHealUnits();

  for (const p of researchProjects) {
    if (p.status !== "active") continue;
    p.progress = Math.min(100, p.progress + 1);
    if (p.progress >= 100) { p.status = "completed"; const tech=technologies.find(t=>t.id===p.technologyId); if(tech){ tech.unlocked=true; (tech.unlocks||[]).forEach(type=>{ if(!tech.unlockedUnits) tech.unlockedUnits=[]; if(!tech.unlockedUnits.includes(type)) tech.unlockedUnits.push(type); }); events.unshift({id:id("evt"),title:`Research complete: ${tech.name}`,description:`New military production capabilities are now available.`,type:"research",timestamp:now(),countryIds:[p.countryId]}); } }
  }

  // Real-time military movement, ETA tracking, garrisoning and supply.
  const tickNow=Date.now();
  for (const u of units.values()) {
    normalizeUnit(u);
    const order=getActiveOrder(u.id);
    if(order){
      const trackingTarget=order.targetUnitId?units.get(order.targetUnitId):null;
      if(order.tracking && trackingTarget && trackingTarget.position){
        order.origin={...u.position}; order.destination={...trackingTarget.position}; order.distanceKm=Math.max(1,haversineKm(order.origin,order.destination));
        const speed=Math.max(1,UNIT_SPEED_KMH[u.type]||30); order.etaSeconds=Math.max(5,Math.round(order.distanceKm/speed*3600)); order.startedAt=new Date(tickNow).toISOString(); order.arrivalAt=new Date(tickNow+order.etaSeconds*1000).toISOString(); order.progress=0; order.route=makeRoute(order.origin,order.destination,Math.min(24,Math.max(4,Math.round(order.distanceKm/180))));
      }
      const total=Math.max(1,new Date(order.arrivalAt).getTime()-new Date(order.startedAt).getTime());
      order.progress=Math.max(0,Math.min(100,((tickNow-new Date(order.startedAt).getTime())/total)*100));
      const t=order.progress/100;
      if(order.destination) u.position={latitude:order.origin.latitude+(order.destination.latitude-order.origin.latitude)*t,longitude:order.origin.longitude+(order.destination.longitude-order.origin.longitude)*t};
      u.destination=order.destination; u.route=order.route; u.supply=Math.max(0,u.supply-(isAirUnit(u)?0.12:0.25)); u.fuel=Math.max(0,(u.fuel??100)-(isAirUnit(u)?0.35:0.15)); u.ammunition=Math.max(0,(u.ammunition??100)-(isAirUnit(u)?0.12:0.03));
      if(order.progress>=100){ finishUnitOrder(u,order); if(order.orderType==='attack') createBattleForUnitAttack(u,order); if(['air_strike','intercept','air_patrol','naval_bombard','naval_patrol','amphibious_assault'].includes(order.orderType)) createSpecializedAirNavalBattle(u,order); }
    } else {
      if(u.status==='defending'||u.status==='garrisoned'){u.entrenchment=Math.min(50,(u.entrenchment||0)+1);u.supply=Math.min(100,u.supply+0.35);u.morale=Math.min(100,u.morale+0.15);} else {u.supply=Math.min(100,u.supply+0.1);}
    }
    u.morale=Math.max(0,Math.min(100,u.morale+(u.supply>60?0.12:-0.35)));
    if(u.supply<20) u.readiness=Math.max(20,(u.readiness||80)-0.4); else u.readiness=Math.min(100,(u.readiness||80)+0.05);
  }
  // Air patrols track enemy ground units and automatically engage when in range; fighters intercept enemy aircraft.
  for(const u of units.values()){
    const o=getActiveOrder(u.id); if(!o || !isAirUnit(u) || !['air_patrol','intercept'].includes(o.orderType)) continue;
    const targets=[...units.values()].filter(t=>t.countryId!==u.countryId && t.position);
    const target= o.targetUnitId ? units.get(o.targetUnitId) : targets.sort((a,b)=>haversineKm(u.position,a.position)-haversineKm(u.position,b.position))[0];
    if(!target || haversineKm(u.position,target.position)>airRangeKm(u.type)) continue;
    o.targetUnitId=target.id; o.destination={...target.position}; o.tracking=true; o.progress=100;
    createSpecializedAirNavalBattle(u,o);
  }
  // Naval formations automatically bombard hostile coastal units/cities inside their range.
  for(const u of units.values()){
    const o=getActiveOrder(u.id); if(!o || !isNavalUnit(u) || !['naval_patrol','naval_bombard'].includes(o.orderType)) continue;
    const target= o.targetUnitId ? units.get(o.targetUnitId) : [...units.values()].filter(t=>t.countryId!==u.countryId && isGroundUnit(t) && targetCityForUnit(t) && isCoastalCity(targetCityForUnit(t)) && t.position).sort((a,b)=>haversineKm(u.position,a.position)-haversineKm(u.position,b.position))[0];
    if(target && haversineKm(u.position,target.position)<=navalRangeKm(u.type)){ o.targetUnitId=target.id; createSpecializedAirNavalBattle(u,o); }
  }
  resolveMilitaryBattles();

  // Resource-sensitive market drift.
  market = market.map((m) => {
    const r = resources.find(x => x.type === ({FOOD:"food",OIL:"oil",STL:"steel",ENR:"energy",TECH:"electronics"}[m.symbol] || ""));
    const pressure = r ? (r.consumption - r.production) / Math.max(1, r.production) : 0;
    const drift = ((Math.random() - 0.5) * 0.8) + pressure * 0.4;
    const next = Math.max(0.1, m.price * (1 + drift / 100));
    return { ...m, price: Math.round(next * 100) / 100, change: Math.round(drift * 10) / 10 };
  });

  // Active battles resolve gradually and can transfer territory.
  for (const b of battles) {
    if (b.status !== "active") continue;
    b.progress = Math.max(0, Math.min(100, b.progress + (Math.random() * 8 - 1)));
    b.attackerStrength = Math.max(0, Math.round(b.attackerStrength * (0.995 + Math.random() * 0.004)));
    b.defenderStrength = Math.max(0, Math.round(b.defenderStrength * (0.995 + Math.random() * 0.004)));
    if (b.progress >= 100 || b.attackerStrength < 100 || b.defenderStrength < 100) {
      b.status = b.attackerStrength > b.defenderStrength ? "attacker_won" : "defender_won";
      const winnerCountryId = b.status === "attacker_won" ? b.attackerCountryId : b.defenderCountryId;
      const loserCountryId = b.status === "attacker_won" ? b.defenderCountryId : b.attackerCountryId;
      const territory = strategyTerritories.find(t => t.id === b.territoryId);
      if (territory) {
        territory.countryId = winnerCountryId;
        territory.controllerCountryId = winnerCountryId;
        territory.controlPercentage = 100;
        territory.contested = false;
        territory.occupied = winnerCountryId !== territory.originalCountryId;
        territory.updatedAt = now();
        const city = strategyCities.find(c => c.id === territory.cityId);
        if (city) city.controllerCountryId = winnerCountryId;
        worldHistory.unshift({id:id("hist"),type:"territory",title:`${territory.name} captured`,description:`${winnerCountryId} defeated ${loserCountryId}.`,timestamp:now(),countryIds:[winnerCountryId,loserCountryId]});
        events.unshift({id:id("evt"),title:`Territory captured: ${territory.name}`,description:`Control transferred to ${winnerCountryId}.`,type:"military",timestamp:now(),countryIds:[winnerCountryId,loserCountryId]});
      }
      const war = wars.find(w => w.id === b.warId);
      if (war && !battles.some(x => x.warId === war.id && x.status === "active")) {
        war.status = "ended";
        war.endedAt = now();
        const wc = countries.get(winnerCountryId); const lc = countries.get(loserCountryId);
        if (wc) wc.status = "peace"; if (lc) lc.status = "peace";
        worldHistory.unshift({id:id("hist"),type:"war_end",title:`War ended: ${wc?.name || winnerCountryId} victory`,description:`The war ended after the battle at ${b.location}.`,timestamp:now(),countryIds:[war.attackerCountryId,war.defenderCountryId]});
      }
    }
  }

  // Persistent player travel. A player remains in transit while offline.
  for (const t of travelOrders) {
    if (t.status !== "active") continue;
    t.progress = Math.min(100, t.progress + 5);
    if (t.progress >= 100) {
      t.status = "completed";
      const p = players.get(t.playerId);
      if (p) {
        p.currentCityId = t.destinationCityId;
        p.travelStatus = "stationary";
        p.travelDestinationCityId = null;
      }
      worldHistory.unshift({id:id("hist"),type:"travel",title:"Player arrived",description:`${p?.displayName || "Player"} arrived in ${t.destinationName}.`,timestamp:now(),countryIds:p?.countryId?[p.countryId]:[]});
    }
  }

  // Jobs pay the player after their server-side duration completes.
  for (const j of playerJobs) {
    if (j.status !== "active") continue;
    j.remainingTicks = Math.max(0, j.remainingTicks - 1);
    if (j.remainingTicks === 0) {
      j.status = "completed";
      const p = players.get(j.playerId);
      if (p) {
        p.wealth += j.salary;
        p.experience += 25;
        p.level = Math.max(1, Math.floor(p.experience / 500) + 1);
        events.unshift({id:id("evt"),title:"Work completed",description:`${j.jobType} paid ${j.salary} GD$.`,type:"economy",timestamp:now(),countryIds:p.countryId?[p.countryId]:[]});
      }
    }
  }

  // Intelligence missions progress on server time. Defenders can detect infiltrators.
  for (const m of espionageMissions) {
    if (m.status !== "active") continue;
    const elapsed = Math.max(0, tickNow - new Date(m.startedAt).getTime());
    const duration = Math.max(30_000, Number(m.durationMs || 90_000));
    m.progress = Math.min(100, Math.floor(elapsed / duration * 100));
    if (m.progress >= 100) {
      const defenders = intelligenceAgencies.filter(a=>a.countryId===m.targetCountryId && a.active);
      const defense = defenders.reduce((n,a)=>n + Number(a.counterintelligence||0), 0);
      const baseRisk = Number(m.risk||20);
      const caughtChance = Math.min(85, Math.max(5, baseRisk + defense*0.35 - 12));
      if (Math.random()*100 < caughtChance) {
        m.status = "caught";
        m.caughtAt = now();
        m.caughtByAgencyId = defenders[0]?.id || null;
        m.result = {message:"Mission compromised by enemy counterintelligence.", targetCountryId:m.targetCountryId};
        events.unshift({id:id("evt"),title:"Intelligence agent caught",description:`A ${m.type} mission was compromised in ${countries.get(m.targetCountryId)?.name||m.targetCountryId}.`,type:"intelligence",timestamp:now(),countryIds:[m.targetCountryId]});
      } else {
        m.status = "completed";
        m.completedAt = now();
        m.result = {stability:countries.get(m.targetCountryId)?.stability||0,militaryStrength:countries.get(m.targetCountryId)?.militaryStrength||0,message:`${m.type} mission completed successfully.`};
        const spyPlayer=players.get(m.playerId);
        if(spyPlayer){spyPlayer.experience=(spyPlayer.experience||0)+50;spyPlayer.prestige=(spyPlayer.prestige||0)+2;spyPlayer.wealth=(spyPlayer.wealth||0)+Math.max(100,Number(m.reward||100));}
        events.unshift({id:id("evt"),title:"Intelligence report received",description:`A ${m.type} mission returned intelligence from ${countries.get(m.targetCountryId)?.name||m.targetCountryId}.`,type:"intelligence",timestamp:now(),countryIds:[m.targetCountryId]});
      }
    }
  }

  // Resistance and revolutions evolve with occupation, morale and economic pressure.
  for (const territory of strategyTerritories) {
    const c = countries.get(territory.originalCountryId);
    if (!c || territory.controllerCountryId === territory.originalCountryId) {
      territory.resistance = Math.max(0, (territory.resistance || 0) - 0.2);
      continue;
    }
    const pressure = territory.morale < 45 ? 0.8 : 0.25;
    territory.resistance = Math.max(0, Math.min(100, (territory.resistance || 0) + pressure));
    if (territory.resistance >= 75 && !revolutions.some(r => r.territoryId === territory.id && r.status === "active")) {
      const rev = {id:id("rev"), territoryId:territory.id, countryId:territory.originalCountryId, cityId:territory.cityId, leaderPlayerId:null, goal:"independence", support:territory.resistance, status:"active", startedAt:now()};
      revolutions.push(rev);
      worldHistory.unshift({id:id("hist"),type:"revolution",title:`Revolt in ${territory.name}`,description:`Local resistance has escalated into an organized uprising.`,timestamp:now(),countryIds:[territory.originalCountryId,territory.controllerCountryId]});
      events.unshift({id:id("evt"),title:`Revolution in ${territory.name}`,description:"Resistance has become an active uprising.",type:"revolution",timestamp:now(),countryIds:[territory.originalCountryId,territory.controllerCountryId]});
    }
  }

  for (const r of revolutions) {
    if (r.status !== "active") continue;
    r.support = Math.min(100, r.support + 1);
    const territory = strategyTerritories.find(t => t.id === r.territoryId);
    if (territory && r.support >= 100) {
      territory.controllerCountryId = territory.originalCountryId;
      territory.countryId = territory.originalCountryId;
      territory.occupied = false;
      territory.contested = false;
      territory.controlPercentage = 100;
      territory.resistance = 100;
      const city = strategyCities.find(c => c.id === territory.cityId);
      if (city) city.controllerCountryId = territory.originalCountryId;
      r.status = "liberated";
      const c = countries.get(r.countryId);
      if (c) { c.status = "independent"; c.controllerCountryId = c.id; c.independenceMovement = 100; }
      worldHistory.unshift({id:id("hist"),type:"independence",title:`${c?.name || r.countryId} liberated`,description:"A successful uprising restored local control.",timestamp:now(),countryIds:[r.countryId]});
    }
  }

  // Active wars create real battles at contested cities when no battle exists there.
  for (const w of wars.filter(w => w.status === "active")) {
    const hasBattle = battles.some(b => b.warId === w.id && b.status === "active");
    if (!hasBattle) {
      const target = strategyTerritories.find(t => t.countryId === w.defenderCountryId || t.controllerCountryId === w.defenderCountryId);
      if (target) {
        target.contested = true;
        const battle = {id:id("battle"),warId:w.id,territoryId:target.id,location:target.name,attackerCountryId:w.attackerCountryId,defenderCountryId:w.defenderCountryId,attackerStrength:Math.max(1000,(countries.get(w.attackerCountryId)?.militaryStrength||20)*100),defenderStrength:Math.max(1000,(countries.get(w.defenderCountryId)?.militaryStrength||20)*100),progress:0,status:"active",createdAt:now()};
        battles.push(battle);
        w.battles = (w.battles || []).concat(battle.id);
      }
    }
  }

  broadcast({ type: "tick", payload: { tickCount, serverTime: now(), market, resources, constructionQueue, researchProjects, battles, revolutions, travelOrders } });
}

// ─── WebSocket (minimal, for tick push) ────────────────────

const wsClients = new Set();

function acceptWs(req, socket, head) {
  // Very small WebSocket handshake
  const key = req.headers["sec-websocket-key"];
  if (!key) {
    socket.destroy();
    return;
  }
  const accept = crypto
    .createHash("sha1")
    .update(key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11")
    .digest("base64");
  socket.write(
    "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " +
      accept +
      "\r\n\r\n"
  );
  const client = { socket, subscribed: false };
  wsClients.add(client);

  const welcome = JSON.stringify({
    type: "welcome",
    payload: { version: VERSION, tickCount, serverTime: now() },
  });
  wsSend(socket, welcome);

  socket.on("data", (buf) => {
    try {
      const msg = wsParse(buf);
      if (!msg) return;
      const data = JSON.parse(msg);
      if (data.type === "subscribe") {
        client.subscribed = true;
        wsSend(socket, JSON.stringify({ type: "subscribed", payload: { ok: true } }));
      }
      if (data.type === "ping") {
        wsSend(
          socket,
          JSON.stringify({
            type: "pong",
            payload: { serverTime: now(), tickCount },
          })
        );
      }
      if (data.type === "auth" && data.token) {
        const session = sessions.get(data.token);
        if (session) {
          client.playerId = session.playerId;
          wsSend(
            socket,
            JSON.stringify({ type: "auth_ok", payload: { playerId: session.playerId } })
          );
        } else {
          wsSend(
            socket,
            JSON.stringify({ type: "auth_fail", payload: { message: "Invalid token" } })
          );
        }
      }
    } catch {
      /* ignore */
    }
  });

  socket.on("close", () => wsClients.delete(client));
  socket.on("error", () => {
    wsClients.delete(client);
    socket.destroy();
  });
}

function wsSend(socket, text) {
  const payload = Buffer.from(text);
  const len = payload.length;
  let header;
  if (len < 126) {
    header = Buffer.alloc(2);
    header[0] = 0x81;
    header[1] = len;
  } else {
    header = Buffer.alloc(4);
    header[0] = 0x81;
    header[1] = 126;
    header.writeUInt16BE(len, 2);
  }
  try {
    socket.write(Buffer.concat([header, payload]));
  } catch {
    /* closed */
  }
}

function wsParse(buf) {
  if (buf.length < 2) return null;
  const second = buf[1];
  const masked = (second & 0x80) !== 0;
  let len = second & 0x7f;
  let offset = 2;
  if (len === 126) {
    len = buf.readUInt16BE(2);
    offset = 4;
  }
  let mask;
  if (masked) {
    mask = buf.slice(offset, offset + 4);
    offset += 4;
  }
  const data = buf.slice(offset, offset + len);
  if (masked && mask) {
    for (let i = 0; i < data.length; i++) data[i] ^= mask[i % 4];
  }
  return data.toString("utf8");
}

function broadcast(obj) {
  const text = JSON.stringify(obj);
  for (const c of wsClients) {
    if (c.subscribed) wsSend(c.socket, text);
  }
}


// ─── social / news / messaging ────────────────────────────
function publicSocialAuthor(playerId){
  const p=players.get(playerId);
  return p ? {id:p.id,username:p.username,displayName:p.displayName,profileImageUrl:p.profileImageUrl,countryId:p.countryId,rank:p.rank} : {id:playerId,username:'unknown',displayName:'Unknown Player',profileImageUrl:null,countryId:null,rank:'citizen'};
}
function makeSystemFeed(){
  const system=[];
  for(const e of events.slice(0,60)) system.push({id:`system_${e.id}`,kind:'system',title:e.title,body:e.description,type:e.type,timestamp:e.timestamp,countryIds:e.countryIds||[],author:null,imageDataUrl:null});
  for(const w of wars.slice(-30)) {
    const a=countries.get(w.attackerCountryId), d=countries.get(w.defenderCountryId);
    system.push({id:`war_${w.id}`,kind:'war',title:`${a?.name||w.attackerCountryId} vs ${d?.name||w.defenderCountryId}`,body:w.status==='active'?'Active war — fronts and battles are updating in real time.':`War ended ${w.endedAt?new Date(w.endedAt).toLocaleString():'recently'}.`,type:'war',timestamp:w.endedAt||w.declaredAt,countryIds:[w.attackerCountryId,w.defenderCountryId],author:null,imageDataUrl:null});
  }
  return system;
}
function makeFeed(){
  const posts=socialPosts.map(p=>({...p,author:publicSocialAuthor(p.playerId)}));
  return [...posts,...makeSystemFeed()].sort((a,b)=>new Date(b.timestamp).getTime()-new Date(a.timestamp).getTime()).slice(0,100);
}
async function handleSocial(req,res,path,method,url,requestId){
  const auth=getPlayerFromReq(req);
  if(method==='GET' && path==='/api/social/feed') return ok(res,makeFeed(),200,requestId);
  if(method==='POST' && path==='/api/social/posts'){
    if(!auth) return fail(res,401,'unauthorized','Authentication required.',false,requestId);
    const body=await readBody(req); const text=String(body.text||'').trim(); const imageDataUrl=body.imageDataUrl?String(body.imageDataUrl):null;
    if(!text && !imageDataUrl) return fail(res,400,'validation_error','Post text or an image is required.',false,requestId);
    if(text.length>1000) return fail(res,400,'validation_error','Post text is limited to 1000 characters.',false,requestId);
    if(imageDataUrl && imageDataUrl.length>240000) return fail(res,413,'payload_too_large','Image is too large. Resize it before posting.',false,requestId);
    const post={id:id('post'),playerId:auth.player.id,text,imageDataUrl,createdAt:now(),timestamp:now(),likes:0,comments:0};
    socialPosts.unshift(post); socialPosts.splice(100); saveState(); return ok(res,{...post,author:publicSocialAuthor(auth.player.id)},201,requestId);
  }
  if(method==='GET' && path==='/api/social/messages'){
    if(!auth) return fail(res,401,'unauthorized','Authentication required.',false,requestId);
    const other=url.searchParams.get('withPlayerId');
    const list=directMessages.filter(m=>other ? ((m.fromPlayerId===auth.player.id&&m.toPlayerId===other)||(m.fromPlayerId===other&&m.toPlayerId===auth.player.id)) : (m.fromPlayerId===auth.player.id||m.toPlayerId===auth.player.id)).map(m=>({...m,from:publicSocialAuthor(m.fromPlayerId),to:publicSocialAuthor(m.toPlayerId)}));
    return ok(res,list.slice(-100),200,requestId);
  }
  if(method==='POST' && path==='/api/social/messages'){
    if(!auth) return fail(res,401,'unauthorized','Authentication required.',false,requestId);
    const body=await readBody(req); const toPlayerId=String(body.toPlayerId||''); const text=String(body.text||'').trim();
    if(!players.has(toPlayerId)||toPlayerId===auth.player.id) return fail(res,400,'validation_error','A valid recipient is required.',false,requestId);
    if(!text||text.length>2000) return fail(res,400,'validation_error','Message must be 1-2000 characters.',false,requestId);
    const m={id:id('msg'),fromPlayerId:auth.player.id,toPlayerId,text,createdAt:now(),read:false}; directMessages.push(m); saveState(); return ok(res,{...m,from:publicSocialAuthor(auth.player.id),to:publicSocialAuthor(toPlayerId)},201,requestId);
  }
  if(method==='GET' && path==='/api/social/coalitions'){
    return ok(res,coalitions.map(c=>({...c,memberCount:c.memberPlayerIds.length,members:c.memberPlayerIds.map(publicSocialAuthor)})),200,requestId);
  }
  if(method==='POST' && path==='/api/social/coalitions'){
    if(!auth) return fail(res,401,'unauthorized','Authentication required.',false,requestId);
    const body=await readBody(req); const name=String(body.name||'').trim();
    if(name.length<3||name.length>48) return fail(res,400,'validation_error','Coalition name must be 3-48 characters.',false,requestId);
    const c={id:id('coalition'),name,tag:String(body.tag||name.slice(0,4)).toUpperCase().slice(0,8),leaderPlayerId:auth.player.id,memberPlayerIds:[auth.player.id],createdAt:now()}; coalitions.push(c); saveState(); return ok(res,c,201,requestId);
  }
  const cm=path.match(/^\/api\/social\/coalitions\/([^/]+)(?:\/(join|messages))?$/);
  if(cm){
    const c=coalitions.find(x=>x.id===cm[1]); if(!c) return fail(res,404,'not_found','Coalition not found.',false,requestId);
    const action=cm[2];
    if(action==='join'&&method==='POST'){
      if(!auth) return fail(res,401,'unauthorized','Authentication required.',false,requestId);
      if(!c.memberPlayerIds.includes(auth.player.id)) c.memberPlayerIds.push(auth.player.id); saveState(); return ok(res,c,200,requestId);
    }
    if(action==='messages'&&method==='GET') return ok(res,coalitionMessages.filter(m=>m.coalitionId===c.id).map(m=>({...m,author:publicSocialAuthor(m.playerId)})).slice(-200),200,requestId);
    if(action==='messages'&&method==='POST'){
      if(!auth) return fail(res,401,'unauthorized','Authentication required.',false,requestId);
      if(!c.memberPlayerIds.includes(auth.player.id)) return fail(res,403,'forbidden','Join the coalition before using coalition chat.',false,requestId);
      const body=await readBody(req); const text=String(body.text||'').trim(); if(!text||text.length>2000) return fail(res,400,'validation_error','Message must be 1-2000 characters.',false,requestId);
      const m={id:id('cmsg'),coalitionId:c.id,playerId:auth.player.id,text,createdAt:now()}; coalitionMessages.push(m); saveState(); return ok(res,{...m,author:publicSocialAuthor(auth.player.id)},201,requestId);
    }
  }
  return fail(res,404,'not_found','Social endpoint not found.',false,requestId);
}

// ─── router ────────────────────────────────────────────────

async function handle(req, res) {
  const requestId = req.headers["x-request-id"] || rid();

  if (req.method === "OPTIONS") {
    res.writeHead(204, {
      "Access-Control-Allow-Origin": CORS_ORIGINS.includes("*") ? "*" : (CORS_ORIGINS.includes(res.req?.headers?.origin) ? res.req.headers.origin : CORS_ORIGINS[0] || ""),
      "Access-Control-Allow-Headers":
        "Content-Type, Authorization, X-Request-ID, X-Client-Version, X-Client-Platform",
      "Access-Control-Allow-Methods": "GET,POST,PUT,PATCH,DELETE,OPTIONS",
    });
    res.end();
    return;
  }

  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  const path = url.pathname;
  const method = req.method || "GET";

  try {
    // Health
    if (method === "GET" && (path === "/health" || path === "/api/health")) {
      return ok(
        res,
        {
          status: "ok",
          version: VERSION,
          tickCount,
          players: players.size,
          uptimeSeconds: Math.floor((Date.now() - new Date(startedAt).getTime()) / 1000),
        },
        200,
        requestId
      );
    }

    if (method === "GET" && path === "/api") {
      return ok(
        res,
        { name: "Global Dominion API", version: VERSION },
        200,
        requestId
      );
    }

    // ── AUTH ──
    if (path.startsWith("/api/auth")) {
      return await handleAuth(req, res, path, method, requestId);
    }

    // ── WORLD ──
    if (path.startsWith("/api/world")) {
      return await handleWorld(req, res, path, method, url, requestId);
    }

    // ── PLAYERS ──
    if (path.startsWith("/api/players")) {
      return await handlePlayers(req, res, path, method, url, requestId);
    }

    // ── ECONOMY ──
    if (path.startsWith("/api/economy") || path === "/api/markets") {
      return await handleEconomy(req, res, path, method, url, requestId);
    }

    // ── MILITARY ──
    if (path.startsWith("/api/government")) { return await handleGovernment(req,res,path,method,requestId); }
    if (path.startsWith("/api/military")) {
      return await handleMilitary(req, res, path, method, url, requestId);
    }

    // ── WARS ──
    if (path.startsWith("/api/wars")) {
      return await handleWars(req, res, path, method, requestId);
    }

    // ── DIPLOMACY ──
    if (path.startsWith("/api/diplomacy")) {
      return await handleDiplomacy(req, res, path, method, url, requestId);
    }

    // ── MAP ──
    if (path.startsWith("/api/map")) {
      if (method === "GET" && path === "/api/map/countries") {
        const features = strategyCities.map((city) => ({
          type: "Feature", id: city.id,
          properties: { name: city.name, countryId: city.controllerCountryId || city.countryId, originalCountryId: city.countryId, capital: city.capital, population: city.population, major: city.major, morale: city.morale, development: city.development },
          geometry: { type: "Point", coordinates: [city.longitude, city.latitude] },
        }));
        return ok(res, { type: "FeatureCollection", features }, 200, requestId);
      }
      if (method === "GET" && path === "/api/map/routes") {
        return ok(res, transportRoutes, 200, requestId);
      }
      if (method === "POST" && path === "/api/map/interactions") {
        const body = await readBody(req);
        return ok(res, { received: true, interaction: body, timestamp: now() }, 200, requestId);
      }
    }

    // ── SOCIAL / NEWS / MESSAGING ──
    if (path.startsWith("/api/social")) {
      return await handleSocial(req, res, path, method, url, requestId);
    }

    // ── BANKING ──
    if (path.startsWith("/api/banking")) {
      return await handleBanking(req, res, path, method, requestId);
    }

    // ── COMPANIES ──
    if (path.startsWith("/api/companies")) {
      return await handleCompanies(req, res, path, method, url, requestId);
    }



    // ── GRAND STRATEGY ──
    if (path.startsWith("/api/strategy") || path.startsWith("/api/buildings") || path.startsWith("/api/cities") || path.startsWith("/api/territories") || path.startsWith("/api/research") || path.startsWith("/api/construction") || path.startsWith("/api/travel") || path.startsWith("/api/revolutions") || path.startsWith("/api/independence") || path.startsWith("/api/history") || path.startsWith("/api/nation") || path.startsWith("/api/jobs") || path.startsWith("/api/espionage") || path.startsWith("/api/intelligence")) {
      return await handleStrategy(req, res, path, method, url, requestId);
    }

    // Resources are now backed by the persistent economy state.
    if (path.startsWith("/api/resources")) {
      const countryId = url.searchParams.get("countryId") || getPlayerFromReq(req)?.player.countryId || "country_gnr";
      return ok(res, resources.filter(r => r.countryId === countryId), 200, requestId);
    }

    fail(res, 404, "not_found", `Endpoint not found: ${method} ${path}`, false, requestId);
  } catch (err) {
    console.error(err);
    fail(res, 500, "server_error", err.message || "Internal error", true, requestId);
  }
}

async function handleStrategy(req, res, path, method, url, requestId) {
  const auth = getPlayerFromReq(req);
  const playerCountry = auth?.player.countryId || url.searchParams.get("countryId") || "country_gnr";
  if (method === "GET" && path === "/api/strategy/state") {
    return ok(res, { tickCount, serverTime:now(), cities:strategyCities, territories:strategyTerritories, buildings, constructionQueue, technologies, researchProjects, marketOrders, battles, revolutions, independenceClaims, travelOrders: auth ? travelOrders.filter(t=>t.playerId===auth.player.id) : [], governments, diplomaticTreaties, worldHistory:worldHistory.slice(0,200), jobs:auth ? playerJobs.filter(j=>j.playerId===auth.player.id) : [], units:[...units.values()], militaryOrders:unitOrders, countries:[...countries.values()], resources:resources.filter(r=>r.countryId===playerCountry), market }, 200, requestId);
  }
  if (method === "GET" && path === "/api/cities") {
    const countryId=url.searchParams.get("countryId");
    return ok(res, strategyCities.filter(c=>!countryId||c.countryId===countryId),200,requestId);
  }
  if (method === "GET" && path.startsWith("/api/cities/")) {
    const city=strategyCities.find(c=>c.id===path.split("/")[3]);
    if(!city) return fail(res,404,"not_found","City not found.",false,requestId);
    return ok(res,{...city,economy:{production:resources.filter(r=>r.countryId===city.countryId),buildings:buildings.filter(b=>b.cityId===city.id)},construction:constructionQueue.filter(q=>q.cityId===city.id)},200,requestId);
  }
  if (method === "GET" && path === "/api/territories") {
    const countryId=url.searchParams.get("countryId");
    return ok(res,strategyTerritories.filter(t=>!countryId||t.countryId===countryId),200,requestId);
  }
  if (method === "GET" && path === "/api/research/technologies") return ok(res,technologies,200,requestId);
  if (method === "GET" && path === "/api/research/projects") return ok(res,researchProjects.filter(p=>!url.searchParams.get("countryId")||p.countryId===url.searchParams.get("countryId")),200,requestId);
  if (method === "POST" && path === "/api/research/projects") {
    if(!auth) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    const body=await readBody(req); const tech=technologies.find(t=>t.id===body.technologyId);
    if(!tech) return fail(res,404,"not_found","Technology not found.",false,requestId);
    if(researchProjects.some(p=>p.playerId===auth.player.id&&p.status==="active")) return fail(res,409,"conflict","A research project is already active.",false,requestId);
    const missing=(tech.prerequisites||[]).filter(reqId=>!researchProjects.some(p=>p.playerId===auth.player.id&&p.technologyId===reqId&&p.status==="completed"));
    if(missing.length) return fail(res,409,"prerequisite","Missing prerequisites.",false,requestId);
    if(auth.player.wealth < tech.cost) return fail(res,400,"insufficient_funds","Insufficient funds for research.",false,requestId);
    auth.player.wealth-=tech.cost;
    const project={id:id("research"),playerId:auth.player.id,countryId:auth.player.countryId||playerCountry,technologyId:tech.id,name:tech.name,progress:0,status:"active",cost:tech.cost,createdAt:now()};
    researchProjects.push(project); return ok(res,project,201,requestId);
  }
  if (method === "GET" && path === "/api/buildings/catalog") return ok(res,Object.entries(BUILDING_BLUEPRINTS).map(([id,v])=>({id,...v})),200,requestId);
  if (method === "POST" && path === "/api/construction") {
    if(!auth) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    const body=await readBody(req); const city=strategyCities.find(c=>c.id===body.cityId);
    const controller=city ? (city.controllerCountryId||city.countryId) : null;
    if(!city || controller!==(auth.player.countryId||playerCountry)) return fail(res,403,"forbidden","You do not control this city.",false,requestId);
    const costs=Object.fromEntries(Object.entries(BUILDING_BLUEPRINTS).map(([k,v])=>[k,v.cost]));
    const buildType=String(body.type||"industrial");
    if(!BUILDING_BLUEPRINTS[buildType]) return fail(res,400,"invalid_building","Unknown building type.",false,requestId);
    if(buildType!=="road" && buildType!=="rail" && hasBuilding(city.id,buildType) && buildingLevel(city.id,buildType)>=BUILDING_BLUEPRINTS[buildType].maxLevel) return fail(res,409,"max_level","Building is already at maximum level.",false,requestId);
    const cost=costs[buildType]||costs.industrial;
    if(auth.player.wealth<cost) return fail(res,400,"insufficient_funds","Insufficient funds for construction.",false,requestId);
    auth.player.wealth-=cost;
    const blueprint=buildingBlueprint(buildType);
    const q={id:id("build"),playerId:auth.player.id,countryId:controller,cityId:city.id,type:buildType,cost,progress:0,status:"active",buildTicks:blueprint.buildTicks,createdAt:now()};
    constructionQueue.push(q); return ok(res,q,201,requestId);
  }
  if (method === "POST" && path === "/api/military/orders") {
    if(!auth) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    const body=await readBody(req); const unit=units.get(body.unitId);
    if(!unit) return fail(res,404,"not_found","Unit not found.",false,requestId);
    if(unit.countryId!==auth.player.countryId && unit.ownerPlayerId!==auth.player.id) return fail(res,403,"forbidden","You do not command this formation.",false,requestId);
    try { const order=startUnitOrder(unit,body,auth.player.id); saveState(); return ok(res,order,201,requestId); }
    catch(e){ return fail(res,e.status||400,e.code||"validation_error",e.message,false,requestId); }
  }
  if (method === "GET" && path === "/api/military/orders") return ok(res,unitOrders.filter(o=>!auth||o.playerId===auth.player.id),200,requestId);
  if (method === "GET" && path === "/api/military/overview") {
    const mine=auth?Array.from(units.values()).filter(u=>u.countryId===auth.player.countryId):Array.from(units.values());
    return ok(res,{units:mine,activeOrders:unitOrders.filter(o=>o.status==='active'&&(!auth||o.playerId===auth.player.id)),garrisons:mine.filter(u=>u.garrisonedCityId),activeBattles:battles.filter(b=>b.status==='active')},200,requestId);
  }
  if (method === "POST" && path.startsWith("/api/military/orders/") && path.endsWith("/cancel")) {
    if(!auth) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    const oid=path.split("/")[4]; const o=unitOrders.find(x=>x.id===oid); if(!o) return fail(res,404,"not_found","Order not found.",false,requestId);
    if(o.playerId!==auth.player.id) return fail(res,403,"forbidden","Order is not yours.",false,requestId);
    o.status='cancelled';o.cancelled=true;o.completedAt=now();const u=units.get(o.unitId);if(u){u.activeOrderId=null;u.destination=null;u.route=[];u.status='ready';u.orderStatus='idle';}
    saveState(); return ok(res,o,200,requestId);
  }
  if (method === "GET" && path === "/api/military/orders") return ok(res,unitOrders.filter(o=>!auth||o.playerId===auth.player.id),200,requestId);
  if (method === "GET" && path === "/api/wars/battles") return ok(res,battles,200,requestId);
  // --- Travel agencies ---
  if (method === "GET" && path === "/api/travel/agencies") {
    const a=getPlayerFromReq(req); if(!a) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    return ok(res, travelAgencies.filter(x=>x.active && (x.type==="civilian" || x.countryId===a.player.countryId)),200,requestId);
  }
  if (method === "POST" && path === "/api/travel/military") {
    const body=await readBody(req); const unit=units.get(String(body.unitId||'')); if(!unit) return fail(res,404,"not_found","Unit not found.",false,requestId);
    let ctx; try{ctx=requireCommand(req,unit.countryId,['president','defense_minister','military_commander', 'army_commander']);}catch(e){return fail(res,e.status||403,e.code||'forbidden',e.message,false,requestId)}
    const destination=strategyCities.find(c=>c.id===body.destinationCityId); if(!destination) return fail(res,404,"not_found","Destination city not found.",false,requestId);
    try{const order=startUnitOrder(unit,{orderType:'transport',destinationCityId:destination.id},ctx.auth.player.id); order.transportAgencyId=body.agencyId||travelAgencies.find(x=>x.countryId===unit.countryId&&x.type==='military')?.id||null; order.transportMode=body.transportMode||'military_transport'; saveState(); return ok(res,order,201,requestId)}catch(e){return fail(res,e.status||400,e.code||'validation_error',e.message,false,requestId)}
  }
  if (method === "GET" && path === "/api/travel") {
    if (!auth) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    return ok(res, travelOrders.filter(t=>t.playerId===auth.player.id),200,requestId);
  }
  if (method === "POST" && path === "/api/travel") {
    if (!auth) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    if (auth.player.travelStatus === "travelling") return fail(res,409,"conflict","Player is already travelling.",false,requestId);
    const body=await readBody(req);
    const destination=strategyCities.find(c=>c.id===body.destinationCityId);
    const origin=strategyCities.find(c=>c.id===auth.player.currentCityId) || destination;
    if (!destination) return fail(res,404,"not_found","Destination city not found.",false,requestId);
    if (!origin) return fail(res,400,"validation_error","Current player location is unknown.",false,requestId);
    const distance=Math.max(10,Math.round(Math.hypot(destination.latitude-origin.latitude,(destination.longitude-origin.longitude)*0.7)*100));
    const transport=["walk","car","train","air","ship"].includes(body.transport)?body.transport:"train";
    const speed={walk:1,car:3,train:6,air:12,ship:4}[transport];
    const cost=Math.max(5,Math.round(distance*({walk:.01,car:.02,train:.03,air:.05,ship:.04}[transport])));
    if (auth.player.wealth < cost) return fail(res,400,"insufficient_funds","Not enough money for travel.",false,requestId);
    auth.player.wealth-=cost;
    const t={id:id("travel"),playerId:auth.player.id,originCityId:origin.id,originName:origin.name,destinationCityId:destination.id,destinationName:destination.name,transport,distance,cost,etaSeconds:Math.max(30,Math.round(distance/speed)),progress:0,status:"active",startedAt:now()};
    travelOrders.push(t);
    auth.player.travelStatus="travelling"; auth.player.travelDestinationCityId=destination.id;
    return ok(res,t,201,requestId);
  }
  if (method === "POST" && path === "/api/travel/cancel") {
    if (!auth) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    const t=travelOrders.find(x=>x.playerId===auth.player.id&&x.status==="active");
    if (!t) return fail(res,404,"not_found","No active travel order.",false,requestId);
    t.status="cancelled"; auth.player.travelStatus="stationary"; auth.player.travelDestinationCityId=null;
    return ok(res,t,200,requestId);
  }

  // --- Revolutions / liberation ---
  if (method === "GET" && path === "/api/revolutions") return ok(res,revolutions,200,requestId);
  if (method === "POST" && path === "/api/revolutions/start") {
    if (!auth) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    const body=await readBody(req);
    const territory=strategyTerritories.find(t=>t.id===body.territoryId || t.cityId===body.cityId || t.originalCountryId===body.countryId);
    if (!territory) return fail(res,404,"not_found","Territory not found.",false,requestId);
    if (territory.controllerCountryId===territory.originalCountryId) return fail(res,409,"conflict","Territory is already controlled by its original nation.",false,requestId);
    const existing=revolutions.find(r=>r.territoryId===territory.id&&r.status==="active");
    if (existing) return ok(res,existing,200,requestId);
    const r={id:id("rev"),territoryId:territory.id,countryId:territory.originalCountryId,cityId:territory.cityId,leaderPlayerId:auth.player.id,goal:body.goal||"independence",support:Math.min(100,(territory.resistance||20)+10),status:"active",startedAt:now()};
    revolutions.push(r);
    events.unshift({id:id("evt"),title:`Resistance organized in ${territory.name}`,description:`${auth.player.displayName} is supporting a liberation movement.`,type:"revolution",timestamp:now(),countryIds:[territory.originalCountryId,territory.controllerCountryId]});
    return ok(res,r,201,requestId);
  }
  if (method === "POST" && path === "/api/revolutions/support") {
    if (!auth) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    const body=await readBody(req); const r=revolutions.find(x=>x.id===body.revolutionId) || revolutions.find(x=>x.countryId===body.countryId && x.status==="active");
    if (!r) return fail(res,404,"not_found","Revolution not found.",false,requestId);
    const amount=Math.max(1,Math.min(20,Number(body.amount)||5));
    if (auth.player.wealth < amount*10) return fail(res,400,"insufficient_funds","Insufficient funds.",false,requestId);
    auth.player.wealth-=amount*10; r.support=Math.min(100,r.support+amount);
    return ok(res,r,200,requestId);
  }
  if (method === "POST" && path === "/api/independence/declare") {
    if (!auth) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    const body=await readBody(req); const country=countries.get(body.countryId);
    if (!country) return fail(res,404,"not_found","Nation not found.",false,requestId);
    const controlled=strategyTerritories.filter(t=>t.originalCountryId===country.id && t.controllerCountryId===country.id).length;
    const total=strategyTerritories.filter(t=>t.originalCountryId===country.id).length;
    const movement=Number(country.independenceMovement||15);
    if (controlled < Math.max(1,Math.ceil(total*0.5)) || movement < 70) return fail(res,409,"requirements_not_met",`Independence requires 50% territorial control and 70% political support. Current support: ${movement}%.`,false,requestId);
    country.status="independent"; country.controllerCountryId=country.id; country.government="provisional";
    country.independenceMovement=100;
    independenceClaims.push({id:id("ind"),countryId:country.id,declaredByPlayerId:auth.player.id,declaredAt:now(),recognized:false});
    worldHistory.unshift({id:id("hist"),type:"independence",title:`${country.name} declares independence`,description:"A restored national government has declared independence.",timestamp:now(),countryIds:[country.id]});
    return ok(res,{success:true,country,claim:independenceClaims[independenceClaims.length-1]},200,requestId);
  }

  // --- Nation / politics ---
  if (method === "GET" && path === "/api/nation") {
    const c=countries.get(playerCountry);
    return ok(res,{country:c,territories:strategyTerritories.filter(t=>t.controllerCountryId===playerCountry),governments:governments.filter(g=>g.countryId===playerCountry),roles:playerNationRoles.filter(r=>r.playerId===auth?.player.id)},200,requestId);
  }
  if (method === "POST" && path === "/api/nation/policy") {
    if (!auth) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    const body=await readBody(req); const c=countries.get(auth.player.countryId);
    if (!c) return fail(res,404,"not_found","Nation not found.",false,requestId);
    const policy=String(body.policy||"industrial_focus");
    const effects={industrial_focus:{stability:-1,gdp:1.02,military:0},military_spending:{stability:-2,gdp:.99,military:3},social_programs:{stability:3,gdp:.995,military:-1},open_trade:{stability:1,gdp:1.01,military:0}}[policy]||{stability:0,gdp:1,military:0};
    c.stability=Math.max(0,Math.min(100,c.stability+effects.stability)); c.gdp=Math.round(c.gdp*effects.gdp); c.militaryStrength=Math.max(0,Math.min(100,c.militaryStrength+effects.military));
    worldHistory.unshift({id:id("hist"),type:"politics",title:`Policy adopted in ${c.name}`,description:policy,timestamp:now(),countryIds:[c.id]});
    return ok(res,{country:c,policy,effects},200,requestId);
  }

  // --- Jobs / work ---
  if (method === "GET" && path === "/api/jobs/current") {
    if (!auth) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    return ok(res,playerJobs.filter(j=>j.playerId===auth.player.id&&j.status==="active"),200,requestId);
  }
  if (method === "POST" && path === "/api/jobs/start") {
    if (!auth) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    if (playerJobs.some(j=>j.playerId===auth.player.id&&j.status==="active")) return fail(res,409,"conflict","You already have an active job.",false,requestId);
    const body=await readBody(req); const jobs={miner:{salary:180,durationTicks:6},factory:{salary:220,durationTicks:6},merchant:{salary:260,durationTicks:6},engineer:{salary:300,durationTicks:8},officer:{salary:340,durationTicks:8}};
    const job=jobs[body.jobType]||jobs.factory;
    const j={id:id("job"),playerId:auth.player.id,jobType:body.jobType||"factory",salary:job.salary,durationTicks:job.durationTicks,remainingTicks:job.durationTicks,status:"active",startedAt:now()};
    playerJobs.push(j); auth.player.career=j.jobType;
    return ok(res,j,201,requestId);
  }

  // --- Intelligence / Secret Services ---
  if (method === "GET" && path === "/api/intelligence/agencies") {
    const countryId=String(url.searchParams.get("countryId")||auth?.player?.countryId||"");
    return ok(res,intelligenceAgencies.filter(a=>!countryId||a.countryId===countryId),200,requestId);
  }
  if (method === "POST" && path === "/api/intelligence/agencies") {
    if(!auth) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    const body=await readBody(req); const countryId=auth.player.countryId;
    if(!countryId) return fail(res,400,"no_country","Player has no country.",false,requestId);
    const secretHqs=buildings.filter(b=>b.countryId===countryId && b.type==="secret_service" && !b.destroyed);
    if(!secretHqs.length) return fail(res,409,"secret_service_required","Build a Secret Service Headquarters before opening an agency.",false,requestId);
    const hqLevel=Math.max(...secretHqs.map(b=>Number(b.level)||1));
    const countryAgencyLimit=Math.min(intelligenceAgencyLimit, 1 + hqLevel);
    if(intelligenceAgencies.filter(a=>a.countryId===countryId).length>=countryAgencyLimit) return fail(res,409,"agency_limit",`Your Secret Service Headquarters supports ${countryAgencyLimit} agencies at its current level. Upgrade it to open more.`,false,requestId);
    if((auth.player.wealth||0)<5000) return fail(res,400,"insufficient_funds","GD$5,000 is required to establish an agency.",false,requestId);
    auth.player.wealth-=5000;
    const agency={id:id("agency"),countryId,name:String(body.name||"National Intelligence Directorate").slice(0,64),founderPlayerId:auth.player.id,level:1,capacity:3+Math.max(0,hqLevel-1),counterintelligence:40+Math.max(0,hqLevel-1)*12,active:true,createdAt:now()};
    intelligenceAgencies.push(agency); saveState(); return ok(res,agency,201,requestId);
  }
  if (method === "GET" && path === "/api/intelligence/missions") return ok(res,auth?espionageMissions.filter(m=>m.playerId===auth.player.id):[],200,requestId);
  if (method === "POST" && path === "/api/intelligence/missions") {
    if (!auth) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    const body=await readBody(req); const target=String(body.targetCountryId||""); const agency=intelligenceAgencies.find(a=>a.id===String(body.agencyId||"") && a.countryId===auth.player.countryId && a.active);
    if (!agency) return fail(res,403,"forbidden","You do not control that intelligence agency.",false,requestId);
    if (!countries.has(target)||target===auth.player.countryId) return fail(res,400,"invalid_target","Invalid intelligence target.",false,requestId);
    const active=espionageMissions.filter(m=>m.agencyId===agency.id&&(m.status==="active"));
    if(active.length>=agency.capacity) return fail(res,409,"agency_capacity","Agency mission capacity is full.",false,requestId);
    const type=String(body.type||"recon"); if(!["recon","surveillance","counterintelligence","sabotage"].includes(type)) return fail(res,400,"invalid_mission_type","Invalid mission type.",false,requestId);
    const durationMs=type==="recon"?90000:type==="surveillance"?150000:type==="counterintelligence"?120000:210000;
    const risk=type==="sabotage"?48:type==="surveillance"?30:20;
    const mission={id:id("spy"),agencyId:agency.id,playerId:auth.player.id,targetCountryId:target,targetCity:body.targetCity?String(body.targetCity).slice(0,80):null,type,progress:0,status:"active",startedAt:now(),durationMs,risk,reward:100+Math.floor(durationMs/1000),caughtByAgencyId:null,result:null};
    espionageMissions.push(mission); saveState(); return ok(res,mission,201,requestId);
  }
  if (method === "GET" && path === "/api/espionage") return ok(res,auth?espionageMissions.filter(m=>m.playerId===auth.player.id):[],200,requestId);
  if (method === "POST" && path === "/api/espionage") {
    if (!auth) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    const body=await readBody(req); const target=String(body.targetCountryId||"");
    if (!countries.has(target)) return fail(res,404,"not_found","Target nation not found.",false,requestId);
    const agency=intelligenceAgencies.find(a=>a.countryId===auth.player.countryId&&a.active);
    if(!agency) return fail(res,403,"no_agency","Establish an intelligence agency first.",false,requestId);
    const mission={id:id("spy"),agencyId:agency.id,playerId:auth.player.id,targetCountryId:target,targetCity:null,type:body.type||"recon",progress:0,status:"active",startedAt:now(),durationMs:90000,risk:20,reward:100};
    espionageMissions.push(mission); return ok(res,mission,201,requestId);
  }

  // --- History ---
  if (method === "GET" && path === "/api/history") return ok(res,worldHistory.slice(0,200),200,requestId);

  return fail(res,404,"not_found","Strategy endpoint not found.",false,requestId);
}

async function handleAuth(req, res, path, method, requestId) {
  if (method === "POST" && path === "/api/auth/register") {
    const body = await readBody(req);
    const email = String(body.email || "")
      .trim()
      .toLowerCase();
    const password = String(body.password || "");
    const displayName = String(body.displayName || "").trim();
    const username = String(body.username || email.split("@")[0] || "citizen").trim().toLowerCase();
    const countryId = String(body.countryId || "country_gnr");
    if (!email || !password || !displayName || !username) {
      return fail(res, 400, "validation_error", "email, password, displayName and username are required.", false, requestId);
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return fail(res, 400, "validation_error", "Enter a valid email address.", false, requestId);
    }
    if (password.length < 8) {
      return fail(res, 400, "validation_error", "Password must be at least 8 characters.", false, requestId);
    }
    if (!/^[a-z0-9_]{3,24}$/.test(username)) {
      return fail(res, 400, "validation_error", "Username must be 3-24 characters using letters, numbers or underscores.", false, requestId);
    }
    if (!countries.has(countryId)) {
      return fail(res, 400, "validation_error", "Invalid starting nation.", false, requestId);
    }
    if (playersByEmail.has(email)) {
      return fail(res, 409, "conflict", "Email already registered.", false, requestId);
    }
    const player = {
      id: id("player"),
      email,
      passwordHash: hashPassword(password),
      username,
      displayName,
      emailVerified: true,
      profileImageUrl: null,
      countryId,
      nationalityCountryId: countryId,
      rank: "citizen",
      level: 1,
      experience: 0,
      prestige: 0,
      reputation: 50,
      wealth: 2500,
      currency: "¥",
      status: "online",
      career: "civilian",
      biography: "A new citizen of the global order.",
      currentCityId: strategyCities.find(c => c.countryId === countryId && c.capital)?.id || strategyCities.find(c => c.countryId === countryId)?.id || null,
      travelStatus: "stationary",
      createdAt: now(),
      lastLoginAt: now(),
    };
    players.set(player.id, player);
    playersByEmail.set(email, player.id);
    const gov=governmentCommandStructures.find(g=>g.countryId===countryId);
    if(gov && !gov.presidentPlayerId){
      gov.presidentPlayerId=player.id;
      playerNationRoles.push({id:id("role"),playerId:player.id,countryId,role:"president",appointedAt:now(),appointedBy:null});
      player.rank="national_leader";
    }
    const session = createSession(player.id, body.deviceId || null);
    saveState();
    return ok(
      res,
      {
        success: true,
        user: authUser(player),
        session,
        verificationRequired: false,
        message: "Account created.",
      },
      201,
      requestId
    );
  }

  if (method === "POST" && path === "/api/auth/login") {
    const body = await readBody(req);
    const email = String(body.email || "")
      .trim()
      .toLowerCase();
    const password = String(body.password || "");
    const pid = playersByEmail.get(email);
    if (!pid) return fail(res, 401, "unauthorized", "Invalid email or password.", false, requestId);
    const player = players.get(pid);
    if (!verifyPassword(password, player.passwordHash)) {
      return fail(res, 401, "unauthorized", "Invalid email or password.", false, requestId);
    }
    if (!player.passwordHash.startsWith("scrypt$")) {
      player.passwordHash = hashPassword(password);
    }
    player.lastLoginAt = now();
    player.status = "online";
    const session = createSession(player.id, body.deviceId || null);
    saveState();
    return ok(
      res,
      {
        success: true,
        user: authUser(player),
        session,
        verificationRequired: false,
        accountLocked: false,
        message: "Welcome back.",
      },
      200,
      requestId
    );
  }

  if (method === "POST" && path === "/api/auth/logout") {
    const auth = getPlayerFromReq(req);
    if (auth) {
      sessions.delete(auth.session.accessToken);
      auth.player.status = "offline";
    }
    return ok(res, { success: true }, 200, requestId);
  }

  if (method === "POST" && path === "/api/auth/refresh") {
    const body = await readBody(req);
    let found = null;
    for (const s of sessions.values()) {
      if (s.refreshToken === body.refreshToken) {
        found = s;
        break;
      }
    }
    if (!found) return fail(res, 401, "unauthorized", "Invalid refresh token.", false, requestId);
    sessions.delete(found.accessToken);
    const next = createSession(found.playerId, found.deviceId);
    saveState();
    return ok(res, next, 200, requestId);
  }

  if (method === "GET" && path === "/api/auth/me") {
    const auth = getPlayerFromReq(req);
    if (!auth) return fail(res, 401, "unauthorized", "Authentication required.", false, requestId);
    return ok(res, authUser(auth.player), 200, requestId);
  }

  // stubs for remaining auth security endpoints
  if (path.startsWith("/api/auth/email") || path.startsWith("/api/auth/password") || path.startsWith("/api/auth/security")) {
    if (method === "GET" && path === "/api/auth/security/status") {
      return ok(res, { twoFactorEnabled: false, trustedDevices: 1, recentFailedLogins: 0, accountRestricted: false }, 200, requestId);
    }
    if (method === "GET" && path === "/api/auth/security/devices") {
      return ok(res, [], 200, requestId);
    }
    if (method === "GET" && path === "/api/auth/security/restriction") {
      return ok(res, { restricted: false, reason: null, until: null }, 200, requestId);
    }
    if (method === "GET" && path === "/api/auth/security/events") {
      return ok(res, [], 200, requestId);
    }
    return ok(res, { success: true, message: "OK" }, 200, requestId);
  }

  fail(res, 404, "not_found", "Auth endpoint not found.", false, requestId);
}

async function handleWorld(req, res, path, method, url, requestId) {
  if (method === "GET" && path === "/api/world/state") {
    return ok(
      res,
      {
        name: "Global Dominion",
        version: VERSION,
        tickCount,
        startedAt,
        serverTime: now(),
        countries: [...countries.values()],
        onlinePlayers: [...players.values()].filter((p) => p.status === "online").length,
      },
      200,
      requestId
    );
  }
  if (method === "GET" && path === "/api/world/countries") {
    return ok(res, [...countries.values()], 200, requestId);
  }
  if (method === "GET" && path.startsWith("/api/world/countries/")) {
    const cid = path.split("/").pop();
    const c = countries.get(cid);
    if (!c) return fail(res, 404, "not_found", "Country not found.", false, requestId);
    return ok(res, c, 200, requestId);
  }
  if (method === "GET" && path === "/api/world/default-factions") {
    const ids=["country_gnr","country_ar","country_gar","country_jps"];
    return ok(res, ids.map(id=>countries.get(id)).filter(Boolean).map(c=>({id:c.id,name:c.name,code:c.code,capital:c.capital,color:c.color,bloc:c.bloc,region:c.region,description:`Alternate-history starting power centered on ${c.capital}.`})),200,requestId);
  }
  if (method === "GET" && path === "/api/world/events") {
    return ok(
      res,
      {
        items: events,
        pagination: {
          page: 1,
          pageSize: events.length,
          total: events.length,
          hasNextPage: false,
          nextCursor: null,
        },
      },
      200,
      requestId
    );
  }
  if (method === "POST" && path === "/api/world/country-selection") {
    const auth = getPlayerFromReq(req);
    if (!auth) return fail(res, 401, "unauthorized", "Authentication required.", false, requestId);
    const body = await readBody(req);
    if (!body.countryId || !countries.has(body.countryId)) {
      return fail(res, 400, "validation_error", "Valid countryId required.", false, requestId);
    }
    auth.player.countryId = body.countryId;
    auth.player.nationalityCountryId = body.countryId;
    return ok(res, { success: true, countryId: body.countryId, player: publicPlayer(auth.player) }, 200, requestId);
  }
  if (method === "POST" && path === "/api/world/subscription") {
    const body = await readBody(req).catch(() => ({}));
    return ok(res, { active: true, regions: body.regions || [], updatedAt: now() }, 200, requestId);
  }
  if (method === "GET" && path === "/api/world/heartbeat") {
    return ok(
      res,
      {
        ok: true,
        serverTime: now(),
        tickCount,
        version: VERSION,
        uptimeSeconds: Math.floor((Date.now() - new Date(startedAt).getTime()) / 1000),
      },
      200,
      requestId
    );
  }
  fail(res, 404, "not_found", "World endpoint not found.", false, requestId);
}

async function handlePlayers(req, res, path, method, url, requestId) {
  const auth = getPlayerFromReq(req);

  if (method === "GET" && path === "/api/players/search") {
    if (!auth) return fail(res, 401, "unauthorized", "Authentication required.", false, requestId);
    const q = String(url.searchParams.get("q") || "").toLowerCase();
    const results = [...players.values()]
      .filter((p) => !q || p.username.includes(q) || p.displayName.toLowerCase().includes(q))
      .slice(0, 20)
      .map((p) => ({
        id: p.id,
        username: p.username,
        displayName: p.displayName,
        countryId: p.countryId,
        rank: p.rank,
        level: p.level,
        status: p.status,
      }));
    return ok(res, results, 200, requestId);
  }

  if (method === "POST" && path === "/api/players/jobs/apply") {
    if (!auth) return fail(res, 401, "unauthorized", "Authentication required.", false, requestId);
    const body = await readBody(req);
    if (playerJobs.some(j=>j.playerId===auth.player.id&&j.status==="active")) return fail(res,409,"conflict","You already have an active job.",false,requestId);
    const jobMap={factory_worker:{salary:180,durationTicks:6},miner:{salary:240,durationTicks:9},merchant:{salary:320,durationTicks:9},engineer:{salary:480,durationTicks:12},officer:{salary:600,durationTicks:12}};
    const def=jobMap[body.jobId]||jobMap.factory_worker;
    const job={id:id("job"),playerId:auth.player.id,jobType:body.jobId||"factory_worker",title:String(body.jobId||"Factory Worker").replace(/_/g," "),salary:def.salary,durationTicks:def.durationTicks,remainingTicks:def.durationTicks,status:"active",startedAt:now()};
    playerJobs.push(job); auth.player.career=job.jobType;
    return ok(res, job, 201, requestId);
  }

  // /api/players/:id/...
  const parts = path.split("/").filter(Boolean); // api, players, ...
  if (parts.length >= 3) {
    const playerId = parts[2];
    if (method === "GET" && parts.length === 3) {
      if (!auth) return fail(res, 401, "unauthorized", "Authentication required.", false, requestId);
      const p = players.get(playerId);
      if (!p) return fail(res, 404, "not_found", "Player not found.", false, requestId);
      return ok(res, publicPlayer(p), 200, requestId);
    }
    if (method === "PUT" && parts.length === 3) {
      if (!auth || auth.player.id !== playerId) {
        return fail(res, 403, "forbidden", "Forbidden.", false, requestId);
      }
      const body = await readBody(req);
      if (body.displayName) auth.player.displayName = String(body.displayName).slice(0, 32);
      if (body.biography) auth.player.biography = String(body.biography).slice(0, 500);
      return ok(res, publicPlayer(auth.player), 200, requestId);
    }
    if (method === "GET" && parts[3] === "statistics") {
      const p = players.get(playerId);
      if (!p) return fail(res, 404, "not_found", "Player not found.", false, requestId);
      return ok(
        res,
        {
          playerId: p.id,
          level: p.level,
          experience: p.experience,
          prestige: p.prestige,
          reputation: p.reputation,
          wealth: p.wealth,
          warsParticipated: 0,
          companiesOwned: 0,
          electionsWon: 0,
        },
        200,
        requestId
      );
    }
    if (method === "GET" && parts[3] === "progression") {
      const p = players.get(playerId);
      if (!p) return fail(res, 404, "not_found", "Player not found.", false, requestId);
      return ok(
        res,
        {
          playerId: p.id,
          level: p.level,
          experience: p.experience,
          experienceToNextLevel: Math.max(100, p.level * 500),
          prestige: p.prestige,
          rank: p.rank,
          career: p.career,
        },
        200,
        requestId
      );
    }
    if (method === "GET" && parts[3] === "jobs" && parts[4] === "current") {
      return ok(res, playerJobs.find(j=>j.playerId===playerId&&j.status==="active") || null, 200, requestId);
    }
    if (method === "GET" && (parts[3] === "achievements" || parts[3] === "roles")) {
      return ok(res, [], 200, requestId);
    }
    if (method === "GET" && parts[3] === "skills") {
      return ok(
        res,
        [
          { id: "skill_leadership", name: "Leadership", level: 1, experience: 0 },
          { id: "skill_commerce", name: "Commerce", level: 1, experience: 0 },
          { id: "skill_tactics", name: "Tactics", level: 1, experience: 0 },
        ],
        200,
        requestId
      );
    }
    if (method === "POST" && parts[3] === "country") {
      if (!auth || auth.player.id !== playerId) {
        return fail(res, 403, "forbidden", "Forbidden.", false, requestId);
      }
      const body = await readBody(req);
      if (!body.countryId || !countries.has(body.countryId)) {
        return fail(res, 400, "validation_error", "Valid countryId required.", false, requestId);
      }
      auth.player.countryId = body.countryId;
      return ok(res, publicPlayer(auth.player), 200, requestId);
    }
  }

  // social stubs
  if (path.includes("/friends") || path.includes("/blocks")) {
    return ok(res, { success: true }, 200, requestId);
  }

  fail(res, 404, "not_found", "Players endpoint not found.", false, requestId);
}

async function handleEconomy(req, res, path, method, url, requestId) {
  if (method === "GET" && (path === "/api/economy/market/prices" || path === "/api/markets")) {
    return ok(res, market, 200, requestId);
  }
  if (method === "GET" && path === "/api/economy/market/orders") {
    const auth = getPlayerFromReq(req);
    return ok(res, auth ? marketOrders.filter(o=>o.playerId===auth.player.id) : marketOrders, 200, requestId);
  }
  if (method === "POST" && path === "/api/economy/market/orders") {
    const auth = getPlayerFromReq(req);
    if (!auth) return fail(res, 401, "unauthorized", "Authentication required.", false, requestId);
    const body = await readBody(req);
    const symbol = String(body.symbol||"").toUpperCase();
    const side = body.side === "sell" ? "sell" : "buy";
    const quantity = Math.max(1, Math.floor(Number(body.quantity)||0));
    const quote = market.find(m=>m.symbol===symbol);
    if (!quote || !quantity) return fail(res,400,"validation_error","Valid market symbol and quantity required.",false,requestId);
    const total = Math.round(quote.price*quantity*100)/100;
    const resourceMap={FOOD:"food",OIL:"oil",STL:"steel",ENR:"energy",TECH:"electronics"};
    const type=resourceMap[symbol]; const stock=resources.find(r=>r.countryId===auth.player.countryId&&r.type===type);
    if (side === "buy") {
      if (auth.player.wealth < total) return fail(res,400,"insufficient_funds","Insufficient funds.",false,requestId);
      auth.player.wealth -= total; if(stock) stock.amount += quantity;
    } else {
      if(!stock || stock.amount < quantity) return fail(res,400,"insufficient_resources","Insufficient resource stock.",false,requestId);
      stock.amount -= quantity; auth.player.wealth += total;
    }
    const order={id:id("ord"),playerId:auth.player.id,symbol,side,quantity,price:quote.price,total,status:"filled",createdAt:now()};
    marketOrders.push(order); return ok(res,order,201,requestId);
  }
  if (method === "GET" && path === "/api/economy/resources") {
    const countryId = url.searchParams.get("countryId") || "country_gnr";
    return ok(
      res,
      resources.filter((r) => r.countryId === countryId),
      200,
      requestId
    );
  }
  if (method === "GET" && (path === "/api/economy/trade-agreements" || path === "/api/economy/investments")) {
    return ok(res, [], 200, requestId);
  }
  if (method === "POST" && path === "/api/economy/tick") {
    advanceTick();
    return ok(res, { tickCount, market }, 200, requestId);
  }
  fail(res, 404, "not_found", "Economy endpoint not found.", false, requestId);
}

function commandRoleFor(playerId, countryId){
  const s=governmentCommandStructures.find(x=>x.countryId===countryId);
  if(!s) return null;
  if(s.presidentPlayerId===playerId) return "president";
  if(s.defenseMinisterPlayerId===playerId) return "defense_minister";
  if(s.militaryCommanderPlayerId===playerId) return "military_commander";
  const role=playerNationRoles.find(r=>r.playerId===playerId && r.countryId===countryId);
  return role?.role||null;
}
function requireCommand(req,countryId,roles){
  const a=getPlayerFromReq(req); if(!a) throw Object.assign(new Error("Authentication required."),{status:401,code:"unauthorized"});
  if(a.player.countryId!==countryId) throw Object.assign(new Error("You do not command this country."),{status:403,code:"forbidden"});
  const role=commandRoleFor(a.player.id,countryId); if(!roles.includes(role)) throw Object.assign(new Error("Insufficient command authority."),{status:403,code:"insufficient_authority"});
  return {auth:a,role};
}
function formationTemplate(body,countryId,playerId){
  return {id:id("formation"),countryId,name:String(body.name||"New Formation"),branch:String(body.branch||"ground"),role:String(body.role||"field_command"),status:"forming",baseCityId:body.baseCityId||null,commanderPlayerId:body.commanderPlayerId||null,chiefOfStaffPlayerId:body.chiefOfStaffPlayerId||null,units:[],requestedUnits:Array.isArray(body.units)?body.units:[],createdBy:playerId,createdAt:now(),updatedAt:now()};
}
function createFormationProduction(q){ formationProductionQueue.push({...q,id:id("fprod"),status:"active",progress:0,startedAt:now(),readyAt:new Date(Date.now()+Math.max(30,Number(q.durationSeconds)||120)*1000).toISOString()}); }

async function handleGovernment(req,res,path,method,requestId){
  const a=getPlayerFromReq(req);
  const countryId=a?.player?.countryId;
  if(method==='GET' && path==='/api/government/command'){
    if(!a) return fail(res,401,'unauthorized','Authentication required.',false,requestId);
    const structure=governmentCommandStructures.find(x=>x.countryId===countryId) || {countryId,presidentPlayerId:null,defenseMinisterPlayerId:null,militaryCommanderPlayerId:null,militaryPolicy:'defensive_readiness'};
    return ok(res,{structure,role:commandRoleFor(a.player.id,countryId),formations:militaryFormations.filter(f=>f.countryId===countryId),proposals:militaryProposals.filter(p=>p.countryId===countryId),production:formationProductionQueue.filter(p=>p.countryId===countryId)},200,requestId);
  }
  if(method==='POST' && path==='/api/government/appointments'){
    const body=await readBody(req); const targetCountry=body.countryId||countryId;
    let ctx; try{ctx=requireCommand(req,targetCountry,['president']);}catch(e){return fail(res,e.status||403,e.code||'forbidden',e.message,false,requestId)}
    const target=players.get(String(body.playerId||'')); if(!target||target.countryId!==targetCountry) return fail(res,404,'not_found','Player is not in this country.',false,requestId);
    const structure=governmentCommandStructures.find(x=>x.countryId===targetCountry); if(!structure) return fail(res,404,'not_found','Government not found.',false,requestId);
    if(body.role==='defense_minister') structure.defenseMinisterPlayerId=target.id;
    else if(body.role==='military_commander') structure.militaryCommanderPlayerId=target.id;
    else return fail(res,400,'validation_error','Unsupported appointment role.',false,requestId);
    playerNationRoles.push({id:id('role'),playerId:target.id,countryId:targetCountry,role:body.role,appointedBy:ctx.auth.player.id,appointedAt:now()});
    saveState(); return ok(res,{structure,player:publicPlayer(target)},200,requestId);
  }
  if(method==='POST' && path==='/api/government/formations/proposals'){
    const body=await readBody(req); const targetCountry=body.countryId||countryId;
    let ctx; try{ctx=requireCommand(req,targetCountry,['defense_minister','president']);}catch(e){return fail(res,e.status||403,e.code||'forbidden',e.message,false,requestId)}
    const proposal={id:id('proposal'),countryId:targetCountry,formation:formationTemplate(body,targetCountry,ctx.auth.player.id),status:'pending_approval',proposedBy:ctx.auth.player.id,createdAt:now()};
    militaryProposals.push(proposal); saveState(); return ok(res,proposal,201,requestId);
  }
  const pm=path.match(/^\/api\/government\/formations\/proposals\/([^/]+)\/approve$/);
  if(method==='POST' && pm){
    const proposal=militaryProposals.find(x=>x.id===pm[1]); if(!proposal) return fail(res,404,'not_found','Proposal not found.',false,requestId);
    let ctx; try{ctx=requireCommand(req,proposal.countryId,['president']);}catch(e){return fail(res,e.status||403,e.code||'forbidden',e.message,false,requestId)}
    proposal.status='approved'; proposal.approvedBy=ctx.auth.player.id; proposal.approvedAt=now();
    const formation=proposal.formation; formation.status='forming'; militaryFormations.push(formation);
    for(const requested of formation.requestedUnits||[]){
      const count=Math.max(1,Math.min(100000,Number(requested.quantity)||1));
      createFormationProduction({formationId:formation.id,countryId:proposal.countryId,cityId:formation.baseCityId,type:String(requested.type||'infantry'),quantity:count,durationSeconds:Math.max(60,Number(requested.durationSeconds)||180)});
    }
    formation.status='production'; saveState(); return ok(res,{proposal,formation},200,requestId);
  }
  if(method==='POST' && path==='/api/government/formations/assign-officer'){
    const body=await readBody(req); const formation=militaryFormations.find(f=>f.id===body.formationId); if(!formation) return fail(res,404,'not_found','Formation not found.',false,requestId);
    let ctx; try{ctx=requireCommand(req,formation.countryId,['president','defense_minister','military_commander']);}catch(e){return fail(res,e.status||403,e.code||'forbidden',e.message,false,requestId)}
    const target=players.get(String(body.playerId||'')); if(!target||target.countryId!==formation.countryId) return fail(res,404,'not_found','Officer is not eligible for this country.',false,requestId);
    if(body.position==='commander') formation.commanderPlayerId=target.id; else if(body.position==='chief_of_staff') formation.chiefOfStaffPlayerId=target.id; else return fail(res,400,'validation_error','Unsupported officer position.',false,requestId);
    playerNationRoles.push({id:id('role'),playerId:target.id,countryId:formation.countryId,role:`${formation.branch}_${body.position}`,formationId:formation.id,appointedBy:ctx.auth.player.id,appointedAt:now()});
    formation.updatedAt=now(); saveState(); return ok(res,formation,200,requestId);
  }
  return fail(res,404,'not_found','Government endpoint not found.',false,requestId);
}

async function handleMilitary(req, res, path, method, url, requestId) {
  const auth = getPlayerFromReq(req);
  if (!auth && method !== "OPTIONS") {
    // allow unauthenticated list for demo? require auth to match client
    if (!getBearer(req)) {
      // still require auth for military
    }
  }

  if (method === "GET" && path === "/api/military/units") {
    if (!getPlayerFromReq(req)) return fail(res, 401, "unauthorized", "Authentication required.", false, requestId);
    const countryId = url.searchParams.get("countryId");
    let list = [...units.values()];
    if (countryId) list = list.filter((u) => u.countryId === countryId);
    return ok(res, list, 200, requestId);
  }
  if (method === "GET" && path.startsWith("/api/military/units/")) {
    const uid = path.split("/").pop();
    const unit = units.get(uid);
    if (!unit) return fail(res, 404, "not_found", "Unit not found.", false, requestId);
    return ok(res, unit, 200, requestId);
  }
  if (method === "GET" && path === "/api/military/bases") {
    return ok(
      res,
      [
        {
          id: "base_1",
          name: "Central Command",
          countryId: "country_gnr",
          location: "Berlin Region",
          capacity: 50000,
          occupied: 16500,
        },
      ],
      200,
      requestId
    );
  }
  if (method === "GET" && path === "/api/military/recruitment") {
    return ok(res, { available: 1200, costPerSoldier: 50, trainingDays: 7 }, 200, requestId);
  }
  if (method === "GET" && path === "/api/military/armory") {
    const air = Object.entries(UNIT_BLUEPRINTS).map(([id,b]) => ({id,...b,branch:b.branch,category:"air_naval"}));
    const ground = Object.entries(GROUND_ARMORY).map(([id,b]) => ({id,...b,category:"ground"}));
    const unitsCatalog = [...ground,...air];
    const matchups = [];
    for (const [attacker,targets] of Object.entries(COMBAT_EFFECTIVENESS)) {
      for (const [target,multiplier] of Object.entries(targets)) {
        matchups.push({attacker,target,multiplier,stars:starsFor(Number(multiplier))});
      }
    }
    return ok(res,{units:unitsCatalog,matchups},200,requestId);
  }
  if (method === "GET" && path === "/api/military/blueprints") {
    return ok(res, Object.entries(UNIT_BLUEPRINTS).map(([id,b]) => ({
      id, ...b, researchReady: auth ? unitHasResearch(auth.player.id,b.requiresTech) : false,
    })), 200, requestId);
  }
  if (method === "GET" && path === "/api/military/production") {
    const a=getPlayerFromReq(req);
    return ok(res, aircraftProduction.filter(q=>!a || q.playerId===a.player.id), 200, requestId);
  }
  if (method === "POST" && path === "/api/military/production") {
    const a=getPlayerFromReq(req); if(!a) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    const body=await readBody(req);
    const type=String(body.type||"");
    const bp=blueprintFor(type);
    if(!bp) return fail(res,400,"invalid_unit_type","Unknown production blueprint.",false,requestId);
    if(bp.branch!=="air" && bp.branch!=="navy") return fail(res,400,"invalid_unit_type","This endpoint is for aircraft/naval production.",false,requestId);
    if(!unitHasResearch(a.player.id,bp.requiresTech)) return fail(res,409,"research_required",`Research ${bp.requiresTech} before production.`,false,requestId);
    const city=strategyCities.find(c=>c.id===body.cityId) || strategyCities.find(c=>c.countryId===a.player.countryId && c.capital);
    if(!city) return fail(res,404,"not_found","Production city not found.",false,requestId);
    const controller=city.controllerCountryId||city.countryId;
    if(controller!==a.player.countryId) return fail(res,403,"forbidden","You do not control this production city.",false,requestId);
    if(!hasFacility(a.player.countryId,bp.requiresFacility,city.id)) return fail(res,409,"facility_required",`Build a ${bp.requiresFacility} in ${city.name} first.`,false,requestId);
    const quantity=Math.max(1,Math.min(100,Number(body.quantity)||1));
    const total=Object.entries(bp.cost).reduce((sum,[k,v])=>sum + Number(v)*quantity*(k==="money"?1:0),0) || Number(bp.cost.money||0)*quantity;
    if(a.player.wealth<total) return fail(res,400,"insufficient_funds",`Production requires GD$${total.toLocaleString()}.`,false,requestId);
    a.player.wealth-=total;
    const q={id:id("prod"),playerId:a.player.id,countryId:a.player.countryId,cityId:city.id,type,quantity,completed:0,total,progress:0,status:"active",startedAt:now(),readyAt:new Date(Date.now()+bp.buildSeconds*1000*quantity).toISOString()};
    aircraftProduction.push(q); saveState(); return ok(res,q,201,requestId);
  }
  if (method === "POST" && path === "/api/military/recruit") {
    const a=getPlayerFromReq(req); if(!a) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    const body=await readBody(req); const countryId=body.countryId||a.player.countryId;
    if(!countryId || countryId!==a.player.countryId) return fail(res,403,"forbidden","You do not command this country.",false,requestId);
    const size=Math.max(100,Math.min(50000,Number(body.size)||1000));
    const unitType=String(body.type||"infantry");
    const requiredFacility=facilityForGroundUnit(unitType);
    if(requiredFacility && !hasFacility(countryId,requiredFacility,body.cityId||null)) return fail(res,409,"facility_required",`Build a ${buildingBlueprint(requiredFacility).displayName} before recruiting this unit.`,false,requestId);
    const costPerPerson={infantry:2,mechanized:4,armor:7,artillery:5,fighter:120,bomber:180,helicopter:90,frigate:2500,destroyer:4000,submarine:5000,carrier:12000}[unitType]||3;
    const totalCost=Math.round(size*costPerPerson);
    if(a.player.wealth<totalCost) return fail(res,400,"insufficient_funds",`Recruitment requires GD$${totalCost.toLocaleString()}.`,false,requestId);
    a.player.wealth-=totalCost;
    const capital=strategyCities.find(c=>c.countryId===countryId&&c.capital)||strategyCities.find(c=>(c.controllerCountryId||c.countryId)===countryId);
    const u=normalizeUnit({id:id("unit"),countryId,type:unitType,name:String(body.name||"New Formation"),size,location:capital?.name||countries.get(countryId)?.capital||"Capital",currentCityId:capital?.id||null,morale:70,supply:80,status:"forming",ownerPlayerId:a.player.id});
    units.set(u.id,u); events.unshift({id:id("evt"),title:`Recruitment — ${u.name}`,description:`${u.size.toLocaleString()} personnel mobilized in ${countries.get(countryId)?.name||countryId} for GD$${totalCost.toLocaleString()}.`,type:"military",timestamp:now(),countryIds:[countryId]});
    saveState();
    return ok(res,u,201,requestId);
  }
  if (method === "GET" && path === "/api/military/logistics") {
    return ok(res, { supplyLevel: 88, fuelReserves: 12000, ammoReserves: 45000, medicalCapacity: 92 }, 200, requestId);
  }
  if (method === "POST" && path === "/api/military/orders") {
    const a=getPlayerFromReq(req); if(!a) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    const body=await readBody(req); const unit=units.get(body.unitId); if(!unit) return fail(res,404,"not_found","Unit not found.",false,requestId);
    if(unit.countryId!==a.player.countryId && unit.ownerPlayerId!==a.player.id) return fail(res,403,"forbidden","You do not command this formation.",false,requestId);
    try { const order=startUnitOrder(unit,body,a.player.id); saveState(); return ok(res,order,201,requestId); } catch(e){ return fail(res,e.status||400,e.code||"validation_error",e.message,false,requestId); }
  }
  if (method === "GET" && path === "/api/military/orders") { const a=getPlayerFromReq(req); return ok(res,unitOrders.filter(o=>!a||o.playerId===a.player.id),200,requestId); }
  if (method === "GET" && path === "/api/military/deployments") { const a=getPlayerFromReq(req); const list=[...units.values()].filter(u=>!a||u.countryId===a.player.countryId).map(u=>({unitId:u.id,name:u.name,status:u.status,orderStatus:u.orderStatus,position:u.position,destination:u.destination,route:u.route,entrenchment:u.entrenchment,garrisonedCityId:u.garrisonedCityId,health:u.health,supply:u.supply,fuel:u.fuel,ammunition:u.ammunition})); return ok(res,list,200,requestId); }
  if (method === "GET" && path === "/api/military/overview") { const a=getPlayerFromReq(req); const list=[...units.values()].filter(u=>!a||u.countryId===a.player.countryId); return ok(res,{units:list,activeOrders:unitOrders.filter(o=>o.status==='active'&&(!a||o.playerId===a.player.id)),garrisons:list.filter(u=>u.garrisonedCityId),activeBattles:battles.filter(b=>b.status==='active')},200,requestId); }
  if (method === "POST" && path.startsWith("/api/military/orders/") && path.endsWith("/cancel")) {
    const a=getPlayerFromReq(req); if(!a) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    const oid=path.split("/")[4]; const o=unitOrders.find(x=>x.id===oid); if(!o) return fail(res,404,"not_found","Order not found.",false,requestId);
    if(o.playerId!==a.player.id) return fail(res,403,"forbidden","Order is not yours.",false,requestId);
    o.status='cancelled'; o.cancelled=true; o.completedAt=now(); const u=units.get(o.unitId); if(u){u.activeOrderId=null;u.destination=null;u.route=[];u.status='ready';u.orderStatus='idle';}
    saveState(); return ok(res,o,200,requestId);
  }
  if (method === "GET" && path === "/api/military/equipment") { return ok(res, [], 200, requestId); }
  if (method === "POST" && path.startsWith("/api/military/personnel")) {
    return ok(res, { success: true }, 200, requestId);
  }
  fail(res, 404, "not_found", "Military endpoint not found.", false, requestId);
}

async function handleWars(req, res, path, method, requestId) {
  if (method === "POST" && path.startsWith("/api/wars/battles/") && path.endsWith("/resolve")) {
    const a=getPlayerFromReq(req); if(!a) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    const battleId=path.split("/")[4]; const b=battles.find(x=>x.id===battleId);
    if(!b) return fail(res,404,"not_found","Battle not found.",false,requestId);
    b.progress=Math.min(100,b.progress+20);
    if(b.progress>=100){
      b.status=b.attackerStrength>b.defenderStrength?"attacker_won":"defender_won";
      const winnerCountryId=b.status==="attacker_won"?b.attackerCountryId:b.defenderCountryId;
      const loserCountryId=b.status==="attacker_won"?b.defenderCountryId:b.attackerCountryId;
      const territory=strategyTerritories.find(t=>t.id===b.territoryId);
      if(territory){
        territory.controllerCountryId=winnerCountryId;
        territory.countryId=winnerCountryId;
        territory.controlPercentage=100;
        territory.contested=false;
        territory.occupied=winnerCountryId!==territory.originalCountryId;
        territory.updatedAt=now();
        const city=strategyCities.find(c=>c.id===territory.cityId);
        if(city) city.controllerCountryId=winnerCountryId;
        worldHistory.unshift({id:id("hist"),type:"territory",title:`${territory.name} captured`,description:`${winnerCountryId} took control from ${loserCountryId}.`,timestamp:now(),countryIds:[winnerCountryId,loserCountryId]});
        events.unshift({id:id("evt"),title:`Territory captured: ${territory.name}`,description:`Control transferred to ${winnerCountryId}.`,type:"military",timestamp:now(),countryIds:[winnerCountryId,loserCountryId]});
      }
      const war=wars.find(w=>w.id===b.warId);
      if(war){
        const remaining=battles.some(x=>x.warId===war.id && x.status==="active");
        if(!remaining){
          war.status="ended";
          war.endedAt=now();
          const wc=countries.get(winnerCountryId); const lc=countries.get(loserCountryId);
          if(wc) wc.status="peace"; if(lc) lc.status="peace";
          worldHistory.unshift({id:id("hist"),type:"war_end",title:`War ended: ${wc?.name||winnerCountryId} victory`,description:`The war ended after the decisive battle at ${b.location}.`,timestamp:now(),countryIds:[war.attackerCountryId,war.defenderCountryId]});
          events.unshift({id:id("evt"),title:`War ended: ${wc?.name||winnerCountryId} victory`,description:`${b.location} is now controlled by ${winnerCountryId}.`,type:"military",timestamp:now(),countryIds:[war.attackerCountryId,war.defenderCountryId]});
        }
      }
    }
    return ok(res,b,200,requestId);
  }
  if (method === "GET" && path === "/api/wars/active") {
    return ok(
      res,
      wars.filter((w) => w.status === "active"),
      200,
      requestId
    );
  }
  if (method === "POST" && path === "/api/wars/declare") {
    const auth = getPlayerFromReq(req);
    if (!auth) return fail(res, 401, "unauthorized", "Authentication required.", false, requestId);
    const body = await readBody(req);
    const attacker = auth.player.countryId;
    const defender = body.defenderCountryId;
    if (!attacker || !defender) {
      return fail(res, 400, "validation_error", "attacker/defender required.", false, requestId);
    }
    if (!countries.has(defender)) {
      return fail(res, 404, "not_found", "Defender not found.", false, requestId);
    }
    const war = {
      id: id("war"),
      attackerCountryId: attacker,
      defenderCountryId: defender,
      status: "active",
      declaredAt: now(),
      declaredByPlayerId: auth.player.id,
      reason: body.reason || "Unspecified",
    };
    wars.push(war);
    const ac = countries.get(attacker);
    const dc = countries.get(defender);
    if (ac) ac.status = "at_war";
    if (dc) dc.status = "at_war";
    events.unshift({
      id: id("evt"),
      title: `War Declared: ${ac?.name || attacker} vs ${dc?.name || defender}`,
      description: war.reason,
      type: "military",
      timestamp: now(),
      countryIds: [attacker, defender],
    });
    return ok(res, war, 201, requestId);
  }
  if (method === "POST" && path.match(/^\/api\/wars\/[^/]+\/join$/)) {
    const auth=getPlayerFromReq(req); if(!auth) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    const warId=path.split("/")[3]; const w=wars.find(x=>x.id===warId);
    if(!w || w.status!=="active") return fail(res,404,"not_found","Active war not found.",false,requestId);
    const city=strategyCities.find(c=>c.id===auth.player.currentCityId);
    const targetCountry=String((await readBody(req)).side||"");
    const side=targetCountry==="defender"?w.defenderCountryId:w.attackerCountryId;
    if (!city || city.controllerCountryId!==side && city.countryId!==side) return fail(res,403,"forbidden","You must travel to a city controlled by the side you are joining.",false,requestId);
    auth.player.career="military_volunteer";
    const participant=w.participants||(w.participants=[]);
    if(!participant.includes(auth.player.id)) participant.push(auth.player.id);
    return ok(res,{war:w,playerId:auth.player.id,side},200,requestId);
  }
  if (method === "POST" && path.match(/^\/api\/wars\/[^/]+\/peace$/)) {
    const auth=getPlayerFromReq(req); if(!auth) return fail(res,401,"unauthorized","Authentication required.",false,requestId);
    const warId=path.split("/")[3]; const w=wars.find(x=>x.id===warId);
    if(!w) return fail(res,404,"not_found","War not found.",false,requestId);
    const body=await readBody(req);
    const resolved=battles.filter(b=>b.warId===w.id && b.status!=="active");
    const winnerCountryId=body.winnerCountryId || (resolved.length ? (resolved.filter(b=>b.status==="attacker_won").length>=resolved.filter(b=>b.status==="defender_won").length?w.attackerCountryId:w.defenderCountryId) : null);
    if(winnerCountryId){
      for(const b of battles.filter(b=>b.warId===w.id && b.status!=="active")){
        const territory=strategyTerritories.find(t=>t.id===b.territoryId);
        if(territory){
          territory.controllerCountryId=winnerCountryId; territory.countryId=winnerCountryId; territory.controlPercentage=100; territory.contested=false; territory.occupied=winnerCountryId!==territory.originalCountryId; territory.updatedAt=now();
          const city=strategyCities.find(c=>c.id===territory.cityId); if(city) city.controllerCountryId=winnerCountryId;
        }
      }
    }
    w.status="ended"; w.endedAt=now();
    const ac=countries.get(w.attackerCountryId); const dc=countries.get(w.defenderCountryId);
    if(ac) ac.status="peace"; if(dc) dc.status="peace";
    worldHistory.unshift({id:id("hist"),type:"peace",title:"Peace agreement",description:`War ${w.id} has ended${winnerCountryId?` with ${winnerCountryId} controlling captured territory`:""}.`,timestamp:now(),countryIds:[w.attackerCountryId,w.defenderCountryId]});
    return ok(res,w,200,requestId);
  }
  if (
    method === "GET" &&
    (path.includes("/fronts") ||
      path.includes("/battles") ||
      path.includes("/objectives") ||
      path.includes("/territory") ||
      path.includes("/ceasefires") ||
      path.includes("/peace"))
  ) {
    if(path.includes("/battles")) return ok(res,battles,200,requestId);
    if(path.includes("/fronts")) return ok(res,wars.filter(w=>w.status==="active").map(w=>({warId:w.id,attackerCountryId:w.attackerCountryId,defenderCountryId:w.defenderCountryId,battles:battles.filter(b=>b.warId===w.id)})),200,requestId);
    return ok(res, [], 200, requestId);
  }
  fail(res, 404, "not_found", "Wars endpoint not found.", false, requestId);
}

async function handleDiplomacy(req, res, path, method, url, requestId) {
  if (method === "GET" && path === "/api/diplomacy/relation") {
    const a = url.searchParams.get("countryA");
    const b = url.searchParams.get("countryB");
    if (!a || !b) return fail(res, 400, "validation_error", "countryA and countryB required.", false, requestId);
    return ok(
      res,
      { countryA: a, countryB: b, relation: relations.get(`${a}:${b}`) ?? 0, min: -100, max: 100 },
      200,
      requestId
    );
  }
  if (method === "GET" && path === "/api/diplomacy/relations") {
    const auth = getPlayerFromReq(req);
    const countryId = url.searchParams.get("countryId") || auth?.player?.countryId;
    if (!countryId) return fail(res, 400, "validation_error", "countryId required.", false, requestId);
    const list = [...countries.values()]
      .filter((c) => c.id !== countryId)
      .map((c) => ({
        countryId: c.id,
        name: c.name,
        relation: relations.get(`${countryId}:${c.id}`) ?? 0,
      }));
    return ok(res, list, 200, requestId);
  }
  if (method === "GET" && path === "/api/diplomacy/treaties") {
    return ok(res, diplomaticTreaties, 200, requestId);
  }
  if (method === "POST" && path === "/api/diplomacy/treaties") {
    const auth = getPlayerFromReq(req);
    if (!auth) return fail(res, 401, "unauthorized", "Authentication required.", false, requestId);
    const body = await readBody(req);
    const treaty={id:id("treaty"),type:body.type||"trade",parties:body.parties||[auth.player.countryId],status:"proposed",createdAt:now(),proposedBy:auth.player.id};
    diplomaticTreaties.push(treaty);
    return ok(res,treaty,201,requestId);
  }
  if (method === "GET" && path === "/api/diplomacy/missions") {
    return ok(res, [], 200, requestId);
  }
  fail(res, 404, "not_found", "Diplomacy endpoint not found.", false, requestId);
}

async function handleBanking(req, res, path, method, requestId) {
  const auth = getPlayerFromReq(req);
  if (method === "GET" && path === "/api/banking/banks") {
    return ok(
      res,
      [
        { id: "bank_global", name: "Global Dominion Central Bank", countryId: null, interestRate: 2.5 },
        { id: "bank_national", name: "National Commercial Bank", countryId: "country_jps", interestRate: 3.1 },
      ],
      200,
      requestId
    );
  }
  if (method === "GET" && path === "/api/banking/accounts") {
    if (!auth) return fail(res, 401, "unauthorized", "Authentication required.", false, requestId);
    return ok(
      res,
      accounts.filter((a) => a.playerId === auth.player.id),
      200,
      requestId
    );
  }
  if (method === "POST" && path === "/api/banking/accounts") {
    if (!auth) return fail(res, 401, "unauthorized", "Authentication required.", false, requestId);
    const body = await readBody(req);
    const account = {
      id: id("acct"),
      playerId: auth.player.id,
      bankId: body.bankId || "bank_global",
      balance: 0,
      currency: body.currency || "GD$",
      createdAt: now(),
    };
    accounts.push(account);
    return ok(res, account, 201, requestId);
  }
  if (method === "POST" && path === "/api/banking/transfers") {
    if (!auth) return fail(res, 401, "unauthorized", "Authentication required.", false, requestId);
    const body = await readBody(req);
    return ok(
      res,
      {
        id: id("tx"),
        fromAccountId: body.fromAccountId,
        toAccountId: body.toAccountId,
        amount: body.amount,
        status: "completed",
        createdAt: now(),
      },
      200,
      requestId
    );
  }
  if (path.includes("/loans")) {
    if (method === "GET") return ok(res, [], 200, requestId);
    if (method === "POST") {
      if (!auth) return fail(res, 401, "unauthorized", "Authentication required.", false, requestId);
      const body = await readBody(req);
      return ok(
        res,
        {
          id: id("loan"),
          playerId: auth.player.id,
          amount: Number(body.amount) || 0,
          termDays: Number(body.termDays) || 30,
          interestRate: 5.0,
          status: "approved",
          createdAt: now(),
        },
        201,
        requestId
      );
    }
  }
  fail(res, 404, "not_found", "Banking endpoint not found.", false, requestId);
}

async function handleCompanies(req, res, path, method, url, requestId) {
  if (method === "GET" && path === "/api/companies") {
    const ownerId = url.searchParams.get("ownerId");
    let list = companies;
    if (ownerId) list = companies.filter((c) => c.ownerPlayerId === ownerId);
    return ok(res, list, 200, requestId);
  }
  if (method === "POST" && path === "/api/companies") {
    const auth = getPlayerFromReq(req);
    if (!auth) return fail(res, 401, "unauthorized", "Authentication required.", false, requestId);
    const body = await readBody(req);
    if (!body.name) return fail(res, 400, "validation_error", "name required.", false, requestId);
    if (auth.player.wealth < 500) {
      return fail(res, 400, "validation_error", "Need 500 wealth to found a company.", false, requestId);
    }
    auth.player.wealth -= 500;
    const company = {
      id: id("co"),
      name: String(body.name).slice(0, 64),
      ownerPlayerId: auth.player.id,
      countryId: body.countryId || auth.player.countryId,
      sector: body.sector || "general",
      valuation: 500,
      employees: 1,
      createdAt: now(),
    };
    companies.push(company);
    return ok(res, company, 201, requestId);
  }
  if (method === "GET" && path.startsWith("/api/companies/")) {
    const cid = path.split("/").pop();
    const company = companies.find((c) => c.id === cid);
    if (!company) return fail(res, 404, "not_found", "Company not found.", false, requestId);
    return ok(res, company, 200, requestId);
  }
  if (method === "PUT" && path.startsWith("/api/companies/")) {
    const auth = getPlayerFromReq(req);
    if (!auth) return fail(res, 401, "unauthorized", "Authentication required.", false, requestId);
    const cid = path.split("/").pop();
    const company = companies.find((c) => c.id === cid);
    if (!company) return fail(res, 404, "not_found", "Company not found.", false, requestId);
    if (company.ownerPlayerId !== auth.player.id) {
      return fail(res, 403, "forbidden", "Not the owner.", false, requestId);
    }
    const body = await readBody(req);
    if (body.name) company.name = String(body.name).slice(0, 64);
    if (body.sector) company.sector = String(body.sector);
    return ok(res, company, 200, requestId);
  }
  fail(res, 404, "not_found", "Companies endpoint not found.", false, requestId);
}

// ─── start ─────────────────────────────────────────────────


const server = http.createServer((req, res) => {
  handle(req, res);
});

server.on("upgrade", (req, socket, head) => {
  const url = new URL(req.url || "/", `http://${req.headers.host || "localhost"}`);
  if (url.pathname === "/ws") {
    acceptWs(req, socket, head);
  } else {
    socket.destroy();
  }
});

setInterval(advanceTick, TICK_MS);

server.listen(PORT, HOST, () => {
  console.log(`
╔══════════════════════════════════════════╗
║     GLOBAL DOMINION API SERVER           ║
╠══════════════════════════════════════════╣
║  HTTP   http://localhost:${PORT}/api
║  Health http://localhost:${PORT}/health
║  WS     ws://localhost:${PORT}/ws
║  Data   ${PERSIST_FILE}
╚══════════════════════════════════════════╝
`);
});

function shutdown() {
  console.log("\n[shutdown] saving state…");
  saveState();
  process.exit(0);
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
