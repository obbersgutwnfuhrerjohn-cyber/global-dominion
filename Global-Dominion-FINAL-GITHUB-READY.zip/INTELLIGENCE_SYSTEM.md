# Global Dominion Intelligence System

- Every seeded country starts with a fictional national intelligence directorate.
- Players can establish additional agencies for their own country for GD$5,000, subject to a five-agency country cap.
- Agencies have level, mission capacity and counterintelligence strength.
- Players can launch persistent recon, surveillance, counterintelligence and sabotage missions.
- Missions run on server time and continue while the player is offline.
- Defender counterintelligence can detect and catch missions when they resolve.
- Successful missions award player experience, prestige and currency; caught missions produce a compromise report.
- All mission state is server-authoritative and exposed through `/api/intelligence`.
