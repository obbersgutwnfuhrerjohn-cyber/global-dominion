# Secret Service Headquarters Building

The intelligence system now has a physical city building requirement.

## Building
- `secret_service` — Secret Service Headquarters
- Base cost: GD$1,200
- Construction: 140 server ticks
- Max level: 5
- Each level increases intelligence agency support and counterintelligence.

## Gameplay
- A country must control a city containing a completed Secret Service Headquarters before a player can open an additional intelligence agency.
- HQ level determines the country's agency capacity (up to the global cap).
- HQ level also increases newly created agency capacity and counterintelligence.
- The four default alternate-history starting powers begin with a headquarters in their capital so their seeded national intelligence agencies remain operational.
- HQs are normal buildings: they appear in the Build screen, use the normal construction queue, have integrity, can be destroyed, and must be rebuilt if destroyed.
