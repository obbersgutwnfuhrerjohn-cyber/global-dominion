# Global Dominion — Strategy Implementation

The game now treats the world map as the primary strategy interface while keeping the existing authentication and Render server architecture.

## Persistent server systems

- Real-time resource production/consumption ticks
- Persistent market buy/sell transactions
- Persistent cities and territories
- City development/building queues
- Research projects and technology tree
- Persistent military recruitment
- Military movement orders
- Persistent battle records and battle resolution
- War declarations and active-war state
- Diplomatic relations
- Persistent JSON world state under `server/data/world.json`
- WebSocket tick broadcasts
- `/health` health check preserved for Render

## Map

- Supplied `mobile/assets/world-map.png` remains the main world-map artwork.
- Cities are loaded from the server rather than only from the UI mock list.
- Map zoom changes the amount of city detail shown.
- Night mode adds city glow and strategic lighting.
- Military, fleet and battle layers remain visible on the map.

## Client

The World Command screen remains the primary screen. Existing authentication, profile, economy, military, politics and work flows are preserved. Nation, Research and Diplomacy screens were added as additional command surfaces.

## Important distinction

Global Dominion is an original game. The implementation takes broad inspiration from persistent real-time grand-strategy mechanics (resource production, construction, research, diplomacy, military movement and combat), but does not copy proprietary code, artwork, branding or exact UI from other games.
