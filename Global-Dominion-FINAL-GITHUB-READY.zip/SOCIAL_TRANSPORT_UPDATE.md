# Global Dominion — Social + Global Transportation Update

## Map transportation
- Added a server-generated transportation network exposed at `GET /api/map/routes`.
- Road network: 415 gameplay road links connecting nearby cities and regional hubs.
- Sea network: 93 sea lanes connecting coastal/port hubs.
- Air network: 63 air corridors connecting major international hubs.
- The Expo World Map renders the routes as a single SVG layer for performance.
- Roads are solid tan lines, sea lanes are dashed blue lines, and air corridors are dotted light lines.
- Port and airport markers appear when zoomed in.
- Military unit routes remain separate and use their own live server-calculated paths/ETAs.

## Social / news
- Added `mobile/src/app/(tabs)/social.tsx`.
- Added automatic system/world feed entries from world events and wars.
- Players can publish text posts.
- Players can publish image posts using Expo Image Picker + Image Manipulator.
- Added direct player-to-player messaging.
- Added coalition creation, joining, and coalition chat.
- Social content is stored in the existing JSON persistence file and survives server restarts.

## New API
- `GET /api/map/routes`
- `GET /api/social/feed`
- `POST /api/social/posts`
- `GET /api/social/messages`
- `POST /api/social/messages`
- `GET /api/social/coalitions`
- `POST /api/social/coalitions`
- `POST /api/social/coalitions/:id/join`
- `GET /api/social/coalitions/:id/messages`
- `POST /api/social/coalitions/:id/messages`

## Mobile dependency
In `/workspaces/global-dominion/mobile` run:

`npx expo install expo-image-picker expo-image-manipulator`

Then restart Expo with cache cleared:

`npx expo start --web --clear`

The existing Render server/Docker configuration is unchanged.
