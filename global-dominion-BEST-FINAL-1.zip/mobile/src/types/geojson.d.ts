declare module "*.geojson";
